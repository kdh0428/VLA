# 다음 단계 실행 프롬프트 — AutoVLA 중심 원고 마무리

작성일: 2026-10-18 (KST)  
대상: 연구 저장소에 접근할 수 있는 코딩 에이전트  
입력: 최신 EXPERIMENT_SUMMARY.md, outputs/review_followup3/, paper_quantitative_package/ 및 해당 원자료/코드

## 1. 이번 작업의 목표와 범위

이번 논문은 **AutoVLA를 주 모델로 유지**한다. OpenVLA와 SpatialVLA는 서로 다른 개입/실행 수준의 보완 증거로 사용한다.

가장 먼저 할 일은 모델 수 확대가 아니라, review_followup3에서 발견된 통계·구현·해석 문제를 해결해 독자가 핵심 결론을 검증할 수 있게 만드는 것이다.

작업 순서는 다음과 같다.

1. **A — 기존 자료와 코드로 통계·해석 문제 수정 및 재현 자료 완성.**
2. **B — AutoVLA의 남은 개입 식별 확인, 보완 증거에 사용하는 OpenVLA 경로의 최소 실행 검증.**
3. **C — 실제 증거에 맞춰 핵심 표·주장·원고 수정.**
4. π₀-FAST는 후속 확장 후보로 적합성만 확인한다. 이번 필수 작업에 대규모 fine-tuning이나 여러 모델의 동시 추가를 넣지 않는다.

이 파일을 새 실행 지시로 전달받으면 필요한 코드 수정, 실제 검증 추론, 아래에 정의한 AutoVLA 후속 확인을 현재 배정된 자원에서 수행하라. 계획만 작성하고 완료 처리하지 않는다. 실제로 불가능한 항목만 BLOCKED로 남기고 다른 작업은 진행한다.

기존 CP2에서 P3/P4를 실행하지 않기로 한 기록은 역사적 결정으로 보존한다. 이번 새 실행은 별도 후속 round의 프로토콜과 결과로 기록한다. 과거 NOT_RUN을 소급 DONE으로 바꾸지 않는다.

## 2. 이미 확보된 결과: 재활용하되 범위를 지킬 것

최신 저장소 원자료를 확인한 뒤 다음 결과를 출발점으로 사용한다.

- AutoVLA 6개 경로 H7/H8/H9/P1A/H32/P1B의 gate는 21+18 path-unit 검증 범위에서 PASS로 보고됐다.
- SpatialVLA split-fingerprint 재검증은 20/20 단위에서 통과했다.
- P1-C 평가 대상 E는 2,191 eligible scenes다. 실제 개입 분석은 선정된 353 scenes / 24 drives이며 sampling weights를 적용했다.
- P1-C F는 105 scenes / 18 drives다. 이를 “24 independent failure drives”라고 쓰지 않는다.
- RN 평가 집합 추정: −4.1 pp [−6.4, −2.4]; RV: +3.6 pp [+2.2, +5.5].
- 개발 자연 평가 A− 빈도: 52/2,747=1.89%. 배포 실패율이 아니다.
- 운동 baseline의 all은 **선정된 208 scenes**다. 2,747/2,191 scenes 전체나 배포 모집단이 아니다.
- OpenVLA는 기존 100 initial states × 8 conditions=800 episodes 재분석이다. 새 inference/parity 검증은 수행되지 않았다.
- 기존 운동 baseline 및 learned motion extrapolator는 이미 추가됐다. 이를 다시 처음부터 학습하지 않는다.
- 기존 검증 manifest의 PASS는 모든 과거 run의 소급 검증이 아니다.
- 현재 보고서의 수치와 저장소 원자료가 다르면 차이를 기록한다. 보고서 숫자에 코드를 맞추지 않는다.

AGENTS.md와 저장소 지침을 읽고, rg로 관련 코드와 실제 경로를 찾는다. 원 결과를 보존하고 별도 outputs/review_followup4/와 변경 이력을 만든다. 기존 사용자 작업을 종료하거나 다른 실험 환경을 파괴하지 않는다.

## 3. A — 즉시 수행: 통계·해석 문제 해결

### A1. 성공률 CI가 [0,0]으로 퇴화하는 문제

구체적인 확인 대상:

- P0E.succ_task.C-F_d8.t5
- P0E.succ_task.C-F_d24.t6

기존 numbers.json에서는 value=0, n_states=10인데 CI가 약 ±2.5e−13이다. 다른 OpenVLA per-task 행에도 같은 현상이 있다.

수행할 일:

1. 단위별 paired success 자료로 2×2 counts를 재구성한다.
2. 기존 sign-flip inversion 구현과 가정을 확인하고, 모든 차이가 0인 입력에서 왜 0폭 CI가 되는지 재현한다.
3. “고정된 관측 표본의 차이”와 “새 상태 집합의 성공확률 차이” 중 어느 추정 대상에 대한 구간인지 명시한다.
4. zero-null McNemar/exact paired test가 맞다는 사실만으로, margin이 0이 아닌 가설이나 모집단 risk-difference CI의 타당성까지 입증됐다고 하지 않는다.
5. 독립 초기 상태의 paired binary 자료에는 Newcombe의 paired score 계열 등 경계에서 0폭으로 퇴화하지 않는 방법을 비교한다. independent-proportions 방법으로 pairing을 없애지 않는다.
6. 같은 물리 상태의 반복이 있는 SpatialVLA에 독립 pair 공식을 그대로 적용하지 않는다. 원 estimand의 가중과 state cluster를 유지한다.
7. 관련 CI와 TOST를 만드는 공통 함수를 추적한다. OpenVLA뿐 아니라 SpatialVLA pooled/per-task 동등성 판정에 영향이 있는지 검사한다.
8. 후보 방법은 coverage/가정으로 선택한다. 유의성이나 동등성 결과가 유리해지는 방법을 고르지 않는다.
9. 필요하면 n=10/100, 0/소수 discordant pairs, 높은/낮은 성공률 및 cluster 반복을 포함하는 작은 coverage simulation으로 문제를 확인한다.
10. 구/신 point estimate, CI, p, margin, Holm family와 판정 변경을 나란히 출력한다. 통계 방법 변경은 사후 sensitivity/수정임을 표시하고 원 분석을 보존한다.

0폭 구간은 “두 방법이 정확히 같다”는 근거로 쓰지 않는다. 적절한 모집단 구간을 얻을 수 없다면 해당 CI는 추론용으로 사용하지 않고 descriptive/NR로 표시한다.

참고:
- https://pubmed.ncbi.nlm.nih.gov/9839354/
- https://www.statsmodels.org/dev/generated/statsmodels.stats.proportion.confint_proportions_paired.html

API는 현재 설치 버전에서 확인한다. dev 문서의 함수를 설치된 버전에 존재한다고 가정하지 않는다.

### A2. correction window의 persistent GT와 release 표현 정리

충돌하는 문서:

- P1/INTERVENTION_SPEC.md: 교정된 고정 절대 위치의 GT가 이후 생성 문맥에도 계속 남는다.
- P0/WINDOW_WEIGHT_AUDIT.md: 특정 시점 이후 “condition on own tokens only”라고 설명한다.

실제 temporal_feedback_window.py 등의 코드를 기준으로 아래를 확정한다.

- 생성 step별 전체 action prefix.
- 원래 token, 실제 context token, GT 여부, overwrite 위치.
- 교정 위치가 뒤 step에서도 GT로 유지되는지.
- “새 GT 위치를 더 이상 추가하지 않음”과 “기존 GT가 문맥에서 제거됨”의 구분.
- 기존 “post-release horizon”이 무엇의 종료 후 시간을 센 것인지.

fixed-position GT가 계속 남는 구현이라면 허용되는 문장은 다음과 같다.

> Three fixed context positions replaced with ground truth and retained in later contexts recovered about 90% of the full-history correction effect.

다음 주장은 삭제한다.

- 세 step 교정 후 GT 정보를 완전히 제거해도 효과가 유지된다.
- 이후 생성은 모델 자신의 token만 참고한다.
- 짧은 일시적 correction만으로 지속적인 회복을 입증했다.

90% 수치의 정의는 유지하되, 교정 위치 수·가중·denominator·남은 생성 길이를 같이 보고한다. 별도 GT 제거 실험 없이 true release 결과를 만들지 않는다.

### A3. Impromptu 재현성 원인 분리

현재 구현 명세의 경고:

- delta-0 normal vs natural: 23/300 scenes 일치.
- natural_rep vs natural: 237/2,728 일치.

먼저 CPU로 원자료 pairing과 코드 경로를 점검한다.

- 정확히 같은 입력·prefix·decoding·seed·rounding·batch인지.
- 자연 생성 결과와 재구성한 text context가 같은 토큰열인지.
- 0.01 m 반올림, 좌표 변환, 재토큰화, source branch, RNG 소비의 차이.
- 실제 같은 조건의 반복인지, 문서가 서로 다른 조건을 no-op처럼 비교했는지.

동일 조건 소규모 실행으로 원인을 확인할 수 있으면 실제 수행한다. 불일치 원인을 확인하지 못하면 Impromptu는 descriptive/unverified로 두거나 핵심 증거에서 제외한다.

이번 라운드에 Impromptu의 대규모 기전 실험을 추가할 필요는 없다. “3개 다른 모델에서 강하게 재현”이라는 문장을 유지하려고 비용을 확대하지 않는다.

### A4. 분모·지표·결론의 범위 통일

다음 집합을 모든 표/캡션/초록에서 구분한다.

- 개발 natural set: 2,747 scenes.
- 개발 mechanism set: 208 selected scenes, F/A+ 비율이 자연 빈도와 다름.
- P1-C target E: 2,191 eligible scenes.
- P1-C intervention sample: 353 selected scenes, weighted estimate.
- P1-C failure stratum: 105 scenes / 18 drives.
- motion-baseline all: 208 selected scenes.

추가 확인:

- RN 전체 효과 중 약 60%가 A+ stratum에서 기여한다는 분해를 유지한다. 이를 전부 원래 실패 장면의 복구로 설명하지 않는다.
- OpenVLA 92.6%는 “적어도 한 후속 성분의 bin 변화가 주입 bin 이상”이라는 지표다. 모든 후속 차원이 그렇다거나 92.6%의 실제 실패가 발생했다고 쓰지 않는다.
- translation/rotation/gripper의 물리 단위를 분리한다.
- commanded action delta와 실제 TCP 이동을 분리한다.
- 서로 반대인 과제별 point estimate만으로 이질성이 확정됐다고 하지 않는다.
- drive-disjoint와 day/vehicle-disjoint를 구분한다.
- A−와 severe의 실제 식·threshold·5 s horizon을 적는다. 3 s로 문서화된 threshold가 5 s에 사용된 부분은 원 정의를 보존하며 명확히 밝힌다.
- 비유의는 동등성이 아니다. 검증된 경로라는 사실은 추정량/통계의 타당성 인증이 아니다.

### A5. 재현 패키지 복구

이전 ZIP에는 다음 파일 상당수가 없었다.

- review_followup3 분석/통계/개입 구현 코드.
- OpenVLA episode records, state mapping, per-task CSV.
- P1 protocol, verification manifests, tolerance pilot, judge 로그.
- P2 locked protocol, 표 계산에 필요한 단위별 summary.
- P3 protocol, P4 power plan 등 보고서가 참조하는 파일.

원 저장소에 존재하면 실제 파일을 포함하는 최소 재현 ZIP을 만든다.

- 무거운 checkpoint/원본 영상 전체는 넣지 않는다.
- paired outcomes, cluster IDs, weights, inclusion/exclusion, source hashes 등 수치 재계산에 충분한 자료는 포함한다.
- 공개 파일 다운로드는 revision과 checksum을 고정한다.
- 코드와 입력이 없는 절대 경로 목록만으로 “재현 가능”이라고 하지 않는다.
- 기존 파일이 실제로 없으면 MISSING으로 명시한다.
- historical CP2 보고서와 final 상태의 우선순위를 README에 적는다.
- final 내용을 복사한 문서에 PROVISIONAL/PENDING이 남았는지 확인하고, 역사 기록이면 명확히 표시한다.
- ZIP의 자체 포함 입력으로 핵심 표를 재생성하는 명령을 실제 실행한다.

## 4. B — 새 모델을 늘리기 전에 필요한 실행

### B1. AutoVLA의 짧은 수치 민감도 확인

기존 gate 6개 경로 전체를 이유 없이 반복하지 않는다. 검증되지 않은 쟁점을 겨냥한다.

- full recompute/free-run과 batch shape에서 suffix가 달라진다는 기존 결과를 보존한다.
- 동일한 실행 경로와 배치 안의 paired contrast가 어떤 수치 안정성을 갖는지 점검한다.
- 기존 gate처럼 “허용 logit 오차 이내”만 보고 끝내지 말고, suffix 차이가 endpoint/severe 판정에 주는 크기를 측정한다.
- 사전에 고정한 대표 manifest에서 no-edit 반복, 실제 개입, 가능한 안정적 연산 설정을 비교한다.
- dtype/backend 변경이 가능하면 동일 input/pairing/dose를 유지해 sensitivity로 실행한다. precision이나 배치가 함께 바뀌면 그 차이를 기록한다.
- 정상 수치 변동을 개입 효과에서 임의로 빼지 않는다.
- 결과가 materially 달라지면 해당 결론을 제한하고 필요한 최소 재실행 범위를 산정한다.

이는 main effect 전체를 새로 추정하는 외부 재현이 아니라, 수치 구현에 대한 sensitivity다.

### B2. AutoVLA matched-prefix 확인: 이번 후속 효과 실험의 우선순위

이전 P3 프로토콜이 존재하면 읽고 아래 질문에 맞게 재사용한다.

> 최신 문맥 block의 값이 중요한가, 아니면 더 오래된 GT prefix의 존재에 크게 의존하는가?

기존 Reverse-N은 GT 문맥에 별도 Normal branch 값을 넣는 처치다. 모델 자신의 오류를 동적으로 되먹이는 모든 상황으로 일반화하지 않는다.

설계:

- older prefix: GT / matched natural prefix.
- latest block source: GT / frozen Normal-source / frozen corrected-source.
- 같은 observation, instruction, anchor, non-target positions, source bank, decoding/RNG 계획.
- 먼저 source bank를 고정하고 arm의 결과에 따라 source를 재선택하지 않는다.
- 값이 달라지면 순수 provenance 효과라고 하지 않는다.
- 하나의 edited prefix를 구성해 suffix를 생성하는 방식부터 수행한다.
- 이후에도 그 prefix를 유지한다면 명시한다. “단발 prefix 치환”과 “교정 정보가 이후에 제거됨”은 다른 뜻이다.
- 기존 반복 Recent/Reverse 결과와 새 single-anchor 결과를 섞지 않는다.

anchor와 코호트:

- older-prefix factor가 비어 있는 anchor는 factorial 식별에 도움이 되지 않는다.
- 충분한 이전 block과 이후 suffix가 존재하도록 anchor 규칙을 사전에 고정한다.
- anchor 제한으로 eligible set이 달라지면 분모와 sampling weights를 다시 계산한다. 원래 2,191-scene estimand를 그대로 붙이지 않는다.
- 전체 eligible 평가와 failure stratum을 모두 보고한다. 미래 결과를 보고 anchor를 선택하지 않는다.
- 새 데이터가 아니면 외부 검증이라고 하지 않는다. 기존 drive에서 새 intervention arm을 실행한 것이다.

주 대비:

- 같은 older prefix 안에서 latest-source 차이.
- older-prefix × latest-source interaction.
- suffix local action 변화, 5 s endpoint/명시된 고정 horizon, severe-event 차이.
- 직접 좌표 누적과의 관계는 기존 지표를 정확히 정의해 연결한다.

실행 전 고정:

- 프로토콜, 포함 기준, 가중/cluster, 주요 대비 family, 표본 수, stopping rule.
- source/target token과 decoded motion, prefix hash.
- no-op, 같은 token 재삽입, full-recompute/cached consistency 검증.
- 현재 배정된 자원의 짧은 throughput pilot로 실제 비용 산정.

확인 가능한 새 arm은 실제 실행하라. 자원이 모자라면 수행 가능한 범위와 달성 정밀도를 데이터 열람 전에 고정하고, 축소 범위를 정직하게 보고한다. 예산 부족을 근거로 이미 실행된 결과를 사후 선별하지 않는다.

GT 기반 실험은 원인 진단용이다. online 복구 방법 또는 배포 성능 개선으로 부르지 않는다.

### B3. OpenVLA의 최소 경로 검증

OpenVLA를 본문에서 기전 보완 증거로 유지할 경우 수행한다. 핵심 증거에서 제외하기로 명시하면 대규모 추가 실행 없이 unverified 상태를 유지할 수 있다.

- 정확한 기존 LIBERO-Spatial checkpoint revision과 normalizer를 복원한다.
- untouched / hook-no-op / 동일 token self-patch / cached vs full recompute를 실제 실행한다.
- 같은 관측·prompt·RNG·batch 조건을 고정한다.
- 비행동 argmax가 bin 254로 조용히 clipping되는 빈도와 영향을 기록한다.
- action-token mask를 추가하면 정책을 바꾼 것이다. 구/신 경로를 분리하고 기존 결과를 소급 수정하지 않는다.
- baseline 재실행의 20% outcome disagreement가 어떤 단계에서 생기는지 진단한다.
- 상태 복원 범위, controller state, RNG, 관측 fingerprint를 확인한다.
- 정상 재실행 불일치 20%를 임의의 “효과 검출 임계값 20 pp”로 쓰지 않는다.

이 단계에서 LIBERO 4 suite 전체나 대규모 새 OpenVLA 기전 프로그램을 자동으로 시작하지 않는다. 이번 주 모델은 AutoVLA다.

## 5. C — 결과에 따른 원고와 주장 정리

### 중심 주장 후보

아래는 검증 후 유지 가능한 범위에서만 쓴다.

1. AutoVLA의 정의된 failure stratum에서 action-context 개입이 후속 생성/궤적에 큰 영향을 준다.
2. 일부 효과는 평가 집합의 평균에서도 관측되지만 크기·분모·불확실성이 다르다.
3. 실패 선택층의 endpoint 반응은 이번에 평가한 운동학/학습 외삽 대조를 넘어선다.
4. 조작 모델에서는 생성 변화, 실제 궤적 변화, task success를 별도로 판단해야 한다.

### 중심 기여에서 낮출 항목

- persistent GT window의 90%를 “짧은 일시적 교정의 지속 효과”로 제시하지 않는다.
- 자체 parity를 통과하지 못한 Impromptu/OpenVLA를 강한 독립 재현으로 세지 않는다.
- 두 과제 평균 동등성을 과제별 무효과로 일반화하지 않는다.
- 모델별 다른 처치의 raw effect를 비교해 구조 순위를 만들지 않는다.
- 모든 VLA의 보편적 오류 원인을 발견했다고 하지 않는다.
- 방법/체크포인트가 다른 π₀와 π₀-FAST의 차이를 순수 architecture effect라고 하지 않는다.

새 matched-prefix 결과가 기대와 다르면 그 결과를 따른다. GT prefix 의존성이 크다면 oracle-conditioned diagnostic이라고 더 좁힌다. 변화가 정상적 보상에 해당한다면 오류/증폭이라는 명명을 낮춘다.

원고 .tex가 저장소에 없으면 문장별 수정안과 표를 별도 파일로 작성한다. 파일이 없는데 실제 원고를 수정했다고 보고하지 않는다.

## 6. 새 모델 확장: 이번에는 feasibility만

A–C 완료 후 π₀-FAST를 다음 확장 후보로 판단한다.

확인할 것:

- 목표 benchmark용 checkpoint가 실제로 존재하며 접근 가능한가?
- checkpoint, tokenizer, action normalizer가 짝을 이루는가?
- 공식 JAX/지원 backend에서 baseline이 동작하는가?
- 현재 공식 openpi에서 FAST의 PyTorch 지원 여부를 확인했는가?
- BPE token position과 DCT 계수 범위가 어떻게 연결되는가?
- token 교체 자체의 decoder 효과와 suffix 재생성 효과를 분리할 수 있는가?
- decode 실패 시 영행동 fallback 등이 있는가?
- 같은 환경에서 실제 사용할 수 있는 비교 모델이 있는가?

성립하지 않는 토큰 개입은 NA다. flow/diffusion 모델의 해당 경로 부재를 측정된 0 효과로 채우지 않는다.

WorldVLA를 후보로 검토하면 원 논문 버전의 코드와 실제 attention mask를 확인한다. 현재 저장소 main이 RynnVLA-002로 연결되는 것과 구분한다. mask 적용/미적용 학습 체크포인트 쌍을 확인하지 않고 “matched pair 공개”라고 쓰지 않는다.

RoboFlamingo/RT-2/Octo를 동시에 늘리는 것은 이번 범위가 아니다. π₀-FAST 때문에 새 대규모 fine-tuning이 필요하면 비용과 확보 가능한 질문을 FEASIBILITY.md에 보고하고 A–C 완료를 우선한다.

## 7. 산출물, 재현 ZIP, 완료 보고

권장 산출물:

- STATUS.md — DONE/PARTIAL/BLOCKED/NOT_RUN, CPU/GPU/새 효과 실험 구분.
- CI_VALIDITY_AUDIT.md/.csv
- WINDOW_SEMANTICS_AUDIT.md
- IMPROMPTU_PARITY_DIAGNOSIS.md
- COHORT_ESTIMAND_MAP.csv
- NUMERICAL_SENSITIVITY.md/.csv
- MATCHED_PREFIX_PROTOCOL.md, MATCHED_PREFIX_RESULTS.md/.csv
- OPENVLA_GATE.md/.csv
- CLAIM_CHANGES.md
- MANUSCRIPT_REVISION.md, machine-generated tables/figures
- FEASIBILITY.md — 추가 모델은 실행 여부와 비용을 사실대로.
- RUN_COMMANDS.md
- 최소 원자료·구현·protocol·judge 로그를 포함한 reproducibility_minimal.zip
- 각 파일의 hash와 근거를 연결한 SOURCE_MANIFEST.csv.

문서·결과의 단순 복사는 새 독립 증거가 아니다. 재현 ZIP에서 핵심 통계표를 실제 재계산해 원 표와 비교한다.

최종 보고 순서:

1. 실제로 고친 오류와 수정 전후 수치/판정.
2. 실제 실행한 새 검증/모델 추론/효과 실험 수.
3. task/physical-state/scene/drive/상위 cluster 분모.
4. 유지·축소·삭제할 정확한 주장.
5. 막힌 항목과 현재 결론에 남는 제한.
6. commit, 재현 명령, 포함 파일과 누락 파일.

**완료 기준:** 원하는 결과가 나온 것이 아니라, 개입·추정 대상·독립 단위·구간·실행 검증·주장이 서로 일치하고 제3자가 확인할 자료가 제공된 것이다.

