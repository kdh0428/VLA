#!/usr/bin/env python
"""AutoVLA rows of claim_to_code.csv (values checked in p0a_autovla_audit.py / summaries; see analysis.md)."""
import csv
import os

RUN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = "autovla_misalignment_poc/scripts/"
O = "O/"  # /root/VLA/autovla_misalignment_poc/outputs/
F = ["claim", "source_doc", "code_file_line", "commit", "raw_file", "verified_from", "status", "note"]
rows = [
    ["A- = 52/2,747 natural scenes (1.89%), 16 logs; step-0 token wrong 17/52 A-, 216 A+",
     "PAPER_NUMBERS Claim 1; EXPERIMENT_SUMMARY", S + "equal_distance_perturbation.py:151-166; pra_comparison/pra_labels.py:469-485",
     "1541f30 (bf15767 GPU-pin only)", O + "full_extract/records.jsonl (regenerated 2026-09-27 on new machine)", "raw", "match",
     "recomputed: 2,748 records, 1 CoT excluded -> 2,747; A- 52 (16 logs); first-mismatch t*=0: A- 17, A+ 216"],
    ["A- = '5 s trajectory failure'", "PAPER_NUMBERS Claim 1; SOURCE_MAP S1", "pra_comparison/pra_labels.py:469-485; vla_misalignment_poc/analysis/trajectory_metrics.py:20-31,104-140",
     "1541f30", "-", "code_only", "partial",
     "implemented as coarse action-class mismatch (lon class with v_end tolerance grid, lat class with +-1 m/+-10 deg grid), not a distance/collision failure; thresholds documented for 3 s/6 steps applied to 5 s/10 steps"],
    ["Experiment 5 population 1,159 scenes (A- 52 / A+ 1,107)", "SOURCE_MAP S2", S + "first_mismatch_causal.py:80-99", "1541f30",
     O + "full_extract/records.jsonl", "raw", "match", "recomputed: all valid scenes with a first mismatch = 1,159 (A+ 1,107 in 28 logs); exp-5 result records not kept"],
    ["Exp 5 one-token GT correction at first mismatch: recovery 17.3 -> 73.1%", "PAPER_NUMBERS Claim 3", S + "first_mismatch_causal.py:150-170",
     "1541f30", "none (records/logits not on disk)", "summary", "unverifiable-from-raw",
     "intervention is OUTPUT-level (GT token executed and in context, then HF generate), unlike context-only Recent-GT"],
    ["Equal-distance set 208 scenes (A- 52/16 logs, A+ 156), 1,408 units (A- 365 / A+ 1,043); 313/887 alternatives", "PAPER_NUMBERS header, Claim 2",
     S + "equal_distance_perturbation.py:151-180,228-231", "1541f30", O + "equal_distance_perturbation/records.jsonl", "raw", "match",
     "A+ spans 26 logs; A+ chosen 3 per A- at same t* with random.Random(0); exp-6 HF generate left the action span in 1 A- unit (364/365 valid)"],
    ["Normal amplification 47.4% -> Recent-GT 7.1% (-40.3 pp, McNemar 2 vs 149), GT-history 4.1%", "PAPER_NUMBERS Claim 3; EXPERIMENT_SUMMARY l.107",
     S + "action_history_causal.py:205-239; " + S + "analyze_action_history.py:57-67", "1541f30", O + "action_history_causal/records.jsonl",
     "raw", "match", "recomputed exactly from raw with original unit_metrics"],
    ["Recent-GT = 'only the last context token replaced by GT' / '직전 token 1개만 GT로 바꿔도 93%'", "PAPER_NUMBERS Claim 3; EXPERIMENT_SUMMARY l.17-18,59",
     S + "action_history_causal.py:210-212", "1541f30", O + "action_history_causal/records.jsonl", "raw", "partial",
     "width 1 per forward but SLIDING and re-applied at every step k>=t*+2: 8-t* applications per unit (A- mean 6.8; token actually changed 4.32 times on average; 4 A- units with 0 effective changes). Earlier positions revert to the branch's own tokens. Not a single correction"],
    ["Recent-GT removes 93% of GT-history effect (40.3/43.3)", "PAPER_NUMBERS Claim 3", S + "analyze_action_history.py", "1541f30",
     O + "action_history_causal/records.jsonl", "raw", "match", "0.930 recomputed; CI exists only for exp 8 (92.9% [89.3, 99.1]) whose Normal is 46.8% (different harness)"],
    ["Attention masks -1.4 pp / -3.3 pp (n.s.)", "PAPER_NUMBERS Claim 3", S + "action_history_causal.py:130-152", "1541f30",
     O + "action_history_causal/records.jsonl", "raw", "match", "46.0-47.4 and 44.1-47.4 recomputed"],
    ["Reverse (exp 8): 'inserting the model's own last-token embedding into a GT history' 4.4 -> 33.4% (+29.0 pp), restores 68%",
     "PAPER_NUMBERS Claim 3; EXPERIMENT_SUMMARY l.108", S + "prev_action_state_patching.py:99-100,174-189", "1541f30",
     "none for main run (records.jsonl absent); tiny re-run rerun_tiny/exp8 (3 units)", "summary", "partial",
     "implementation: row base = gt_history context; at every step k>=t*+2 the hidden state (emb) of position k-1 is copied from the SEPARATE Normal row of the same batch, i.e. the Normal branch's token, not the token the reverse branch itself generated (shown in rerun trace alt0: injected 568/1083 while reverse's own output was 268/638). Numbers only in summary.json"],
    ["Exp 8 layer patching: any of 37 sites 3.8-7.4%", "PAPER_NUMBERS Claim 4", S + "prev_action_state_patching.py:76-101,174-189", "1541f30",
     O + "prev_action_state_patching/summary.json (no records)", "summary", "unverifiable-from-raw",
     "patch target = last span position only (1 position x 1 layer) every step; patch@emb == recent_gt and patch@L35 == gt_history by construction (sanity rate 1.0)"],
    ["Exp 8 Normal reproduces exp 7", "summary sanity", S + "prev_action_state_patching.py:136-143", "1541f30",
     O + "prev_action_state_patching/summary.json sanity", "summary", "partial", "Normal 88.6%, gt_history 92.9%, recent_gt 88.6% token-identical to exp 7 (B=93 bf16 batch path)"],
    ["Exp 9 window 1/2/3/4 steps recover 47/76/90/96% (Normal 46.6, Full 4.1)", "PAPER_NUMBERS Claim 5; EXPERIMENT_SUMMARY l.61,109",
     S + "temporal_feedback_window.py:62-70,180-191", "1541f30", O + "temporal_feedback_window/summary.json (no records)", "summary",
     "unverifiable-from-raw", "win_w = GT at FIXED absolute context positions t*+1..t*+w, kept in context at all later steps (not w repeated last-token corrections, not a one-off correction); win1 (47%) is a different intervention from Recent-GT (93%)"],
    ["Critical window '2-4 steps' / 'about 3 steps'", "PAPER_NUMBERS Claim 5; EXPERIMENT_SUMMARY l.18,264", S + "analyze_temporal_feedback_window.py",
     "1541f30", O + "temporal_feedback_window/summary.json subsets.all perturbations.A-.critical_window", "summary", "partial",
     "critical window (f>=0.9) point = 4, bootstrap median 3.5, CI [3,4]; f>=0.8 -> 3; label depends on threshold"],
    ["Normal amplification differs across exps 46.6/46.8/47.1/47.4/47.9%", "CONSISTENCY_AUDIT m-1", "batched harnesses (B=17/93/9/1/6)",
     "1541f30/bf15767/af2eb10", O + "action_history_causal, motion_semantics_ablation records", "raw", "match",
     "exp32 vs exp7 raw: Normal tokens identical 88.2%, A- amplification label differs in 8/365 units; exp7 vs exp6 stored 71.6%"],
    ["Direction-wrong vs magnitude-wrong +9.0 pp (61 vs 28), mirror -34.2 pp, achieved distances 0.318 vs 0.505, mirror 0.458 vs 0.515",
     "PAPER_NUMBERS Claim 7", S + "motion_semantics_ablation.py:56-75,207-225", "af2eb10 (prereg) / aee41e5 (analysis)",
     O + "motion_semantics_ablation/records.jsonl", "raw", "match",
     "substitute replaces position k-1 at every step (sliding, 8-t* times); dir_wrong substitute does not reach its target distance e (0.318 vs e 0.499)"],
    ["Token motion = codebook end pose (dx, dy)", "SOURCE_MAP S9", S + "motion_semantics_ablation.py:token_motion", "af2eb10", "autovla/codebook_cache/agent_vocab.pkl",
     "code_only", "match", "segment displacement in the frame of the segment start; direction/magnitude are per 0.5 s segment, not global heading"],
    ["GT tokens = navsim future trajectory tokenised with the AutoVLA routine", "metric spec", "autovla/navsim/navsim/agents/autovla_agent.py:88-151,286-320; vla_agent.py:108-112",
     "AutoVLA ba34eed", O + "full_extract/records.jsonl gt_action_idx", "code_only", "match",
     "ego-local frame at current pose; greedy contour match (2.0x4.8 m box corners) with re-anchoring on the chosen token"],
    ["Exp 7 context/output separation (executed action stays model's own)", "action_history_causal docstring; PAPER_NUMBERS Claim 3",
     S + "action_history_causal.py:207-239", "1541f30", O + "action_history_causal/records.jsonl", "raw", "match",
     "executed = pred[:t*]+forced+own; prefix KV never patched, span recomputed every step (no stale KV)"],
    ["Mechanism experiments 4-11 'fixed before running'", "reports (e.g. exp 4 rules, 3.0 m threshold)", "-", "1541f30 (scripts+results same commit)",
     "-", "unverified", "unverifiable", "no git evidence of pre-registration (SOURCE_MAP already notes this); only exp 32 has prior commit af2eb10"],
    ["Cross-model 'Reverse' row compares like with like", "paper_cross_model_table.csv; EXPERIMENT_SUMMARY l.222,263",
     S + "prev_action_state_patching.py:99-100; " + S + "cross_vla_temporal/exp_cde.py (reverse)", "1541f30 / 038a6d3", "-", "code_only", "mismatch",
     "AutoVLA reverse = emb-state copied from a separate Normal branch (residual patch); Impromptu reverse = the reverse branch's OWN k-1 waypoint as text; SpatialVLA see its row. Different source branches and mechanisms"],
]
with open(os.path.join(RUN, "work", "claims_autovla.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(F)
    w.writerows(rows)
print(len(rows))
