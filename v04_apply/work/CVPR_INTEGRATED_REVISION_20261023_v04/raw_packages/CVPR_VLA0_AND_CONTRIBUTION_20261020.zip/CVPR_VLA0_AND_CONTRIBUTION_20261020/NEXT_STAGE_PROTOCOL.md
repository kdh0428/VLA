# NEXT_STAGE_PROTOCOL — not executed in this package

## 1. Confirmatory within-call matched-prefix diagnostic on VLA-0 (independent initial states)
- Units: LIBERO spatial/object/goal (and libero_10 if added), all 10 tasks per suite, initial states 6–25 (never used here;
  states 0 = validation, 1–5 = this development pilot). 20 states × 30 tasks = 600 observations; task = cluster (30 clusters).
- Fixed in advance from this pilot only: anchor a = 3, whole-vector donors from 4 samples at T = 0.7 with length-matched
  substitution, arms R/O/L/OL, primary endpoint L − O normalised response, source-distance-matched secondary.
- Precision target: half-width of the task-cluster 95 % interval for L − O ≤ 1/3 of the pilot |L − O| estimate; with the pilot's
  between-task SD this needs ≈ 30 tasks × 20 states (planning from the pilot variance; to be recomputed before running).
- Cost estimate (from measured pilot latency; see README): ≈ 600 × pilot seconds/observation ≈ 4–5 GPU-hours on one RTX 5090;
  disk: weights 7.5 GB (or /dev/shm), observations ≈ 0.4 MB each.
- Margins: no equivalence claim unless a task-justified margin for the normalised response is fixed before running.

## 2. VLA-0 closed loop (only if 1 shows an interpretable within-call effect)
- Keep the native evaluation behaviour: action_horizon = 1, ensemble_prediction = 8 (ensemble version 1); changing either is a
  separate ablation. An intervention edits the conditioning text of one call; the executed action is the ensembled first step, so
  the edited call contributes to the next 8 executed actions through the ensemble buffer — log the buffer contents per step.
- Pairing: same task, same initial state, same env seed (7), identical replay until the intervention step (state hashes checked
  as in SpatialVLA P1-D); arms N / context-only (R) / executed-only (C) / both (F) as in P1-D; no-op control = re-feeding the
  natural text.
- Outcomes: success (episode), actual end-effector trajectory deviation (simulator), time to success; demonstrations are not
  ground truth after any deviation. Episode count: success differences of ±10 pp need ≈ 300 paired episodes per arm (P1-D
  precision analysis); ≈ 1–2 min/episode with 8-prediction ensembling (unmeasured) → tens of GPU-hours.

## 3. Largest remaining evidence gap (priority)
Independent driving clusters: every AutoVLA split (dev mechanism set, P1-C/B2, best-of-N development and heldout) lies in the same
5 day–vehicle components of their union (tables/autovla_split_components.csv), so no re-split creates independent clusters. New
disjoint day-and-vehicle data (not in OpenScene trainval) is the single most valuable addition; a third model or more tasks do not
fix this limitation.
