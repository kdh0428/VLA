# CONTRIBUTION_DECISION
Category: **PILOT_COMPLETE, interpretable response with full coverage** (149/150 analysed; donors 149/149 for every vector).
- Contribution added: a second policy/representation in which the same within-call question (emitted prefix fixed, conditioning
  value edited) shows the same qualitative temporal pattern as AutoVLA (latest > older, additive-on-average). Development pilot;
  needs the independent-state confirmatory run (NEXT_STAGE_PROTOCOL.md §1) before a paper-level claim.
- Not added: model-family generality (same Qwen2.5-VL-3B backbone), task outcome for VLA-0, AutoVLA independent clusters (all
  AutoVLA splits share 5 day–vehicle components), any new method.
- Largest remaining gap: independent driving clusters (new day-and-vehicle-disjoint data). Next experiment: the confirmatory
  VLA-0 diagnostic on LIBERO initial states 6–25 (≈ 600 obs, ≈ 5 GPU-h) only after deciding whether its result would change the
  paper's claims more than resolving the driving-cluster gap.
