# PROTOCOL_BEFORE_VLA0_GPU — VLA-0 native-path validation and within-call pilot (fixed 2026-10-20 before any VLA-0 GPU output)

Post-hoc-free design written and hashed (PROTOCOL_LOCK.json) before the first VLA-0 forward pass. Not a retroactive registration.

## Fixed artefacts
- Code: NVlabs/vla0 commit b78db19eda67b02844fe82b8929e1f94de7f2dcc (tarball, unmodified). Weights: HF `ankgoyal/vla0-libero`
  revision 6c62a511ad56042b2b3ea0a90c4def33e1ea3b96, folder `model_last/` (2 safetensors shards 7,509,337,944 bytes + tokenizer/
  processor/config), root `config.yaml`, `dataset_stats.pkl`. The 15 GB `model_last.pth` is NOT used; numerical equality of the two
  exports is not tested. Weights are held in /dev/shm (RAM-backed mount; /root has ≈ 2.2 GB free).
- Environment: existing `autovla` conda env (torch 2.8.0+cu128, transformers 4.49.0; export saved with 4.51.3) + existing LIBERO /
  robosuite / Mesa EGL install of /root/VLA/openvla (env.sh). Not modified. RTX 5090 (GPU 1), bf16, B = 1, attention = sdpa default.
- Adapter: `vla0_adapter.py` sets the official `QwenActor` attributes from config.yaml (horizon 8, act_dim 7, 1000 bins, 2 tiled
  224×224 cameras, history 1, add_vision_id) and loads the HF export directly (the official constructor would first download the
  base model). Native functions are used for image preprocessing (`image_unifier_transform`, eval=True: center crop 0.875 of 256 →
  224, no colour augmentation), image tiling, chat template, logits processor (digits/space/EOS only) and `forward`.
- Observation: native eval preprocessing — OffScreenRenderEnv 256×256 (camera depths on), env.seed(7), set_init_state(i), 10
  dummy steps [0,0,0,0,0,0,−1], agentview + wrist images flipped [::-1, ::-1]; cameras 3p1 = agentview, 3p2 = wrist (dataset
  physical-intelligence/libero camera key order image, wrist_image).
- Generation: greedy = `do_sample=False`, `max_new_tokens=1024`, model generation_config otherwise inherited (repetition_penalty
  1.05, as in the native .pth path whose base generation_config is identical); sources: `do_sample=True`, temperature 0.7, seed =
  first 4 bytes of sha256("vla0src:"+obs_id), `num_return_sequences=4` (batch of 4 from one prompt). Final generation config logged.
  Note: repetition_penalty acts on all digit tokens present in the input, so a context edit can also act through this penalty;
  this is part of the native policy and is reported, not removed.

## Validation (12 observations: suites spatial/object/goal × task 0, 3, 6, 9 × init state 0)
PASS requires for every observation: native `forward` succeeds; adapter greedy ids decode to exactly the native text and parsed
action; raw output = 56 integers in [0, 1000] ending in EOS (no padding/truncation/fallback); the text-path prefix of the first 21
numbers + trailing space retokenises to exactly the generated ids (vector boundary) and equals the concatenation of the 3 per-vector
tokenisations; self-patch (prefix re-fed through the text path) continuation token ids identical to the original continuation; the
continuation starts with the 22nd number (timestep 4). A donor (different-source) edit of vector 3 is run as a separate check; it
is gated only on invariants (equal token length, unchanged tokens outside the edited span). Token identity is the criterion; no
logit tolerance. Failures → fix code, re-run the same 12; unresolved → BLOCKED_PARITY, no pilot.

## Pilot (150 observations: 3 suites × 10 tasks × init states 1–5)
- Reference A = greedy chunk (natural reference, not GT). Emitted prefix = A1:A3 (anchor a = 3); all arms condition on a prefix of
  3 vectors and generate timesteps 4–8.
- Source bank: the 4 sampled chunks. For each target vector j ∈ {1, 2, 3}: the first candidate (in generation order) whose vector j
  has 7 valid integers, differs from A_j, and whose substitution keeps the tokenised prefix length and all tokens outside vector j
  identical. None → NO_MATCHED_SOURCE for j. No re-sampling, no seed/temperature/candidate change.
- Arms: R (A1:A3), O (vector 2 ← donor), L (vector 3 ← donor), OL (2 and 3), H (1 and 2), HL (1, 2, 3); primary R/O/L/OL,
  secondary H/HL; an arm runs only if all its donors exist.
- Response (primary metric): mean over timesteps 4–8 and the first 6 dims of |arm − R| / 1000 (normalised action-command bins);
  gripper reported as flip rate. Arms with < 35 suffix numbers are flagged and excluded from that contrast (no padding).
- Primary endpoint: paired L − O response difference. Secondary/descriptive: per-arm response, first changed timestep, per-timestep
  curves, signed vector interaction I = A_OL − A_L − A_O + A_R (mean |I|/1000), H vs L, source distance (same metric on the donor
  vector) and the pre-fixed source-distance-matched subset (L/O distance ratio in [0.8, 1.25]).
- Uncertainty: task-cluster bootstrap (30 tasks), 10,000 resamples, seed 20261020, 95 % percentile; suite-level estimates
  descriptive (3 suites). No multiplicity family; development pilot only.
- Budget: GPU wall time for validation + pilot ≤ 120 min; on reaching the cap the pilot stops → PARTIAL with completed
  observations listed.
