# INPUTS_AND_ENVIRONMENT
- Code: NVlabs/vla0 b78db19eda67b02844fe82b8929e1f94de7f2dcc (tarball sha256 b8c1ce72b557a762ed74a3b531637c4edd68f4317a31189c1da73e9484324968, unmodified; not in the zip).
- Weights: huggingface.co/ankgoyal/vla0-libero @ 6c62a511ad56042b2b3ea0a90c4def33e1ea3b96, model_last/model-00001-of-00002.safetensors
  sha256 2021480ff1b4fb6e635195591615d7cd93d7fba492865375d6f49722b4415e4a, -00002 sha256 2fd9786a84cf652f432173bb4f69951eaaca3d840995f730cd7ec4496b98d659
  (= HF LFS etags); config.yaml sha256 6624f21b24a760dda442217454accf0873526d446b88ca257c5f130fc678c7ea; dataset_stats.pkl sha256 ee365dfe83bb9a20a8e5b3777ce72d44e26b7352fa6e609cd9d6483aaae09c6b. Held in /dev/shm during the run (deleted after loading to GPU); not in the zip.
- LIBERO: /root/VLA/openvla/LIBERO (existing install, task order [0..9], 50 init states/task), robosuite + Mesa EGL from /root/VLA/openvla/site, env.sh.
- Python 3.9 autovla env: torch 2.8.0+cu128, transformers 4.49.0 (export saved with 4.51.3), qwen_vl_utils; GPU RTX 5090 (GPU 1).
- Final generation config (greedy): do_sample False; inherited repetition_penalty 1.05, eos [151645, 151643], pad 151643; logits processor digits/space/EOS; max_new_tokens 1024 (+ forced prefix length). Sources: do_sample True, temperature 0.7, seeds sha256("vla0src:"+obs_id)[:4], 4 return sequences.
- Observations (162 npz, 27 MB, re-renderable with scripts/vla0_prepare_obs.py; included).
