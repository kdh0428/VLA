# DECISION_SUMMARY — VLA-0 native validation and within-call pilot (2026-10-20)

**Status: PILOT_COMPLETE** (interpretable response, full donor coverage). Development pilot on initial LIBERO observations,
command level only; not a cross-model replication of AutoVLA's outcome effects, not a success-rate result.

## Execution
| Step | Result |
|---|---|
| Weights | HF export `model_last/` @ 6c62a51 (sha256 of both shards = HF LFS etags), held in /dev/shm (disk /root ≈ 2.2 GB free); the 15 GB .pth not used; export–pth numerical equality not tested |
| Native validation (12 obs) | attempt 1/2: no output (import error; OOM kill during load); **attempt 3 FAIL** (all 12 executed): self-patch token identity 3/12 when the prefix was fed by prefill concatenation (digit-level divergences, prefill-vs-incremental bf16 path); fix = forced decoding through the native incremental KV path (no tolerance change); **attempt 4 PASS 12/12**: native text and parsed action identical, 56 integers in range + EOS, prefix boundary/retokenisation exact, self-patch continuation token-identical, suffix starts at timestep 4, donor-edit invariants hold (donor found 12/12) |
| Pilot (150 obs) | completed 150/150; 149 analysed (1 reference with 55 numbers → REFERENCE_INCOMPLETE, excluded, no padding); donors found for vectors 1/2/3 in 149/149; all arm suffixes complete; self-patch identity 149/149 |
| GPU | RTX 5090, 78.1 min for the final validation+pilot run (+ ≈ 8 min in the failed attempts) < 120 min cap; 30.5 s/observation median (8 generate calls: reference, 4 sampled sources in one call, 6 arms); peak 8.4 GB |

## Effects (normalised action-command response = mean |arm − R| over generated timesteps 4–8, dims 1–6, /1000; task-cluster
bootstrap 95 %, 30 tasks, 10,000 resamples, seed 20261020)
| Quantity | Estimate | 95 % CI | n obs / tasks |
|---|---|---|---|
| **PRIMARY L − O** (latest vs one-older vector replaced) | **+0.0137** | [0.0115, 0.0157] | 149 / 30 |
| L − O, source-distance-matched subset (L/O distance ratio 0.8–1.25) | +0.0154 | [0.0120, 0.0190] | 66 / 27 |
| response O / L / OL | 0.0160 / 0.0297 / 0.0290 | [0.0138, 0.0183] / [0.0266, 0.0330] / [0.0260, 0.0321] | 149 / 30 |
| response H (1–2) / HL (1–3) (secondary) | 0.0162 / 0.0297 | | 149 / 30 |
| signed interaction mean (OL − L − O + R) | −0.0011 | [−0.0038, 0.0013] | 149 / 30 |
| mean |interaction| (descriptive) | 0.0250 | [0.0219, 0.0281] | |
| source distance O / L | 0.0224 / 0.0254 | | |
L > O in 83 % of observations and in 30/30 task means; first changed timestep = 4 (median) for all edited arms; gripper flips 0.
Suite estimates (descriptive): L − O 0.0143 (spatial), 0.0161 (object), 0.0107 (goal) (effects.csv).
Pattern over time: replacing the latest vector shifts the suffix immediately (≈ 0.029 from timestep 4 on); replacing the older vector
starts smaller (0.010) and grows to ≈ 0.020 by timestep 8 (figures/vla0_timestep_response).

## Reading
- Same question as AutoVLA's matched prefix, different representation: with the emitted actions fixed, changing only the conditioning
  value of the latest timestep vector changes the generated continuation about twice as much as changing the previous vector, also
  when donor distances are matched; adding the older edit to the latest edit (OL) does not add on average (signed interaction ≈ 0,
  interval includes 0). This parallels AutoVLA's large latest-position contrast with I ≈ 0 — at command level, on initial
  observations, with donors drawn from the model's own samples.
- Not shown: correctness or utility (donors are not errors; R is not GT), physical motion, success, later episode states,
  backbone diversity (both Qwen2.5-VL-3B). The integer-text edit also changes the digit tokens seen by the native
  repetition_penalty 1.05; this channel is part of the native policy and is not separated here.
- Signed-interaction ≈ 0 is not equivalence (no margin); |I| is large because per-coordinate responses are noisy.
