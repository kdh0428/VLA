# 코딩 에이전트 통합 프롬프트 — VLA-0 실행 검증·핵심 파일럿과 CVPR 기여·일반화 보강

작성일: 2026-10-20 (KST)

## 0. 목표와 실행 순서

기존 AutoVLA 중심 action-context intervention 연구를 이어서 수행하세요. 목표는 모델 이름을 하나 추가하는 것이 아니라, **실제로 출력한 과거 행동을 고정했을 때 조건 문맥만 바꾸는 개입이 어떤 후속 행동 변화를 만드는지**를 다른 행동 표현과 과제에서 검증하는 것입니다.

이 문서는 기여·일반화 보강 계획과 VLA-0 실행 지시를 함께 포함합니다.

- 지금 병행할 작업: 기존 결과·원고 정리, 주장–증거 표 작성, 일반화 축 점검, VLA-0 환경·어댑터·프로토콜 준비.
- 순서가 필요한 작업: 실제 native 경로 검증 → 통과한 코드로 소규모 within-call 파일럿 → 결과와 적용 범위에 맞춘 주장 수정.
- VLA-0가 로드되거나 no-op 검사를 통과한 것만으로 cross-model 재현을 달성했다고 보고하지 마세요.
- 계획서만 제출하고 끝내지 말고, 아래 범위의 구현·실행·분석·전달물을 가능한 범위에서 완료하세요. 검증 통과 뒤에는 단계마다 다시 질문하지 말고 파일럿으로 진행하세요.

이번 실행 범위는 **공식 VLA-0 checkpoint 형식 하나 확보, 필요한 최소 입력·환경 준비, 실제 12-observation 검증, 통과 시 150-observation 개발 파일럿, CPU 분석과 원고 보강 자료 작성**입니다. 기존 프롬프트의 ‘VLA-0 CPU 사전 점검만’ 범위를 이번 지시가 확장합니다.

G4 heldout 추론·gate 튜닝, 새 fine-tuning, 대규모 LIBERO 성공률 평가, 새 주행 closed-loop 환경 구축, 추가 모델들의 연속 다운로드는 이번 범위에 포함하지 않습니다. VLA-0의 성능 향상 방법을 임의로 새로 만들어 붙이지 마세요.

## 1. 출발점과 보존할 결론

기본 프로젝트 위치는 /root/VLA/autovla_misalignment_poc 입니다. 실제 경로와 상위 지침부터 확인하세요. 이 문서를 작성한 대화 환경은 서버에 접속한 상태가 아니므로, 아래 자원 수치를 현재 상태라고 가정하면 안 됩니다.

우선 읽을 자료:

- CVPR_G4_PILOT_AND_MODEL_EXTENSION_20261020 패키지의 DECISION_SUMMARY.md, PROTOCOL_BEFORE_GPU.md, CHANGES_AFTER_LOCK.md, vla0/, paper/.
- CVPR_G4_PILOT_VERIFICATION_20261020.md.
- VERIFICATION_RESPONSE_20261020.md와 실제 수정된 README/DECISION_SUMMARY.
- 기존 AutoVLA matched-prefix 실험의 프로토콜, parity 자료, 단위·군집 정의, SpatialVLA 8행 자료.
- 현재 서버의 최신 원고·PDF 및 해당 원고가 참조하는 원자료.

확정된 시작점:

1. G4 개발 파일럿은 600 scenes, 56 logs, 가중치 합 4,563이며 STOP입니다. FDE 기준 충족은 5/10/20%의 3개 예산, 추가 PDMS 기준 충족은 0/5입니다.
2. 5% 예산에서 gain−entropy PDMS는 약 +0.000374입니다. ‘PDMS 개선이 전혀 없다’가 아니라 ‘사전 설정한 추가 개선 0.003 기준에 미달’이라고 쓰세요. STOP은 무효과·동등성의 통계적 증명이 아닙니다.
3. G4의 효과는 regenerated keep 대비입니다. stored keep와 544/600이 같고 56개가 다릅니다. 서로 다른 baseline을 섞지 마세요.
4. G4는 새 방법의 주 기여로 확대하지 않고 탐색적 개발 결과로 보존합니다. 설명 오류를 고쳤다고 새 일반화·closed-loop 증거가 생긴 것은 아닙니다.
5. AutoVLA의 주 근거는 단일 driving checkpoint의 open-loop 진단입니다. connected components 6개라는 추론상의 한계는 표본 행 수를 늘려 해결할 수 없습니다.
6. 기존 SpatialVLA 결과는 과제 결과 수준의 보완 증거입니다. 두 과제 평균의 ±10 pp 결론을 과제별 동등성이나 모든 로봇 과제로 확대하지 마세요.

응답서에 ‘수정했다’고 적힌 항목은 실제 파일에서도 확인하세요. 이미 닫힌 오류를 새 연구 과제처럼 반복 구현하지 마세요.

## 2. 기여의 크기를 높일 연구 질문

논문의 중심을 다음 질문으로 정리하고, 각 주장에 대응하는 증거를 만드세요.

- RQ1 — 문맥의 기능적 영향: 출력된 과거 행동은 같게 유지하면서 조건으로 주는 행동 값만 바꾸면, 후속 행동이 얼마나·언제 달라지는가?
- RQ2 — 시간적 구조: 가장 최근 행동과 더 오래된 행동의 영향은 같은가? 주입한 변화의 크기를 고려해도 차이가 남는가?
- RQ3 — 결과와의 연결: action sequence 변화, 실제 운동 반응, task success는 각각 무엇을 보여 주는가? 어느 연결까지 실제 자료로 확인됐는가?
- RQ4 — 적용 범위: AutoVLA의 시간별 codebook token에서 관찰한 현상 중 무엇이 VLA-0의 숫자 텍스트 행동 표현에서도 관찰되는가? 공통점뿐 아니라 불일치도 보고할 수 있는가?

VLA-0의 자연 행동을 reference로 사용하는 이번 파일럿은 **문맥 민감도** 검사입니다. reference를 GT로 부르거나, donor 개입 후 자연 출력과 달라진 것을 오류·성공률 저하로 정의하지 마세요.

다음 상태표를 실제 결과로 채우세요.

| 기여 후보 | 현재 확보된 근거 | 이번 작업의 보강 | 주장 허용 조건 |
| --- | --- | --- | --- |
| 재현 가능한 paired intervention 분석 | AutoVLA matched-prefix 및 구현 검사 | VLA-0 어댑터·원시 기록·동일 의미의 contrast | 실제 parity와 본실험 기록 필요 |
| 시간 위치에 따른 문맥 영향 | AutoVLA의 latest/older 및 시간 분석 | VLA-0 최신/이전 vector 비교·시간별 반응 | source 크기·길이·표본 범위를 함께 보고 |
| 표현·과제에 걸친 공통점과 경계 | 주 근거는 AutoVLA, SpatialVLA는 보완 | 숫자 텍스트 기반 LIBERO within-call 진단 | 같은 질문을 실제 실행하고 결과가 해석 가능해야 함 |
| 행동 변화와 과제 성과의 관계 | 기존 SpatialVLA 결과 | 기존 8행 표 보강, VLA-0 후속 outcome 설계 | 새 성공률 주장은 실제 rollout 이후만 허용 |
| GT-free utility 방법 | G4 계속 기준 미달 | 탐색 결과를 정확히 보존 | 이번 작업에서는 새 방법·성능 향상 주장 금지 |

‘새 모델 한 개 추가’ 자체를 기여로 쓰지 마세요. **기존 발견을 재현하거나, 어디서 성립하지 않는지를 정량화한 결과**가 기여입니다. 현재 결과만으로 CVPR significance 문제가 해결된다고 단정하지 마세요.

## 3. 자원·가중치·loader 준비

공식 출처:

- 코드: https://github.com/NVlabs/vla0
- 논문: https://arxiv.org/abs/2510.13054
- 가중치 root: https://huggingface.co/ankgoyal/vla0-libero/tree/main
- HF export: https://huggingface.co/ankgoyal/vla0-libero/tree/main/model_last

기존 사전 점검의 code commit은 b78db19eda67b02844fe82b8929e1f94de7f2dcc, HF revision은 6c62a511ad56042b2b3ea0a90c4def33e1ea3b96 입니다. 현재 사용하는 정확한 revision을 고정하고 기록하세요. 더 새 버전을 쓰면 변경 이유와 차이를 남기세요.

공식 root의 model_last.pth는 약 15 GB이며, model_last/ HF 폴더는 약 7.53 GB입니다. 두 safetensors shard 자체는 반올림해 약 5.00+2.51 GB입니다. 폴더 전체와 shard 합의 크기를 구분하세요.

1. GPU·디스크·공유 mount·기존 cache를 실제 확인하세요. 과거 보고된 여유 약 2.3 GB는 현재 상태의 확인값이 아니며, 그대로라면 작은 export에도 부족합니다.
2. 우선 HF export 하나를 쓰는 경로를 점검하세요. model_last/와 필요한 root config.yaml, dataset_stats.pkl 등만 선택적으로 확보하세요. repository 전체 snapshot으로 15 GB pth나 평가 영상까지 함께 받지 마세요.
3. 원 wrapper의 from_pretrained(path) 경로와 config·dataset stats·processor 연결을 확인하세요. wrapper 생성 중 불필요하게 base weights를 먼저 다운로드하는지도 점검하세요.
4. HF export와 pth가 수치적으로 동일하다고 가정하지 마세요. 하나의 형식에서 공식 모델 동작을 재현하는 것이 우선입니다. pth와의 수치 동등성을 확인하지 않았으면 그대로 기록하세요.
5. 기존 프로젝트 환경을 덮어쓰지 말고 별도 환경 또는 격리된 의존성 경로를 사용하세요. RTX 5090에 필요한 torch/CUDA 호환성은 실제 설치 상태로 판단하세요.
6. quantization으로 공간·메모리를 맞춘 모델을 원 bf16 checkpoint의 재현이라고 부르지 마세요. 우선 bf16, B=1, 고정된 backend로 검사하세요.
7. 새 파일·환경·assets·다운로드 임시 공간을 포함한 필요량과 여유를 계산하세요. 사용 가능한 기존 mount를 활용하되 기존 checkpoint·원자료·다른 작업의 파일·프로세스를 삭제하거나 종료하지 마세요.
8. 공간이 없으면 BLOCKED_STORAGE로 기록하고 CPU 원고·설계·구현을 계속하세요. 재현 불가능한 삭제나 두 checkpoint의 중복 다운로드로 해결하지 마세요.

GPU는 다른 작업을 방해하지 않는 한 장을 사용하세요. 새 추론은 native 검증과 150개 파일럿을 합쳐 **GPU 점유 시간 120분 상한**으로 관리하세요. 이는 시간 추정이 아니라 이번 탐색 작업의 상한입니다. 실행 중간에 checkpoint와 진행률을 저장하고, 시간 부족이면 PARTIAL로 종료해 완료 표본만 명시하세요. 완료에 필요한 시간을 검증 관측에서 추정해 보고하세요.

## 4. GPU 전에 프로토콜과 어댑터를 고정

새 suffix 결과를 보기 전에 PROTOCOL_BEFORE_VLA0_GPU.md와 manifest를 작성하고 hash/commit으로 고정하세요. 이미 본 결과를 소급해서 사전 등록이라고 부르지 마세요.

고정할 항목:

- code/model/config/stats/tokenizer/processor revision 및 해시.
- native의 이미지 순서·회전·resize/crop·입력 history·instruction·정규화·action horizon.
- generation의 do_sample, temperature, seed, max_new_tokens, logits_processor, dtype, backend.
- 아래 표본·source 선택·길이 검사·분석 규칙·실행 상한.
- 미완료·parse 오류·source 미확보·실제 불일치의 처리 규칙.

**어댑터에서 특히 확인할 사항**

- VLA-0는 timestep별 7개 정수를 텍스트로 직렬화하는 경로가 있습니다. token 하나를 시간 step 하나로 취급하지 마세요.
- native get_one_step_action/last_action_txt 경로는 max_new_tokens, parser의 padding·truncation, 마지막 행 반환을 사용합니다. 인자로 prefix를 넣었다는 사실만으로 ‘원하는 다음 timestep’을 받았다고 가정하지 마세요. 작은 제어 입력으로 실제 반환 index를 확인하세요.
- parser는 불완전한 숫자 묶음 절단, 마지막 행동 반복 padding, 예외 시 중간값 fallback을 할 수 있습니다. 원시 text·정수 개수·범위·EOS·fallback 여부를 별도 기록하세요. 자동 보정을 정상 생성이나 새로운 행동 반응으로 세지 마세요.
- gt_out_ori_act라는 반환 필드 이름을 실제 GT의 증거로 쓰지 마세요. 코드에서 무엇이 들어가는지 확인하세요.
- sampling source를 만들 때 temperature만 설정하고 실제 do_sample은 false인 상태가 되지 않게 하세요. 최종 generation config를 기록하세요.
- full-prefix 재계산으로 올바른 causal contrast를 구현할 수 있으면 그 경로를 우선 사용하세요. 이번 파일럿에 cache 최적화를 억지로 추가할 필요는 없습니다. cache를 사용하면 별도 parity 검사가 필요합니다.

범위·수치·실행 경로가 달라지는 수정은 amendment에 기록하세요. 결과를 본 뒤에는 기준을 바꿔 같은 자료를 새 확증 실험으로 재분류하지 마세요.

## 5. 실제 native 경로 검증 — 12 observations

LIBERO spatial/object/goal 각 suite의 task index 0/3/6/9에서 초기 상태 index 0을 사용해 총 12개 관측을 준비하세요. 공식 task 목록을 저장하고 index를 정확한 이름으로 풀어 쓰세요. 해당 데이터·환경에 이 index가 없으면 결과를 보기 전에 대체 규칙과 manifest를 수정·고정하세요.

필요한 최소 simulator assets·초기 상태·두 카메라 관측만 준비하세요. 이 단계에 전체 학습 demonstration 다운로드나 학습은 필요하지 않습니다. 고정 no-op 대기·camera 처리 등은 native 평가 전처리를 따르세요.

동일 관측·instruction·B=1·greedy 설정에서 다음을 검사하세요.

1. 공식 wrapper를 통한 기본 action chunk 생성.
2. 어댑터 no-op 실행: native와 raw text/token 및 parsed action 비교.
3. self-patch: 자연 prefix를 같은 값으로 재주입했을 때, 생성된 continuation이 원래 continuation과 일치하는지 검사.
4. 강제 prefix가 정확히 7-number vector 경계에 붙는지, suffix의 첫 값이 목표 timestep인지 검사.
5. edit가 지정된 vector에만 적용되고, 보존해야 할 prefix·suffix 시작 token 위치가 맞는지 검사.
6. 원문 text, token ID, prefix hash, raw 숫자 수, parse 상태, elapsed time, peak VRAM을 저장.

최소 통과 조건:

- 12개에서 checkpoint/config/stats 연결과 native 출력 생성 완료.
- 원시 출력에서 완전한 목표 horizon을 확보하고 값 범위를 만족. padding/fallback으로 검사를 통과시키지 않음.
- no-op·self-patch의 목표 continuation token identity가 모두 일치.
- 자기 자신과 다른 source를 넣는 검사는 no-op 검사와 구분.
- emitted prefix 고정, context edit 위치·길이, suffix index invariants 위반 0.

logit 차이와 token identity는 구분해 보고하세요. 수치 차이가 있으면 같은 backend·shape·prefill 경로에서 원인을 확인하고, 허용치를 사후 확대해 token 불일치를 정상이라고 만들지 마세요.

실패하면 원인을 수정하고 같은 12개로 다시 검증하세요. 실패 장면을 바꾸지 마세요. 모델·어댑터를 바꿔야 하는 중대한 실패가 해소되지 않으면 파일럿을 실행하지 말고 BLOCKED_PARITY를 보고하세요. 정상적인 구현 수정과 재검증은 별도 사용자 확인 없이 진행하세요.

검증이 통과하면 다음 파일럿으로 바로 이어가세요.

## 6. Within-call 핵심 파일럿 — 150 observations

### 6.1 표본과 reference

- spatial/object/goal 각 10 tasks × task별 초기 상태 index 1–5 = 150 observations.
- 검증용 index 0과 구분하세요. task 수가 다르면 출력 결과를 보기 전에 manifest를 고정하고 이유를 남기세요.
- 각 관측에서 greedy native 전체 chunk A를 한 번 생성해 동결하세요. A는 자연 reference이며 expert/GT가 아닙니다.
- 현재 config에서 horizon 8, action dimension 7인지 확인하세요. 다르면 조용히 숫자만 맞추지 말고 실험 설계와 범위를 수정·기록하세요.
- 초기 관측만 쓰는 제한을 명시하세요. 이를 전체 작업 진행 구간이나 전체 LIBERO 분포의 대표 표본이라고 부르지 마세요.

### 6.2 Source bank

동일 관측과 instruction에서 최대 4개 native-format sampled chunk를 고정 seed, do_sample=true, temperature=0.7로 생성하세요. 유효 범위·문법을 만족하는 chunk만 후보로 보존하고, invalid 후보도 실패 기록에 남기세요.

- 각 대상 vector의 donor는 **후속 결과를 보기 전에**, 후보 생성 순서상 처음으로 아래 조건을 만족하는 것을 선택하세요.
- vector 전체 7개 숫자가 유효하며 reference와 실제로 다를 것.
- 정확한 prompt·구분자·prefix 안에서 retokenize했을 때 해당 vector token 길이가 reference와 같을 것.
- 나머지 고정 구간과 suffix 시작 위치가 동일하게 유지될 것.
- vector별로 다른 candidate에서 선택했다면 그 사실과 candidate ID를 기록하세요. 조합된 donor bank 전체가 모델이 자연 생성한 하나의 공동 계획이라고 주장하지 마세요.
- 후보 네 개로 source를 얻지 못하면 NO_MATCHED_SOURCE로 남기세요. 결과가 약하다고 seed·temperature·후보 수를 바꾸어 재탐색하지 마세요.

full prefix에서의 token 위치를 검사하세요. 같은 문자 수나 숫자 개수만으로 같은 token 길이라고 판정하면 안 됩니다. 특히 gripper·구분자 처리와 EOS를 확인하세요.

후속 비교에서 필요한 source가 없는 관측은 primary paired contrast에서 제외하되, 150개 전체에서 제외 이유·suite/task별 coverage·유효 표본 수를 보고하세요. 낮은 coverage를 숨기고 전체 모델에 일반화하지 마세요. 자연 reference 자기 자신으로 교체한 사례를 유효한 donor 효과로 세지 마세요.

### 6.3 동일 출력 prefix를 유지한 개입

anchor a=3을 사용합니다. 첫 3개 vector A1:A3를 **이미 출력된 행동**으로 저장하고 모든 arm에서 동일하게 유지하세요. 조건으로 제공하는 prefix만 바꾼 뒤 timestep 4–8을 생성하세요.

| Arm | 조건 prefix의 변경 | 역할 |
| --- | --- | --- |
| R | A1:A3 그대로 | reference/self-patch continuation |
| O | timestep 2 vector만 donor로 교체 | 한 단계 오래된 문맥의 영향 |
| L | timestep 3 vector만 donor로 교체 | 가장 최근 문맥의 영향 |
| OL | timestep 2와 3 교체 | 두 위치의 joint response |
| H | timestep 1과 2 교체 | 전체 older span의 보조 검사 |
| HL | timestep 1–3 교체 | older span과 latest의 보조 factorial 검사 |

동일 관측의 각 arm은 같은 frozen donor bank, prompt, generation 설정, emitted prefix를 사용하세요. reference·donor를 arm마다 새로 생성하지 마세요.

R/O/L/OL이 primary 비교입니다. H/HL은 secondary 비교이며, 모든 필요한 source를 확보한 관측에서 수행하세요. source coverage와 각 contrast의 짝 표본 수를 별도로 보고하세요.

주 개입 단위는 7-number vector 전체입니다. 숫자의 일부 자리·부호·space만 바꾸는 개입을 같은 의미의 temporal action intervention으로 섞지 마세요.

이번 개입은 출력된 과거 행동과 조건으로 읽히는 과거 행동을 의도적으로 분리한 진단입니다. 환경이 이미 그 donor 행동을 실행한 반사실적 rollout이라고 해석하지 마세요.

## 7. 분석: 무엇이 발견인지 정량화

### 7.1 필수 결과

- 각 arm의 유효 생성률·parse 오류·fallback·EOS·부족/초과 숫자 수.
- 전체 observation 수, donor 확보 수, suite/task별 paired coverage.
- suffix 4–8의 token/vector 변경률과 첫 변경 timestep.
- 각 timestep의 reference 대비 action 차이 곡선.
- L−O의 paired 차이와 H/L 비교, source 변화 크기 및 길이 일치.
- interaction의 크기와 불확실성.
- scene별 시간·peak VRAM·decode/prefill 수·후보 생성 비용.

1차 반응량은 suffix 4–8에서 각 vector의 첫 6개 action bin 좌표에 대한 reference 대비 평균 절대 차이를 num_bins_actions로 나눈 값으로 고정하세요. gripper는 별도 일치/flip 지표로 보고하세요. 좌표별·시점별 결과도 함께 보존하세요.

이 값은 정규화된 action-command 변화입니다. native 정규화 해제와 단위를 확인한 경우에만 translation/rotation 명령 변화도 보고하세요. simulator를 실행하지 않은 상태에서 실제 EE 이동 거리·운동 반응·안전 개선이라고 이름 붙이지 마세요.

### 7.2 해석을 바꾸는 제어

- O와 L은 각각 vector 하나를 교체하지만 donor 변화 크기까지 자동으로 같아지는 것은 아닙니다. 두 위치의 source 거리 분포를 반드시 비교하세요.
- 사전 고정한 보조 분석으로 source 거리 비가 0.8–1.25인 paired subset에서 L−O를 다시 보고하세요. source 거리는 같은 첫 6개 bin 좌표의 평균 절대 차이/num_bins_actions를 사용하고, 분모 0이나 gripper만 다른 경우를 별도 표기하세요.
- 이 subset도 coverage와 선택 규칙을 공개하세요. source 크기 통제가 부족하면 ‘latest가 본질적으로 더 지배적이다’로 결론 내리지 마세요.
- vector interaction은 A_OL−A_L−A_O+A_R처럼 signed action 좌표에서 정의한 뒤 크기를 보고하세요. 이미 절댓값으로 요약한 반응량의 차이를 곧바로 선형적인 action interaction이라고 부르지 마세요.
- interaction 점추정이 작거나 p>0.05라고 동등성·독립성을 주장하지 마세요. 실질적 equivalence를 주장하려면 과제적으로 정당한 margin과 별도 고정 설계가 필요합니다.
- 초기 관측에서 donor를 확보한 조건부 분포에 관한 결과라는 점을 유지하세요.

### 7.3 불확실성과 추론 단위

task를 상위 cluster로, 초기 상태를 task 내부 단위로 취급하세요. 150 observations를 token 수나 suffix step 수로 부풀리지 마세요.

paired effect와 task-cluster bootstrap 95% 구간을 제시하고 suite별 결과를 함께 보고하세요. seed와 bootstrap 횟수 10,000을 고정하세요. suite는 3개뿐이므로 ‘suite 모집단에 대한 일반화’를 bootstrap으로 확보했다고 쓰지 마세요.

primary endpoint는 L−O의 paired 정규화 반응량 차이입니다. 나머지는 secondary/descriptive로 표시하세요. 여러 endpoint를 확증적 유의성 주장으로 바꾸려면 가족과 다중 비교 규칙을 별도로 고정해야 합니다.

이번 표본은 **개발 파일럿**입니다. 효과의 부호·크기·구간·coverage를 보고하고, 통계적 유의성 하나로 확대 여부를 결정하지 마세요. 150개 전부를 완료하지 못하면 PARTIAL이며 최종 150개 결과인 것처럼 쓰면 안 됩니다.

## 8. 일반화를 축별로 구분

GENERALIZATION_MATRIX.md를 작성하세요.

| 축 | 현재/이번 실험이 추가할 수 있는 것 | 여전히 추가되지 않는 것 |
| --- | --- | --- |
| checkpoint/학습된 policy | 실제 VLA-0 결과가 생기면 AutoVLA 외 한 policy | 각 모델 내부의 여러 seed·checkpoint |
| 행동 표현 | 시간별 codebook token ↔ 숫자 텍스트 vector | 모든 action tokenizer·continuous/diffusion 정책 |
| 과제·데이터 | driving ↔ LIBERO manipulation의 within-call 진단 | 모든 주행 조건·모든 로봇 과제 |
| backbone | 두 정책이 같은 Qwen 계열을 쓰는 범위 | 별도 backbone에 대한 재현 |
| 평가 수준 | 새 모델의 command-level 반응 | 새 모델의 physical rollout·task success |
| 독립 표본·군집 | 각 데이터에서 실제 확보한 task/log/초기 상태 | 기존 AutoVLA의 6 components 문제 해소 |

AutoVLA의 기존 development/heldout 명칭이 day–vehicle 독립을 보장하지 않습니다. 저장된 ID로 split 간 log/day–vehicle/component 중복을 확인하고, 완전히 분리한 추론이 가능한지 CPU feasibility 표를 만드세요. 같은 component를 행 단위로 나눠 독립 heldout으로 부르지 마세요.

이미 저장된 예측으로 할 수 있는 범위 분석은 하되, 결과를 보고 유리한 split을 선택하거나 새 AutoVLA 대규모 추론을 시작하지 마세요. 독립 군집을 추가할 수 없다면 한계로 남기세요.

## 9. 원고 보강 — VLA-0 실행과 병행

최신 원고 source를 실제 확인하세요. 이전 TeX는 2 figures/4 tables, 최신 PDF는 8 figures/2 tables였다는 이력이 있습니다. 파일 날짜만 보고 구버전을 최신 원고에 덮어쓰지 마세요.

최신 TeX가 있으면 기존 목표인 본문 8페이지 안에서 수정하고 컴파일하세요. 없으면 진행을 멈추지 말고, 최신 PDF의 section/table/figure anchor를 기준으로 정확한 교체 문장·CSV·figure·BibTeX를 준비하세요. 오래된 TeX로 새 PDF를 만들어 최신 원고 수정본이라고 보고하면 안 됩니다.

필수 반영:

1. 제목·초록·기여 문장을 실제 검증된 정책·과제·평가 수준으로 제한.
2. 원래 발견을 긍정형으로 서술하고 반복적인 한계 문장은 한계 절로 정리. 한계 자체를 숨기지는 말 것.
3. Table 2의 day–vehicle 열과 α=0.025 근거·family 정의.
4. 직접 행동 생성 범위와 CoT 제외 수.
5. no-op/cache parity의 실제 수치와 검사 시점. exact identity와 bf16 허용 오차 검사를 구분.
6. SpatialVLA task×setting×contrast 8행 전체와 짝 단위·성공 counts·구간. 평균 효과가 과제별 무효과라는 해석 금지.
7. PDMS 버전·4초 horizon, FDE5의 5초 horizon, 공식 scorer adapter의 검증 범위. 미계산 CI를 만들지 말고 가능한 기존 원시 자료에서 적절한 paired cluster 구간을 계산.
8. 운동 반응의 +4.37/+2.35/+1.97 m 등 구간이 빠진 항목은 정확한 원자료·단위·추정량을 찾아 CI를 복원. 다른 실험의 CI 재사용 금지.
9. 내부 라벨을 독자가 이해할 이름으로 교체. 364/365 units는 서로 다른 perturbation family라는 출처를 설명.
10. retained-window 90.1%, transient 78.3%, 동일 자료 persistent 89.0%의 표본·설계·구간을 분리.
11. Figure 8의 ‘두 과제의 pool에서 선택한 move_near 예시’라는 관계를 명확히 하고 실제 case manifest와 맞춤.
12. 요청된 관련 연구 Astra, ContextVLA, FoMoVLA, Hume, LaRA-VLA, Lee et al., Puthumanaillam 및 Impromptu VLA의 정확한 논문을 원문에서 확인해 관련성을 설명. 이름이 모호하면 임의 논문으로 채우지 말고 식별 불가라고 기록.
13. nuPlan/NAVSIM, SimplerEnv, Newcombe/MOVER, sign-flip, TOST 인용의 정확한 원 출처와 적용 방법을 확인.
14. G4는 탐색적 보충 결과로 배치. negligible/no improvement/equivalent 같은 표현을 근거 없이 사용하지 말고, 수치와 사전 계속 기준 미달을 명시.

실행되지 않은 VLA-0 결과는 논문 본문의 완료된 결과로 넣지 마세요. 내부 초안의 예정 문장은 명확히 표시하고 최종 원고에서 제거하세요.

## 10. 결과에 따른 기여·다음 단계 결정

CONTRIBUTION_DECISION.md에 다음 구분을 적용하세요.

- **BLOCKED_LOAD / BLOCKED_PARITY**: 구현 준비 단계입니다. 모델 일반화 증거는 추가되지 않았습니다. 실패 원인·재현 명령·필요 자원과 완료한 원고 작업을 전달하세요.
- **PILOT_COMPLETE, 해석 가능한 반응과 충분한 coverage**: 실제로 관찰된 공통점/차이를 제시하세요. ‘모든 autoregressive VLA의 성질’이나 새 성능 방법으로 확대하지 마세요.
- **PILOT_COMPLETE, 약한 반응·넓은 구간·낮은 coverage**: 이를 부정확한 재현 성공으로 포장하지 말고, 관찰 범위와 판별되지 않은 질문을 남기세요. source/anchor를 반복 변경해 좋은 결과를 찾지 마세요.
- **AutoVLA와 다른 temporal pattern**: 오류인지 먼저 parity·source 크기·horizon을 확인한 뒤 실제 차이라면 표현/학습된 policy에 따른 경계 결과로 보고하세요.
- **새 방법 수준의 기여가 필요하지만 utility·성과 증거가 없음**: 현재 진단 논문의 목표와 별도 방법 연구를 구분하세요. gate 수치나 제목을 바꿔 이를 대체하지 마세요.

별도로 NEXT_STAGE_PROTOCOL.md를 작성하되 이번에 대규모 실행하지 마세요.

- 독립 LIBERO 초기 상태/episode를 쓰는 확증적 matched-prefix 진단의 표본 설계·불확실성 목표·예상 비용.
- VLA-0 closed-loop를 할 경우 native action_horizon=1, ensemble_prediction=8 평가 동작을 유지하는 방법. 바꾸면 별도 ablation으로 명시.
- intervention이 chunk의 어느 vector와 ensemble buffer에 반영되는지, 동일 초기 상태의 paired rollout과 no-op controls를 어떻게 구현할지.
- 실제 출력 prefix 고정과 simulator에 실행되는 행동의 관계를 분명히 할 것.
- rollout 후 달라진 상태에서 원 demonstration 행동을 유일한 GT로 취급하지 않을 것.
- 성공률·충돌·운동 반응 등 실제 계산 가능한 지표, 독립 단위, episode 수 산정과 시간·저장 공간 예산.
- 더 큰 기여를 위해 무엇이 추가로 필요한지 구체화: task outcome 연결, 독립 driving 군집, 별도 backbone 중 현재 가장 큰 증거 공백 하나를 우선순위로 제안. 여러 모델을 무작정 추가하는 계획 금지.

이 후속 계획은 실행 전 검토할 별도 단계입니다. 이번 12+150 관측 실험을 그 계획서만 쓰는 것으로 대체하지 마세요.

## 11. 최종 전달물과 완료 조건

하나의 CVPR_VLA0_AND_CONTRIBUTION_20261020 패키지로 정리하세요.

- README.md: 무엇을 실제 실행했는지, 전체 상태, 핵심 수치, 재현 명령.
- DECISION_SUMMARY.md: 실행 검증, 파일럿 결과, 기여·일반화에 생긴 변화와 남은 공백.
- PROTOCOL_BEFORE_VLA0_GPU.md, manifest, 고정 hash/commit 및 amendments.
- 실행 가능한 loader/adapter/validation/pilot/analysis 코드와 필요한 최소 제어 검사.
- native 검증 12개와 pilot 관측별 원시 기록: text/tokens/prefix/donor/arm/action/parse/비용.
- 검증 summary, coverage 표, task/suite별 paired effect·구간·source 크기 통제 표.
- suffix timestep별 action-command 반응 그림: PDF/SVG와 원 데이터.
- CLAIM_EVIDENCE_MAP.md, GENERALIZATION_MATRIX.md, CONTRIBUTION_DECISION.md.
- PAPER_READY_UPDATES.md, 본문용/보충용 table CSV, 검증된 references.bib.
- NEXT_STAGE_PROTOCOL.md.
- INPUTS_AND_ENVIRONMENT.md, 실제 포함 파일만 대상으로 한 OUTPUT_HASHES.json.

README에서 다음을 분리하세요.

1. 파일만 작성한 항목.
2. CPU 검사만 수행한 항목.
3. 실제 GPU로 수행한 관측 수와 native parity 결과.
4. 실제 effect를 계산한 paired observation 수.
5. 이번 결과가 뒷받침하는 주장과 아직 뒷받침하지 못하는 주장.

최종 보고는 실행 완료 수, 오류·제외·coverage, 주 effect와 구간, 기여에 대한 결정, 가장 필요한 후속 실험 한 가지를 먼저 제시하세요.

추정 소요 시간·VRAM을 실측으로 쓰거나, mock output을 실제 모델 결과로 보고하거나, 소수 관측의 parity를 논문 일반화의 완성으로 표현하지 마세요. 실행이 막혀도 독립적으로 가능한 원고·CPU 분석·어댑터 구현은 끝까지 완료하세요.
