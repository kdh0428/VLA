# CVPR_VLA0_AND_CONTRIBUTION_20261020

Execution of CODING_AGENT_VLA0_CONTRIBUTION_GENERALIZATION_20261020.md. Start with DECISION_SUMMARY.md.

## Headline
- **Native validation (12 obs): PASS** on attempt 4 (attempt 3 failed self-patch identity with a prefill path → fixed by forced
  decoding through the native KV path; AMENDMENTS.md).
- **Pilot: 150/150 executed, 149 analysed** (1 incomplete reference excluded); donor coverage 149/149 for each vector.
- **Primary L − O = +0.0137 [0.0115, 0.0157]** (normalised command response; task-cluster bootstrap, 30 tasks); distance-matched
  +0.0154 [0.0120, 0.0190]; signed interaction −0.0011 [−0.0038, 0.0013].
- **Decision: PILOT_COMPLETE** — same qualitative temporal pattern as AutoVLA at command level; no outcome/success, same backbone.
- Most needed next: independent driving clusters (all AutoVLA splits share 5 day–vehicle components); VLA-0 confirmatory run
  (states 6–25) is the next model-side step (NEXT_STAGE_PROTOCOL.md).

## What was done, by kind
1. Files only: NEXT_STAGE_PROTOCOL.md, GENERALIZATION_MATRIX.md, CLAIM_EVIDENCE_MAP.md, CONTRIBUTION_DECISION.md, paper/PAPER_READY_UPDATES.md.
2. CPU only: LIBERO observation rendering (162), analysis + bootstrap, figure, AutoVLA split-overlap table, PDMS cluster-t intervals
   (paper/pdms_paired_cluster_t.csv), motion-excess interval provenance.
3. Real GPU: 12 validation observations (4 attempts; native parity PASS on attempt 4) + 150 pilot observations; 78.1 min final run
   (+ ≈ 8 min failed attempts); RTX 5090, bf16, B = 1.
4. Effect computed on 149 paired observations (30 task clusters).
5. Supported: "with emitted actions fixed, the latest conditioning vector changes VLA-0's generated continuation more than an older
   one (command level, initial LIBERO states, own-sample donors)". Not supported: success/utility, physical motion, backbone
   generality, AutoVLA cluster independence, any method claim.

## Reproduce
```bash
source /root/VLA/openvla/env.sh   # LIBERO, robosuite, Mesa EGL
python scripts/vla0_prepare_obs.py --manifest manifest_validation_12.json --out obs
python scripts/vla0_prepare_obs.py --manifest manifest_pilot_150.json --out obs
# weights: huggingface ankgoyal/vla0-libero@6c62a51 model_last/ -> /dev/shm/vla0/model_last (see INPUTS_AND_ENVIRONMENT.md)
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1 python scripts/vla0_run.py --val-manifest manifest_validation_12.json \
  --pilot-manifest manifest_pilot_150.json --obs obs --out run --enable-new-inference --release-shm-weights --gpu-cap-min 112
python scripts/vla0_analyze.py run/pilot/records.jsonl analysis; python scripts/vla0_figure.py analysis
```
Contents: PROTOCOL_BEFORE_VLA0_GPU.md, PROTOCOL_LOCK.json, AMENDMENTS.md, manifests, scripts/, run/ (validation + pilot raw records:
text, token ids, prefixes, donors, arms, audits, latency, VRAM), run_attempt3_validation_FAIL/, obs/, analysis/ (coverage, paired
per observation, timestep curves, effects), figures/, tables/ (AutoVLA split overlap), paper/, INPUTS_AND_ENVIRONMENT.md,
OUTPUT_HASHES.json. Latest manuscript TeX (sha256 4991781…) is not on the server; no PDF was rebuilt.
