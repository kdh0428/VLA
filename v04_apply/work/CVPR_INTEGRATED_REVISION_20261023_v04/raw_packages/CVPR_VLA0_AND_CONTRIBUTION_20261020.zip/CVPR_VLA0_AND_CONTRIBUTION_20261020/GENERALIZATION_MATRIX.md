# GENERALIZATION_MATRIX (filled after the VLA-0 run; see DECISION_SUMMARY.md for the numbers)

| Axis | Added by this work (if the pilot completed) | Still not added |
|---|---|---|
| checkpoint / learned policy | one policy beyond AutoVLA (VLA-0 LIBERO fine-tune, HF export) at command level | several seeds/checkpoints per model; numerical identity of the HF export vs the .pth |
| action representation | temporal codebook tokens (AutoVLA) ↔ space-separated integer text vectors (VLA-0, 1–4 digit tokens per number) | other tokenizers (FAST/BPE), continuous / diffusion heads |
| task / data | driving open-loop ↔ LIBERO manipulation initial observations, within-call | other LIBERO suites (10/90), later episode states, other robots |
| backbone | none: both use Qwen2.5-VL-3B | a different backbone family |
| evaluation level | VLA-0 normalised action-command response | VLA-0 physical rollout / success; closed-loop driving |
| independent clusters | 30 LIBERO tasks (task clusters) | AutoVLA independence: all AutoVLA splits share the same 5 day–vehicle components (tables/autovla_split_components.csv); dev/heldout share 12 day–vehicle pairs, P1-C shares 32 logs with each best-of-N split |
