# CLAIM_EVIDENCE_MAP

| Contribution candidate | Evidence before | Added now | Claim allowed |
|---|---|---|---|
| Reproducible paired intervention analysis | AutoVLA matched prefix + parity gates | VLA-0 adapter with native-path validation (12/12 token identity via forced decoding; prefill path failed), raw records for 150 obs | "the matched-prefix diagnostic was implemented natively in a second VLA with integer-text actions" |
| Temporal position of context | AutoVLA latest/older, I ≈ 0 | VLA-0: L − O +0.0137 [0.0115, 0.0157], matched-distance +0.0154, signed I −0.0011 [−0.0038, 0.0013] | "in both models the latest action-context value has the larger conditional effect on the continuation; adding an older edit does not change it on average" — command level, development pilot, own-sample donors |
| Shared pattern vs boundaries across representations/tasks | AutoVLA primary, SpatialVLA outcomes | driving codebook tokens ↔ LIBERO integer text, both within-call | report commonality AND that VLA-0 evidence is command-level only, initial observations, same backbone |
| Action change vs task outcome | SpatialVLA 8 rows (success ±10 pp on two-task mean only) | none for VLA-0 (no rollout) | no new success claim |
| GT-free utility method | G4 STOP | — | no method / performance claim |
