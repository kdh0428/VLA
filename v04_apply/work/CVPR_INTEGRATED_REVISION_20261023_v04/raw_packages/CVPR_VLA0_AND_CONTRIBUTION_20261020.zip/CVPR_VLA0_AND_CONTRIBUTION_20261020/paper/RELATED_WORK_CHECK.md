# Related work check (D3 + addendum 6) — arXiv metadata verified 2026-10-20; **abstract-level reading only** (no full text read)

Metadata (title, authors, version, date, comment) from the arXiv API: `arxiv_metadata_20261020.json`; BibTeX:
`related_work_verified.bib`. Existing manuscript bib = `references.bib` in CVPR_20261019_source.zip (17 entries, 9 cited).

| Item | arXiv / source | Verified title (year) | Status vs manuscript | Direct relevance / positioning (1–2 sentences) |
|---|---|---|---|---|
| FAST | 2501.09747 v1 | FAST: Efficient Action Tokenization for Vision-Language-Action Models (2025) | **actual omission** | Compressed DCT/BPE action tokens: earlier tokens are lower frequencies of the same chunk, so a within-call token edit is not a time-local edit; our edits act on time-local 0.5 s motion codes. Cite where the scope of "action-token context" is defined. |
| TraceVLA | 2412.10345 v3 | TraceVLA: Visual Trace Prompting … (2024) | omission; moderate | Input-side trace conditioning (visual history), not emitted-action-token history; useful contrast for "context" definitions. |
| Spatial Traces | 2508.09032 v1 | Spatial Traces: Enhancing VLA Models with Spatial-Temporal Understanding (2025) | low relevance | Input-side trace conditioning; optional. |
| Hybrid Training | 2510.00600 v2 (ICLR 2026) | Hybrid Training for Vision-Language-Action Models (2025) | low–moderate | Training-time use of reasoning/intermediate outputs; not an action-context intervention study. Optional. |
| GaussVLA | 2608.24959 v1 (BMVC 2026) | GaussVLA: Geometry-Aware Spatial Reasoning … (2026) | low relevance | Spatial representation; not needed. |
| AVA-VLA | 2511.18960 v4 (CVPR 2026 Highlight) | AVA-VLA: … Active Visual Attention (2025) | low–moderate | Recurrent/visual-attention state across steps; contrast with explicit action-token history. Optional. |
| SmolVLA | 2506.01844 v1 | SmolVLA: … Affordable and Efficient Robotics (2025) | low relevance | Chunked/asynchronous execution; cite only if chunked execution is discussed. |
| VLA survey | 2405.14093 v8 | A Survey on Vision-Language-Action Models for Embodied AI (2024) | omission (background) | One background citation for VLA families is sufficient. |
| Token Steering | 2606.15021 v1 | Steering Autoregressive VLA Policies via Action Token Intervention (2026) | **already cited** (`chan2026tokensteering`; bib matches title/authors) | Closest method: user/explicit steering by action-token edits. Our work is a diagnostic of how edits propagate through context, not a steering method. |
| CMA | 2609.27247 v1 | Memory That Changes Action Is Not Memory That Guides It … (2026) | **already cited** (`zhang2026memoryaudit`; 3 authors, matches) | Separates memory sensitivity from guidance/utility; aligns with our split of output change vs correctness vs success. |
| TRUST | 2610.00601 v1 | When Reasoning Helps Action: Monitoring and Steering CoT in VLA Policies (2026) | omission; **directly relevant to G** | Predicts when reasoning helps and steers selectively; G's gain gate is close in spirit (predict benefit before acting) — a novelty claim for G is not supported. |
| INSIGHT | 2510.01389 v2 | INSIGHT: INference-time Sequence Introspection for Generating Help Triggers … (2025) | omission; **directly relevant to G** | Token-uncertainty-based help triggers ≈ our entropy/risk gates; cite as baseline family. |
| ContextVLA | 2510.04246 v1 | ContextVLA: VLA Model with Amortized Multi-Frame Context (2025) | omission; moderate | Multi-frame observation context, not action-token history; contrast for "context". |
| FoMoVLA | 2607.14739 v1 | FoMoVLA: Bridging Visual Foresight and Motion Guidance … (2026) | low–moderate | Foresight/motion guidance; optional. |
| Hume | 2505.21432 v4 | Hume: Introducing System-2 Thinking in VLA Model (2025) | moderate (value-guided candidate selection) | System-2 value-guided candidate selection ≈ best-of-k critic baseline for G. |
| LaRA-VLA | 2602.01166 v2 (ICML 2026) | Latent Reasoning VLA: Latent Thinking and Prediction … (2026) | low–moderate (CoT scope) | Latent CoT; relevant only to the adaptive-reasoning scope note (addendum 1). |
| Astra | ambiguous (2512.08931 world model; 2408.01147 embodied transformer; "GPT-6 Astra" in 2609.34261/2610.08995) | — | **unidentifiable** | Several unrelated "Astra" works; not added without the reviewer's exact reference. |
| Lee et al. | — | — | **unidentifiable** | Name only; not added. |
| Puthumanaillam | author has several 2023–2026 arXiv papers on trajectory diffusion / planning | — | **unidentifiable** (no VLA paper matched) | Not added without the exact title. |
| Impromptu VLA | 2505.23757 v1 | Impromptu VLA: Open Weights and Open Data for Driving VLA Models (2025) | **in bib (`chi2025impromptu`) but not cited** although named in the text and Supp. G | Add `\citep{chi2025impromptu}` at first mention. |
| NAVSIM | 2406.15349 v2 (NeurIPS 2024 D&B) | NAVSIM: Data-Driven Non-Reactive AV Simulation and Benchmarking | **actual omission** (data/metric source) | Cite for navtest scenes, PDMS. Pseudo-simulation / EPDMS = `cao2025pseudosim` (in bib, not cited). |
| nuPlan | 2106.11810 v4 | NuPlan: A closed-loop ML-based planning benchmark … (2021) | **actual omission** (data source) | Cite for logs/maps. |
| SimplerEnv | 2405.05941 v1 | Evaluating Real-World Robot Manipulation Policies in Simulation (2024) | **actual omission** (simulator) | Cite for the SpatialVLA tasks. |
| Newcombe | Newcombe (1998) Stat. Med. | paired-difference intervals (method 10) | **actual omission**; implementation = Newcombe-10 + Rao–Scott design effect (adapted, not the plain method) | Cite with "design-effect-adjusted". Not verified online in this run. |
| MOVER | Zou & Donner (2008) Stat. Med. | MOVER combination | **actual omission** | Cite for task-equal combination. Not verified online. |
| sign-flip | `winkler2015multilevel` (in bib, not cited) | Multi-level block permutation (2015) | in bib, not cited | Our implementation: exact enumeration of cluster-total sign flips at δ = 0; cite Winkler et al. for exchangeability-block reasoning. |
| TOST | `lakens2017equivalence` | cited in supplement | already cited | Our margins use corrected paired intervals, not t-based TOST → describe as "interval inclusion (TOST-equivalent)". |

Positioning sentence (main text, suggested): *"Unlike action-token steering methods that edit tokens to change behaviour
[chan2026tokensteering] and memory audits that separate sensitivity from guidance [zhang2026memoryaudit], we measure how a
controlled edit of time-local action-token context propagates into later generation, physical motion and success; compressed
action tokenizers such as FAST [pertsch2025fast] would require a different, frequency-domain notion of a local edit."*
