# Change and deviation record (v02)

## Before the GPU run (all locked in PROTOCOL_LOCK_CL_v02.sha256 at 2026-10-21T07:36:50Z)
- **Environment.** OpenVLA's `site/` shadows transformers (old version, no Qwen2.5-VL). The closed loop therefore uses the autovla env plus `site_libero/`, which symlinks **only** the packages missing from the autovla env: robosuite, mujoco, bddl, gym, easydict, OpenGL and others (list in `site_libero_links.txt`). See `env_cl.sh`.
- **Observation path.** The official `libero_to_rv_obs` needs lerobot, which is not installed. It is replaced by a raw-image pass-through, and the model wrapper uses the pilot adapter path. Stage 1 checked native-forward equality on closed-loop observations: 16/16.
- **CPU dry run.** `scripts/dryrun_cpu.py` was run with a fake policy and no model: official loop + env + logger, bitwise state replay, float32 buffers, and an ensemble check against a manual computation.

## After the run (analysis only; the harness and its outputs were not changed)
- **`vla0_cl_analyze.py` quaternion angle.** Before the final analysis the formula changed from `2·arccos(|q1·q2|)`, which gave 1e-7 rad for bitwise-identical quaternions through rounding, to the exact `4·atan2(‖q1−q2‖, ‖q1+q2‖)` (sign-aligned). It was unit-tested on a 0.3 rad rotation, identical inputs, and q vs −q. Only interim output (U1) was seen with the old formula.
- **`vla0_cl_figure.py`.** A shorter y-axis label.
- **`analysis/cl_window_summary.csv` and `cl_cost_by_call_kind.json`.** Computed by an inline script that is reproduced in `scripts/vla0_cl_window_summary.py`.

## Runs
One GPU attempt (`run/attempt1`). No re-runs, no seed changes, and no unit or configuration re-selection.
