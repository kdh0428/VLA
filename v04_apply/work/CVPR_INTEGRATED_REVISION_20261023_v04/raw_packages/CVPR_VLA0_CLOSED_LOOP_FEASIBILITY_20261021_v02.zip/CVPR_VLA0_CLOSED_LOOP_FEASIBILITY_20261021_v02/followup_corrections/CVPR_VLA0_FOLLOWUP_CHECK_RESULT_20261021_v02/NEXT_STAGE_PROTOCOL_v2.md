# NEXT_STAGE_PROTOCOL v2 — 2026-10-21 (replaces the section order of pkg/NEXT_STAGE_PROTOCOL.md; nothing here is executed on GPU)

The question for the next stage is: **does the context-only change reach executed actions and actual motion?** Increasing the precision of the open-loop L − O is not the goal, because the pilot already meets the earlier precision target. Accordingly:
- The closed-loop feasibility path (§1) **may proceed from the 149-observation pilot plus the path checks below**.
- The 600-observation open-loop reproduction (§3) is optional and is **not** a prerequisite.
- The old heading "only if 1" is withdrawn.

## 0. Entry conditions for §1
| condition | status |
| --- | --- |
| Runner resume protection, fail-fast fingerprint, strict validation gate (CPU negative controls) | **done**, ALL_PASS (`RUNNER_FIX_20261021.md`) |
| Official ensemble index/weight/buffer update read and replayed on CPU with stored chunks | **done** (`BUFFER_REPLAY_REPORT.md`) |
| Closed-loop configuration fixed in advance | **fixed here**: README LIBERO command (action_horizon 1, ensemble_prediction 8, ensemble_version 1, frame_skip 10, seed 7) |
| Single-process (or bridged) LIBERO env + VLA-0 model smoke test | not done (§1 Stage 1) |
| Explicit permission and GPU budget in the next prompt | required; this package used no GPU |

What the CPU replay established for this configuration:
- A context-only edit leaves the first three executed actions after the edited call unchanged.
- Each edited call contributes exactly 1/9 of its suffix difference at executed offsets 3–7.
- If the edit is applied at every replan, the steady-state executed change is about 0.85 of the chunk-mean difference.
- The executed gripper command never changed.

These results assume a stationary context; real feedback is what §1 measures.

## 1. Bounded closed-loop feasibility (VLA-0, LIBERO) — protocol only
- **Stage 1: engineering smoke (≤ 15 GPU-min).**
  - LIBERO, robosuite and EGL live in /root/VLA/openvla's environment; the model runs in the autovla environment. The step loop needs either one process or a bridge. The upstream rv_train/deploy service is a candidate, unverified.
  - The official `eval_run` loop must be used unchanged.
  - Run one episode, N arm only, 16 executed steps. Log per-step: observation hash, model text, decoded chunk, ensemble buffer, executed action, EE pose, simulator state hash.
- **Stage 2: paired path check (hard cap 150 GPU-min; estimate ≈ 110).**
  - Units: 4 (suite, task, init-state) units from initial states 6–7, which are not used anywhere so far. Selection rule fixed in advance: libero_spatial task 0, libero_object task 5, libero_goal task 0, libero_goal task 5.
  - Arms, all sharing one trajectory until the edit replan:
    - **N** natural.
    - **R** self-patch at every replan (the no-op).
    - **L** context-only vector-3 edit at every replan from replan 8: donor from a 4-sample T = 0.7 source bank, the pilot's donor rule; the executed chunk is natural vectors 1–3 plus the edited suffix.
    - **O** the same with vector 2.
  - Window: 48 executed steps after the frame skip; full episodes are not run.
  - Cost: generate calls per step are N 1, R 2, L/O 3 (native + source bank + forced). At the measured median 3.79 s per call that is ≈ 27 GPU-min per unit, plus env time (unmeasured).
- **Stage 2 measurements and stop rules:**
  - **M1 no-op.** R must equal N bitwise in every executed action and state hash. A failure means **STOP**.
  - **M2 buffer consistency.** The logged executed actions must equal an offline CPU replay of the logged chunks through `eval_run` (the harness in `scripts/vla0_buffer_replay.py`, given logged chunks). A failure means **STOP**.
  - **M2b simulator determinism.** Replaying N's logged actions on CPU (no model) must reproduce N's state hashes.
  - **M3 motion.** Report, per step: EE position difference ‖p_L − p_N‖ and ‖p_O − p_N‖ in m, orientation difference, gripper state, and the first divergence step (CPU expectation: edit replan + 3). Also report the L − O motion difference. These are descriptive per-unit traces; with n = 4 there is no hypothesis test.
  - **M4 cost.** Report s/step per arm and peak VRAM.
- **Ground truth.** After the arms' actions differ, the demonstration is **not** treated as ground truth. All comparisons are arm vs arm. Success flags are logged but not analysed as an effect.
- **Stage 3: task-outcome evaluation.** It is designed only after Stage 2 and gets its own preregistration: endpoint, configuration, and an episode count derived from the Stage-2 divergence and paired discordance. The P1-D figure of ≈ 300 per arm is not transferable. Do not start a large success-rate experiment before Stages 1–2 pass.

## 2. AutoVLA cluster independence (unchanged, scope clarified)
The 147-log day–vehicle graph is reproduced: each split alone has 6 components; the union of splits and all 147 logs have 5. This reproduction is separate from the candidate-data independence search, and the two must not be merged into one claim. The search is the local audit `review_followup5/C_DISJOINT`, copied with its scripts to `audit_source_C_DISJOINT/`. Its status is `BLOCKED_NO_DISJOINT_DATA`, and it covers the five inspected sources only:
- OpenScene v1.1 test;
- navmini;
- warmup_test_e2e;
- NAVSIM v2 navhard two-stage;
- OpenScene private_test_hard (anonymised).

It is **not** an exhaustive search of all public driving data.

## 3. Optional: frozen-protocol open-loop reproduction on unseen initial states
This is the former §1: 600 observations, initial states 6–25, ≈ 4–5 GPU-h. It is justified only as a reproduction on unseen initial states, not as a precision step. It is not required for §1.
