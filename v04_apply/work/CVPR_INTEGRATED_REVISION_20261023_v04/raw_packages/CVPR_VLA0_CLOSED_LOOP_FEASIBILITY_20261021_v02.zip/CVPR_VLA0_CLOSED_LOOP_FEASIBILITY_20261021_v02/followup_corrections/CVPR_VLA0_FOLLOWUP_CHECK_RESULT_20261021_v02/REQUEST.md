# VLA-0 후속 패키지 검토 — 2026-10-21

대상: CVPR_VLA0_AND_CONTRIBUTION_20261021.zip

ZIP SHA-256: ffc3c81b621271938e9a2958ccc1aba07ceb7a0e9558ec469e4ea7be73804eb8

## 1. 판단

**이전 검토의 핵심 해석 수정과 사후 분석은 정확히 반영됐습니다.** 원시 모델 출력은 이전 패키지와 같으며, 이번 전달물은 CPU 분석·문서·향후 실행 코드 보완입니다. 새 일반화 실험이나 closed-loop 성과가 추가된 것은 아닙니다.

주 결과 L−O = +0.013679 [0.011513, 0.015694]는 유지됩니다. 이번에는 추가된 사후 결과와 147-log 군집 그래프도 독립 재계산했습니다.

다만 향후 GPU 실행 전에 고칠 **재개 보호와 validation gate의 제어 흐름 문제**가 남아 있습니다. 이는 현재 149개 파일럿의 수치가 잘못됐다는 의미가 아닙니다.

## 2. 직접 확인한 수정

| 항목 | 확인 |
| --- | --- |
| 파일 무결성 | 해시 목록 219개 전부 존재·일치 |
| 기존 모델 기록 | validation/pilot records, 관측, 주 효과·그림은 이전 파일과 동일 |
| 상호작용 해석 | additivity, older의 추가 영향 없음, AutoVLA I≈0 재현이라는 주장을 철회 |
| 조건부 older 효과 | mean abs(A_OL−A_L)/1000 = 0.0152248 [0.0133076, 0.0172660], 149개 / 30 tasks 재현 |
| 거리 요약 차이 | D_OL−D_L = −0.0006678 [−0.0019874, +0.0006663] 재현 |
| 같은 prefix token 집합 subset | L−O = +0.0148612 [0.0119566, 0.0179802], 79개 / 29 tasks 재현 |
| 위 조건 + source 거리 통제 | +0.0170392 [0.0128977, 0.0218372], 40개 / 22 tasks 재현 |
| OL과 L의 완전 일치 | suffix 정수 35개가 모두 같은 관측 1/149 재현 |
| 사후 분석 표시 | 추가 분석을 post hoc으로 명시, 원래 149개/66개 분석과 구분 |
| 600개 근거 | 기존 정밀도 목표를 현재 파일럿이 이미 충족한다고 정정 |
| 원고 자료 | VLA-0 삽입 문장 item 15 추가. TeX 편집·컴파일 미수행 사실 명시 |

사후 bootstrap 구간은 같은 seed라도 앞에서 난수를 소비한 순서가 달라지면 조금 달라질 수 있습니다. 이번 D_OL−D_L 구간은 새 script의 순서로 재현됐습니다. 추정량·반복 수·seed·호출 순서를 함께 보존하면 됩니다.

주요 문서의 수정 방향은 타당합니다. 최신 vector가 preceding vector보다 큰 반응을 만든다는 공통점은 유지하되, interaction이나 outcome의 전체 재현으로 확대하지 않습니다.

## 3. 군집 그래프의 6개와 5개: 이제 재현됨

제공된 log_membership_navtest147.csv의 147개 고유 log에서 날짜와 차량을 각각 node로 두고, day–vehicle pair를 edge로 하는 graph를 새로 구성했습니다.

| 자료 | logs | 해당 자료만의 components | 합친 graph에서 닿는 components |
| --- | ---: | ---: | ---: |
| best-of-N development | 56 | 6 | 5 |
| best-of-N heldout | 52 | 6 | 5 |
| development mechanism | 26 | 6 | 5 |
| P1-C / B2 자료 | 64 | 6 | 5 |
| 위 4개 split의 합집합 | — | 5 | 5 |
| 제공된 navtest 147 logs | 147 | 5 | 5 |

20개 고유 day–vehicle edges, component labels, component별 log 수와 scene 합계도 저장 표와 일치했습니다.

따라서 이전의 6개와 이번의 5개는 서로 다른 graph 범위 때문에 생긴 차이입니다. 자료를 합치면서 추가된 edges가 기존 components를 연결합니다.

해석도 바로잡혔습니다.

- component를 통째로 분리하는 holdout은 가능합니다.
- 현재 자료에서 사용할 수 있는 상위 독립 components의 수가 적고 크기도 불균형합니다.
- 행이나 split을 재배치해 독립 components의 총수를 늘릴 수는 없습니다.

다만 ‘전체 후보 데이터 중 독립 자료가 더 있는지’에 관한 원격 metadata audit 원본은 이번 ZIP에 없습니다. 제공된 147-log graph의 재현과, 모든 후보 데이터의 독립성 탐색 완료를 같은 검증으로 부르면 안 됩니다.

## 4. 남은 실행 코드 문제: CPU 제어 검사로 재현

첨부 코드를 GPU 없이 실행하기 위해 필요한 함수·summary 분기를 AST로 추출하고, 임시 폴더와 synthetic records로 아래 제어 흐름만 검사했습니다. 모델을 로딩하거나 기존 결과를 변경하지 않았습니다.

### 4.1 Fingerprint가 없는 기존 결과 폴더를 새 실행으로 받아들임

현재 흐름은 다음과 같습니다.

1. 모델 로딩.
2. RUN_FINGERPRINT.json이 있으면 mismatch 비교.
3. 파일이 없으면 새 fingerprint와 run_meta를 기록.
4. pilot의 기존 obs_id는 완료된 것으로 보고 건너뜀.

CPU 검사에서 **기존 pilot 기록이 있지만 fingerprint는 없는 폴더**를 제공하자:

- 새 fingerprint가 기록됐습니다.
- 기존 run_meta가 덮어써졌습니다.
- 과거 pilot 기록은 남았습니다.
- validation/pilot 진행이 허용됐습니다.

이는 이전 실행을 새 코드로 수행한 것처럼 묶을 수 있습니다. 특히 README의 재현 명령이 기존 run 폴더를 대상으로 하므로 고쳐야 합니다.

수정 조건:

- 기존 결과가 있는데 fingerprint가 없으면 자동 채택하지 말고 중단.
- 완료한 과거 run에는 fingerprint를 소급해 만들어 붙이지 않음.
- 실제 재현은 새로운 출력 폴더 사용.
- fingerprint 불일치·미존재 검사는 모델 로딩과 RAM-backed weight 삭제, metadata 덮어쓰기보다 먼저 수행.
- CPU 검사에서 mismatch인 경우에도 현재는 model-load 함수가 먼저 호출됐습니다. fail-fast 순서를 바꾸세요.

또 현재 fingerprint의 weights_index는 실제 weight 값의 hash가 아닙니다. 장래 실행에서 model identity를 보장하려면 실제 shards를 로딩 전에 streaming hash로 확인하거나, 검증한 shard hash와 고정 revision을 기록하세요. tokenizer/processor와 upstream 코드 식별도 연결하는 것이 좋습니다.

### 4.2 새 strict gate가 validation의 최종 PASS 판정에 연결되지 않음

개별 기록에는 새로 다음 검사가 추가됐습니다.

- arms_complete_exact35_eos
- arm_invariants
- 실패 시 status=CHECK_FAILED

그런데 마지막 VALIDATION_SUMMARY 작성 분기는 예전 gate 목록만 사용합니다.

CPU negative control로 다음 synthetic 기록을 넣었습니다.

- 예전 native/prefix/self-patch gates: 모두 true.
- arms_complete_exact35_eos=false.
- arm_invariants=false.
- status=CHECK_FAILED.

그런데 최종 summary가 **PASS**였습니다. 새 검사를 통과하지 않은 validation 뒤에 pilot을 시작할 수 있는 구조입니다.

수정 조건:

- 최종 validation PASS에 새 strict gates와 status=OK를 포함.
- donor 검사가 필요한데 수행되지 않은 경우를 default true로 통과시키지 않음. donor 미확보의 정책을 명시.
- exact-35 위반, EOS 없음, invariant 실패가 각각 최종 FAIL로 이어지는 CPU negative control을 추가.

현재 149개 기록에서는 모든 arm이 실제로 35개 정수와 EOS를 만족하고 invariants도 정상입니다. 이 코드 문제를 이유로 기존 수치를 폐기하거나 같은 150개를 다시 추론할 필요는 없습니다.

## 5. 다음 연구 단계

**600개 초기 관측 확장보다, context-only 변화가 실제 실행 행동에 연결되는지를 확인하는 작은 VLA-0 closed-loop feasibility를 우선 검토하는 편을 권합니다.**

이유는 현재 주 결과의 정밀도가 부족해서라기보다, 아직 command 변화와 물리적 운동·task outcome의 연결이 비어 있기 때문입니다. 성공률 향상을 보장하는 제안은 아닙니다.

순서:

1. 위 두 실행 보호 문제를 CPU에서 수정·검증.
2. 공식 ensemble 코드의 index·가중치·buffer 갱신을 확인.
3. 저장된 natural/edited chunk로 CPU buffer replay를 해, suffix 교체가 실제 실행 action에 언제·얼마나 들어가는지 먼저 확인.
4. 그 경로가 맞으면 소수 paired rollout으로 환경 state와 buffer의 일치, no-op identity, 실제 운동 차이와 비용을 확인.
5. 그 뒤 별도 목적·표본 수를 가진 task-outcome 평가를 설계.

현재 anchor=3에서는 처음 3개 출력 vector를 유지합니다. edited chunk의 첫 action 자체는 바뀌지 않으므로, suffix가 ensemble에 저장·사용되는 경로를 확인해야 합니다. 실제 영향 시점은 공식 구현을 읽고 buffer replay로 검증하세요. 이를 확인하지 않고 곧바로 대규모 성공률 실험을 시작하지 마세요.

NEXT_STAGE_PROTOCOL §2의 제목은 아직 ‘only if 1’로 돼 있어, §1의 600개 실험을 먼저 해야 하는 것으로 읽힙니다. §3의 ‘small closed-loop feasibility 우선 검토’와 맞춰 **이번 149개 파일럿 및 경로 검증으로 진행할 수 있는 별도 단계**로 고치세요.

새 실험을 하더라도 서로 다른 행동이 실행된 이후 demonstration 행동을 유일한 GT로 취급하면 안 됩니다.

## 6. 코딩 에이전트에게 바로 전달할 수정 지시

이번 패키지의 원시 기록과 완료된 연구 결과는 보존하세요. 다음 CPU 작업을 먼저 완료하세요.

1. nonempty legacy output + missing fingerprint를 거부하고, mismatch 검사도 model load 전에 수행하도록 수정.
2. completed run의 metadata를 소급해 교체하지 않도록 방지하고 README 재현 출력 폴더를 새 경로로 변경.
3. 최종 validation gate에 status·exact-35/EOS·invariants를 연결.
4. 위 두 문제의 CPU negative controls와 정상 fresh-run/same-fingerprint-resume 경로를 확인.
5. 새로운 코드·fingerprint 개선은 ‘향후 실행용 수정’으로 표시. 기존 149개가 그 코드로 실행됐다고 소급해서 쓰지 않음.
6. NEXT_STAGE_PROTOCOL의 closed-loop 진입 조건을 정리.
7. 공식 ensemble을 사용한 CPU buffer replay 계획 또는 실행 가능한 작은 harness를 준비하고, 실제 GPU rollout은 별도 bounded protocol과 비용으로 구체화.

상호작용 해석·주 수치·graph 계산을 다시 처음부터 반복할 필요는 없습니다. 이번 CPU 보완을 마치면 연구의 다음 질문은 **‘이 문맥 변화가 실행 행동과 실제 운동까지 도달하는가?’**입니다.
