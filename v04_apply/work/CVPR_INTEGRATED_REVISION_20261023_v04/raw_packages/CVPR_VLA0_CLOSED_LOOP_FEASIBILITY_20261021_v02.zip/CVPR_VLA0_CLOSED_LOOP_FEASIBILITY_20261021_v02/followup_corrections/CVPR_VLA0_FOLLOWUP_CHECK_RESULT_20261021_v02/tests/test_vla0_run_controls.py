"""CPU negative controls for vla0_run.py (2026-10-21 fixes). Mocks the model loader and the GPU loops; temporary dirs only; no model
weights loaded; synthetic records exist only inside the test and are deleted."""
import argparse, json, os, shutil, sys, tempfile, types
RESULT_PATH = os.path.abspath(sys.argv[1])   # saved before the controls rewrite sys.argv (v02 fix)
sys.path.insert(0, "/root/VLA/vla0_work/scripts")
import vla0_run as RUN
V = RUN.V
res, calls = {}, {"build_actor": 0, "run_mode": []}


def fake_build_actor(device="cuda:0"):
    calls["build_actor"] += 1
    gc = types.SimpleNamespace(to_dict=lambda: {"do_sample": True, "temperature": 1e-6, "repetition_penalty": 1.05})
    return types.SimpleNamespace(model=types.SimpleNamespace(generation_config=gc), num_tokens=1024), {}, {}


def fake_run_mode(a, kv, mode, manifest, obs, out, t_start, cap):
    calls["run_mode"].append(mode)
    os.makedirs(out, exist_ok=True)
    if mode == "validate":
        json.dump({"status": "PASS"}, open(os.path.join(out, "VALIDATION_SUMMARY.json"), "w"))


def run(out, extra=()):
    sys.argv = ["vla0_run.py", "--val-manifest", "/root/VLA/vla0_work/manifest_validation_12.json", "--pilot-manifest",
                "/root/VLA/vla0_work/manifest_pilot_150.json", "--obs", "/x", "--out", out, "--enable-new-inference", *extra]
    try:
        RUN.main(); return None
    except SystemExit as e:
        return str(e)


def rec(**over):
    c = {k: True for k in ["native_text_equal", "native_parsed_equal", "raw_complete", "prefix_retokenises_to_generated",
                          "prefix_equals_vector_concat", "selfpatch_token_identity", "suffix_starts_at_timestep4",
                          "arms_complete_exact35_eos", "arm_invariants", "donor_check_invariants"]}
    status = over.pop("status", "OK")
    for k, v in over.items():
        if v is None:
            c.pop(k)
        else:
            c[k] = v
    return {"obs_id": "x", "status": status, "checks": c}


tmp = tempfile.mkdtemp(prefix="vla0ctl_")
try:
    # sandbox weights with the verified hashes cannot be faked -> patch VERIFIED_SHARDS to dummy shard hashes
    W = os.path.join(tmp, "weights"); os.makedirs(W)
    for f in RUN.VERIFIED_SHARDS:
        open(os.path.join(W, f), "w").write(f)
    for f in RUN.TOKENIZER_FILES:
        shutil.copy(os.path.join(V.HF, "model_last", f), W)
    V.WEIGHTS = W
    RUN.VERIFIED_SHARDS = {f: RUN._h(os.path.join(W, f)) for f in RUN.VERIFIED_SHARDS}
    V.build_actor = fake_build_actor
    RUN.run_mode = fake_run_mode
    # C1 legacy output (records, no fingerprint) -> refuse BEFORE model load, nothing overwritten
    leg = os.path.join(tmp, "legacy"); os.makedirs(os.path.join(leg, "pilot"))
    open(os.path.join(leg, "pilot", "records.jsonl"), "w").write('{"obs_id": "old"}\n')
    open(os.path.join(leg, "run_meta.json"), "w").write('{"old": true}')
    b0 = calls["build_actor"]
    res["C1_legacy_refused"] = run(leg)
    res["C1_model_not_loaded"] = calls["build_actor"] == b0
    res["C1_run_meta_untouched"] = json.load(open(os.path.join(leg, "run_meta.json"))) == {"old": True}
    res["C1_no_fingerprint_written"] = not os.path.exists(os.path.join(leg, "RUN_FINGERPRINT.json"))
    # C2 fresh run -> fingerprint + run_meta written, validate then pilot
    fr = os.path.join(tmp, "fresh")
    res["C2_fresh_run_exit"] = run(fr)
    res["C2_fingerprint_written"] = os.path.exists(os.path.join(fr, "RUN_FINGERPRINT.json"))
    res["C2_modes"] = list(calls["run_mode"])
    meta0 = open(os.path.join(fr, "run_meta.json")).read()
    # C3 same-fingerprint resume -> allowed, validation not repeated, run_meta not overwritten
    calls["run_mode"].clear()
    res["C3_resume_exit"] = run(fr)
    res["C3_modes"] = list(calls["run_mode"])
    res["C3_run_meta_unchanged"] = open(os.path.join(fr, "run_meta.json")).read() == meta0
    # C4 mismatch (manifest changed via a copy) -> refuse before model load
    fp = json.load(open(os.path.join(fr, "RUN_FINGERPRINT.json"))); fp["config_yaml"] = "0" * 64
    json.dump(fp, open(os.path.join(fr, "RUN_FINGERPRINT.json"), "w"))
    b0 = calls["build_actor"]
    res["C4_mismatch_refused"] = run(fr)
    res["C4_model_not_loaded"] = calls["build_actor"] == b0
    # C5 tampered weight shard -> refuse before load
    open(os.path.join(W, list(RUN.VERIFIED_SHARDS)[0]), "a").write("x")
    b0 = calls["build_actor"]
    res["C5_bad_weights_refused"] = run(os.path.join(tmp, "fresh2"))
    res["C5_model_not_loaded"] = calls["build_actor"] == b0
    # C5b tokenizer/processor file differs from the persistent revision copy -> refuse before load
    open(os.path.join(W, list(RUN.VERIFIED_SHARDS)[0]), "w").write(list(RUN.VERIFIED_SHARDS)[0])   # restore shard
    open(os.path.join(W, "tokenizer_config.json"), "a").write(" ")
    b0 = calls["build_actor"]
    res["C5b_tokenizer_mismatch_refused"] = run(os.path.join(tmp, "fresh3"))
    res["C5b_model_not_loaded"] = calls["build_actor"] == b0
    # C6 validation_summary negative controls
    S = lambda rs: RUN.validation_summary(rs, len(rs))["status"]
    res["C6_all_good"] = S([rec(), rec()])
    res["C6_exact35_or_eos_false"] = S([rec(), rec(arms_complete_exact35_eos=False)])
    res["C6_invariant_false"] = S([rec(arm_invariants=False)])
    res["C6_status_check_failed"] = S([rec(status="CHECK_FAILED")])
    res["C6_donor_missing"] = S([rec(donor_check_invariants=None)])
    res["C6_old_gates_true_new_false_checkfailed"] = S([rec(arms_complete_exact35_eos=False, arm_invariants=False, status="CHECK_FAILED")])
    res["C6_missing_record"] = RUN.validation_summary([rec()], 2)["status"]
finally:
    shutil.rmtree(tmp, ignore_errors=True)
    res["temporary_files_deleted"] = not os.path.exists(tmp)
expect_pass = (res["C1_legacy_refused"] and res["C1_model_not_loaded"] and res["C1_run_meta_untouched"] and res["C1_no_fingerprint_written"]
               and res["C2_fresh_run_exit"] is None and res["C2_fingerprint_written"] and res["C2_modes"] == ["validate", "pilot"]
               and res["C3_resume_exit"] is None and res["C3_modes"] == ["pilot"] and res["C3_run_meta_unchanged"]
               and res["C4_mismatch_refused"] and res["C4_model_not_loaded"] and res["C5_bad_weights_refused"] and res["C5_model_not_loaded"]
               and res["C5b_tokenizer_mismatch_refused"] and res["C5b_model_not_loaded"]
               and res["C6_all_good"] == "PASS" and all(res[k] == "FAIL" for k in ("C6_exact35_or_eos_false", "C6_invariant_false",
               "C6_status_check_failed", "C6_donor_missing", "C6_old_gates_true_new_false_checkfailed", "C6_missing_record"))
               and res["temporary_files_deleted"])
res["ALL_PASS"] = bool(expect_pass)
print(json.dumps(res, indent=1)); json.dump(res, open(RESULT_PATH, "w"), indent=1)
