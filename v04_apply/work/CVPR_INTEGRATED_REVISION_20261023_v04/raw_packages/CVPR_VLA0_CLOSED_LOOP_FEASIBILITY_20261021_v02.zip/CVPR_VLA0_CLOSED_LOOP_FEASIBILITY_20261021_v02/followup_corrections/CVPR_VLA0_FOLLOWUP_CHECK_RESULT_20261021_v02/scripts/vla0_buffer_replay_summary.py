"""Summarise CPU buffer replay (POST HOC). Task-cluster bootstrap (B=10000, seed 20261021) for executed-action L-O."""
import json, os, sys
import numpy as np, pandas as pd
D = sys.argv[1]
import gzip
_p = os.path.join(D, "replay_rows.json")
df = pd.DataFrame(json.load(gzip.open(_p + ".gz", "rt") if not os.path.exists(_p) else open(_p)))
pre = df[df.offset == "pre"]
pers = df[df.offset == "persistent_steady"]
ps = pers.groupby(["config", "variant", "arm"]).agg(steady_exec_abs_d=("exec_abs_d_arm6", "mean"), chunk_abs_d_mean=("chunk_abs_d_arm6_mean", "mean"),
     steady_const_all=("steady_const", "all"), n=("obs_id", "nunique")).reset_index()
ps["steady_ratio_vs_chunk_mean"] = ps.steady_exec_abs_d / ps.chunk_abs_d_mean
ps.to_csv(os.path.join(D, "replay_persistent_steady.csv"), index=False)
print(ps.round(5).to_string())
post = df[~df.offset.isin(["pre", "persistent_steady"])].copy(); post["offset"] = post.offset.astype(int)
out = {"pre_injection_max_abs_diff": float(pre.exec_abs_d_arm6.max())}
tab = post.groupby(["config", "variant", "arm", "offset"]).agg(exec_abs_d_arm6=("exec_abs_d_arm6", "mean"),
      grip_changed_frac=("exec_grip_changed", "mean"), chunk_abs_d_at_index=("chunk_abs_d_arm6_at_index", "mean"), n=("obs_id", "nunique")).reset_index()
tab.to_csv(os.path.join(D, "replay_by_offset.csv"), index=False)
# per-observation total executed change over the window, and first executed offset with a change
g = post.groupby(["config", "variant", "arm", "obs_id", "task"])
per = g.apply(lambda x: pd.Series({"exec_sum": x.exec_abs_d_arm6.sum(),
      "first_change_offset": (x[x.exec_abs_d_arm6 > 0].offset.min() if (x.exec_abs_d_arm6 > 0).any() else np.nan),
      "chunk_sum": x.chunk_abs_d_arm6_at_index.dropna().sum()})).reset_index()
per.to_csv(os.path.join(D, "replay_per_obs.csv"), index=False)
summ = per.groupby(["config", "variant", "arm"]).agg(exec_sum_mean=("exec_sum", "mean"), chunk_sum_mean=("chunk_sum", "mean"),
       first_change_offset_min=("first_change_offset", "min"), first_change_offset_median=("first_change_offset", "median"),
       n_obs=("obs_id", "nunique"), n_any_exec_change=("first_change_offset", lambda s: int(s.notna().sum()))).reset_index()
summ["transmission_ratio"] = summ.exec_sum_mean / summ.chunk_sum_mean
summ.to_csv(os.path.join(D, "replay_summary.csv"), index=False)
rng = np.random.default_rng(20261021)
lo = []
for (c, v), x in per.groupby(["config", "variant"]):
    w = x.pivot_table(index=["obs_id", "task"], columns="arm", values="exec_sum").dropna(subset=["L", "O"]).reset_index()
    w["d"] = w.L - w.O
    tasks = w.task.unique(); by = {t: w[w.task == t].d.values for t in tasks}
    bs = []
    for _ in range(10000):
        s = rng.choice(tasks, len(tasks)); v_ = np.concatenate([by[t] for t in s]); bs.append(v_.mean())
    lo.append({"config": c, "variant": v, "L_minus_O_exec_sum": float(w.d.mean()), "ci95": [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
               "n_obs": len(w), "n_tasks": len(tasks)})
out["L_minus_O_executed"] = lo
json.dump(out, open(os.path.join(D, "replay_contrasts.json"), "w"), indent=1)
pd.set_option("display.width", 250); print(summ.round(5).to_string()); print(json.dumps(out, indent=1))
print(tab[(tab.config == "readme_ah1_ens8_v1") & (tab.variant == "context_only") & (tab.arm == "L")].round(5).to_string())
print(tab[(tab.config == "evalfn_default_ah5_ens1") & (tab.variant == "context_only") & (tab.arm == "L")].round(5).to_string())
