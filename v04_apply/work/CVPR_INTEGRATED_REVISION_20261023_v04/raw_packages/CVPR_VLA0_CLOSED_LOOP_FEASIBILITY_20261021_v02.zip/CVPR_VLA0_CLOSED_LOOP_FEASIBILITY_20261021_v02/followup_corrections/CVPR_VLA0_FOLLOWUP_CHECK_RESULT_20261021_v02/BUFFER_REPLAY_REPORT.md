# CPU buffer replay — does a context-only VLA-0 edit reach executed actions? (POST HOC, 2026-10-21)

**What this is.** A CPU-only check of the *path* from a stored chunk to `env.step()`. It does **not** measure physical motion, environment feedback, or task outcome, and it used no GPU, no new model inference and no simulator physics.

**How (`scripts/vla0_buffer_replay.py`, `scripts/vla0_buffer_replay_summary.py`):**
- The official `eval_run` from `roboverse/evals/libero/eval.py` @ b78db19 is run verbatim.
  - It was extracted via AST. eval.py is byte-identical to the pinned tarball (sha256 61b8d46c…; eval_run source sha256 45a0c699…).
- A mock env only records `env.step(action)`, and a mock model returns stored chunks.
- Text → action uses the official `QwenActor.get_action_from_text_action` with the checkpoint's dataset_stats.
- Inputs: the 149 analysed pilot observations and their stored arms O, L, OL, H, HL. The R (self-patch) chunk is the baseline.
- Every non-injected replan returns the same R chunk. This assumes a stationary context with no env feedback.
- Executed-chunk variants:
  - **context_only:** natural vectors 1–3 plus the arm's suffix (vectors 4–8). The edit lives only in the conditioning; this is the closed-loop analogue of the pilot's question.
  - **as_forced:** the arm's prefix, including the edited vector, plus the suffix.
- Configurations:
  - README LIBERO command: action_horizon 1, ensemble_prediction 8, version 1.
  - Version 2 with weight 0.5.
  - `eval_libero.py` default: action_horizon 0 → horizon 8, no ensemble.
  - `eval()` keyword default: action_horizon 5, no ensemble.
- Injection modes:
  - Single replan: injected once the 8-chunk buffer is full (ah 1), or at the 3rd replan (ah 5 or 8).
  - Persistent: every replan from then on, reported as the steady state.

## No-op and sanity checks (all passed)
- R chunk equals the decoded reference chunk: 149/149.
- Injecting R itself leaves executed actions bitwise identical: 596/596 (149 × 4 configs).
- Executed actions before the injected replan never differ (max |Δ| = 0).

## When and how much (single injection, context_only; |Δ| = mean over the 6 arm dims, LIBERO action units)

| config | executed offsets that change | weight of chunk Δ at those offsets | L: mean executed |Δ| per step | L: summed over window (chunk-level sum) |
| --- | --- | --- | --- | --- |
| README ah1 ens8 v1 | 3, 4, 5, 6, 7 (never 0–2) | exactly 1/9 (transmission 0.1111 for every arm) | 0.0045–0.0050 | 0.0237 (0.2130) |
| ah1 ens8 v2 (w 0.5) | 3–7 | smaller (≈ 0.02 overall) | — | 0.0051 (0.2130) |
| default ah8 (no ensemble) | 3–7 executed directly | 1 | 0.041–0.045 | 0.2130 (0.2130) |
| eval() default ah5 | 3, 4 only; suffix vectors 6–8 are never executed | 1 at 3–4, 0 at 5–7 | 0.041 | 0.0822 (0.2130) |

- **context_only.** The first three executed actions after the edited call never change: offsets 0–2, the timesteps kept by anchor 3. Under the README configuration the suffix enters the executed command only through the ensemble. Each edited call contributes 1/9 of its suffix difference at offsets 3–7: weight 0.5 against a normaliser of 1 + 0.5·7 = 4.5. It is therefore diluted about 9-fold for a single edited call.
- **Persistent edit.** If the edit is applied at every replan, the steady state is constant (README configuration). The executed |Δ| per step is then 0.0227 for L and 0.0118 for O, about 0.85 of the chunk-mean |Δ| (`replay_persistent_steady.csv`).
- **Gripper.** The executed gripper command (snapped to ±1 by the official loop) never changed, in any configuration, arm or variant.
- **as_forced.** Here the edited vector itself is executed, so changes start at offset 0 for H (vector 1), 1 for O, and 2 for L.

## L − O in executed-action space (post hoc; task-cluster bootstrap, B = 10000, seed 20261021; 149 obs / 30 tasks)

| config | context_only | as_forced |
| --- | --- | --- |
| README ah1 ens8 v1 | +0.01098 [0.00901, 0.01296] | +0.01143 [0.00940, 0.01345] |
| ah1 ens8 v2 | +0.00281 [0.00237, 0.00327] | −0.00073 [−0.00150, +0.00006] |
| default ah8 | +0.09882 [0.08107, 0.11646] | +0.10288 [0.08433, 0.12155] |
| eval() ah5 | +0.04765 [0.04013, 0.05540] | +0.05172 [0.04318, 0.06037] |

**Reading.** Under the stationary-context assumption, the chunk-level "latest > older" response survives into the executed command for the README configuration and both no-ensemble defaults, scaled by the configuration's weights. In the version-2 *as_forced* case the sign is not preserved: there the older edit is executed earlier and with more weight. Which configuration the closed-loop study uses therefore changes the size of the executed effect by an order of magnitude, so it must be fixed in advance.

**Not shown.** Real closed-loop behaviour (the next context differs once actions differ), physical end-effector motion, and task outcome. These need the bounded GPU protocol (`NEXT_STAGE_PROTOCOL_v2.md` §2).

Files: `buffer_replay/replay_meta.json`, `replay_noop_checks.json`, `replay_rows.json.gz` (row level), `replay_by_offset.csv`, `replay_per_obs.csv`, `replay_summary.csv`, `replay_persistent_steady.csv`, `replay_contrasts.json`. Re-running the summary script on the gz file reproduced replay_contrasts.json byte for byte.

## v02 clarifications (2026-10-21, after review v02)
- **Endpoint units.** The executed-space L − O above is the L − O of mean |action_arm − action_R|, *summed over the evaluation window after one injection*. It is not on the same scale as the pilot's normalised-bin mean difference (+0.01368), and the two numbers must not be read as an effect-retention ratio.
- **Sign.** context_only is positive in all four configurations. The only negative point estimate is ensemble v2 **as_forced**, which is a different intervention. It must not be described as "the context-only latest advantage reverses under ensemble v2".
- **Stationary assumption.** The persistent steady state (L ≈ 0.02267, O ≈ 0.01182; ≈ 0.85 / 0.83 of the chunk-mean difference) holds only if every later observation and chunk is unchanged. Real closed-loop feedback is measured separately (CVPR_VLA0_CLOSED_LOOP_FEASIBILITY_20261021_v02).
- **dtype.** This replay converted decoded chunks to float64. The official path is float32 (`get_action_from_text_action` → `.numpy()`), and the float64 no-op checks do not stand in for a float32 bitwise check. The closed-loop package's offline replay uses the logged float32 chunks.
- **Reproduction dependencies.** The official eval.py, config.yaml and dataset_stats.pkl were not in the earlier zip. They are now under `repro_deps/` (eval.py is CC BY-NC 4.0, NVIDIA; unmodified).
