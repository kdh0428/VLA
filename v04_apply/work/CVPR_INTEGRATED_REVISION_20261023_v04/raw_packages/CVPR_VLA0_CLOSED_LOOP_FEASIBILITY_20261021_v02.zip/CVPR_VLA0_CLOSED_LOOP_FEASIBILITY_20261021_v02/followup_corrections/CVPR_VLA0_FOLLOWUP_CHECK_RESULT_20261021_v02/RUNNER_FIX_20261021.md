# Runner fix (future executions only) — 2026-10-21

**Scope.** These are fixes to `vla0_run.py` for *future* GPU runs. The completed 149-observation pilot and the 12-observation
validation in `CVPR_VLA0_AND_CONTRIBUTION_20261021.zip` were **not** produced by this code and are not re-labelled as such (original run: packaged runner e9c0bafb…, no runtime fingerprint; see the lineage table). Their
raw records, run_meta.json and gpu_time.json are unchanged. No fingerprint was attached to the completed run retroactively.

**Runner lineage (corrected v02):**

| stage | sha256 | meaning |
| --- | --- | --- |
| runner in the first GPU result package (CVPR_VLA0_AND_CONTRIBUTION_20261020.zip) | e9c0bafb13c246ea836a0927aea65b65c109ae0719b75ec02e1a49455b73377f | code tied to the original GPU run report and amendments; the run recorded no runtime fingerprint |
| runner of the next CPU-revised package / BEFORE here | 45943fc3d6f072115fcd8046f6a9ad4cc4b4951e5f84149efe7a1c98a6fcfd4f | CPU revision in which the control-flow problems were found; it writes the strict fields in each row, which the original records lack, so it did not produce them |
| AFTER here | 4a18f2e53f847c705fbaa2d26e398341b239e6f6149a8127d5b7f5ca323e3890 | future-execution fix tested by the CPU controls |

The raw pilot records are byte-identical in both earlier packages (sha256 51a0f96e…).

Files: `scripts/vla0_run_BEFORE_20261021fix.py` (sha256 45943fc3…, identical to `scripts/vla0_run.py` inside the reviewed zip
ffc3c81b…), `scripts/vla0_run_AFTER_20261021fix.py` (sha256 4a18f2e5…; also the live copy at /root/VLA/vla0_work/scripts/vla0_run.py),
`scripts/vla0_run_20261021fix.diff`.

## 4.1 Resume protection and fingerprint

| Problem (review §4.1) | Fix |
| --- | --- |
| Non-empty output with no RUN_FINGERPRINT.json was accepted; a new fingerprint was written and run_meta overwritten | `preflight()` refuses it: "output dir has results but no RUN_FINGERPRINT.json (legacy/completed run): refuse; use a NEW --out directory" |
| Mismatch check ran after model loading (and after /dev/shm weight release) | `preflight()` runs first in `main()`, before `build_actor()`, before weight release, before any write |
| Metadata could be overwritten on resume | Fresh run: writes RUN_FINGERPRINT.json + run_meta.json. Same-fingerprint resume: writes only `run_meta_resume_<time>.json`; a PASS validation summary is not re-run; gpu_time is written to a timestamped file |
| `weights_index` hashed the index json, not weights | Streaming sha256 (16 MB chunks) of both actual shards **before loading**, required to equal the HF LFS hashes of ankgoyal/vla0-libero@6c62a511 (2021480f…, 2fd9786a…, recorded in INPUTS_AND_ENVIRONMENT.md); otherwise exit |
| Tokenizer/processor and upstream code not linked | Every tokenizer/processor/config file in the load directory (tokenizer.json, tokenizer_config.json, vocab, merges, added/special tokens, chat_template, preprocessor_config, generation_config, config, index) must be byte-identical to the persistent revision copy hf_6c62a51/model_last; the upstream tarball must have sha256 b8c1ce72… (b78db19). All are recorded in the fingerprint with the HF revision and upstream commit |
| README reproduction targeted the existing `run` folder | New command uses a new folder (`REPRO_COMMANDS_v2.md`). The live check `preflight(--out /root/VLA/vla0_work/run)` was executed read-only and refused the completed run folder (its file list was unchanged afterwards) |

## 4.2 Validation gate

`validation_summary(records, n_expected)` now decides the final PASS. PASS requires: the record count equals the manifest, every record
has `status == "OK"`, and every gate is literally `True`. Gates: native_text_equal, native_parsed_equal, raw_complete,
prefix_retokenises_to_generated, prefix_equals_vector_concat, selfpatch_token_identity, suffix_starts_at_timestep4,
**arms_complete_exact35_eos**, **arm_invariants**, **donor_check_invariants**.

`arm_invariants` itself no longer defaults to True: every edited arm (all except the self-patch R) must carry
`invariant_len is True` and `invariant_outside is True`.

**Donor policy (explicit).** Each validation observation needs the different-source donor check. A missing donor is a missing gate,
so the result is FAIL; the old default of True is removed. The 12 completed validation observations all had donors for vector 3.
The summary lists the failed gates for each observation.

## CPU negative controls (`tests/test_vla0_run_controls.py` → `tests/test_vla0_run_controls_result.json`)

*(corrected v02)*: the earlier zip saved the result as `tests/--val-manifest`, because the script re-read `sys.argv[1]` after the controls had rewritten `sys.argv`. The result path is now captured at start. The re-run gives the same content, ALL_PASS. The misnamed file is kept as `tests/superseded_misnamed_result_--val-manifest.json`.

Setup: the model loader and GPU loops are mocked; work happens in temporary directories, deleted afterwards; no weights are loaded.
For the sandbox, the shard hashes are replaced by those of dummy shards.

| Control | Expected | Observed |
| --- | --- | --- |
| C1 legacy folder (pilot records + run_meta, no fingerprint) | refuse before model load; run_meta untouched; no fingerprint written | refused, model not loaded, run_meta untouched, no fingerprint |
| C2 fresh run | fingerprint + run_meta written; validate → pilot | yes; modes [validate, pilot] |
| C3 same-fingerprint resume | allowed; validation not repeated; run_meta unchanged | modes [pilot]; run_meta unchanged |
| C4 fingerprint mismatch | refuse before model load | refused; model not loaded |
| C5 tampered weight shard | refuse before model load | refused; model not loaded |
| C5b tokenizer_config differs from revision copy | refuse before model load | refused; model not loaded |
| C6 all gates true, status OK | PASS | PASS |
| C6 exact-35/EOS false | FAIL | FAIL |
| C6 arm_invariants false | FAIL | FAIL |
| C6 status CHECK_FAILED | FAIL | FAIL |
| C6 donor check missing | FAIL | FAIL |
| C6 review's negative control (old gates true, new false, CHECK_FAILED) | FAIL (was PASS before the fix) | FAIL |
| C6 record missing (1 of 2) | FAIL | FAIL |
| temporary files deleted | yes | yes |

**ALL_PASS = true.** These controls test control flow only. A real GPU run with the new runner has not been executed.

**Post hoc audit of the completed records** (`tests/posthoc_strict_audit_completed_records.json`, read-only, CPU). The
completed validation records predate the new fields, so they carry no `arms_complete_exact35_eos` / `arm_invariants` keys. Under the
new gate they would read as *missing*, which is why the old validation is **not** relabelled as a new-gate PASS. When the same
definitions are recomputed from the stored audits, the results are:
- validation: 12/12 status OK, exact-35 + EOS in all arms, invariants in all edited arms;
- pilot: 149/150 status OK; the same 149 satisfy exact-35 + EOS and the invariants.

The `vla0_analyze.py` strictness for exact-35/EOS (applied on 2026-10-21) is unchanged. All 149 analysed pilot records satisfy exact-35 + EOS and the invariants. The existing numbers do not depend on this code fix, so the 150 observations were not re-inferred.
