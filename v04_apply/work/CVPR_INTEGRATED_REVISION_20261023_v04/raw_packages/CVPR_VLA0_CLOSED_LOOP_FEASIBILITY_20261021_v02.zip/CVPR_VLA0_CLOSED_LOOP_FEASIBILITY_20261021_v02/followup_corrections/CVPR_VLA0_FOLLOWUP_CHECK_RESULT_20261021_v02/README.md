# CVPR_VLA0_FOLLOWUP_CHECK 대응 결과 — 2026-10-21

대상 검토: `REQUEST.md` (= /root/VLA/CVPR_VLA0_FOLLOWUP_CHECK_20261021.md). 검토 대상 ZIP은 CVPR_VLA0_AND_CONTRIBUTION_20261021.zip이며, SHA-256 ffc3c81b…로 일치함을 확인했습니다.

**이번 작업 범위**
- 전부 CPU로 수행했습니다. GPU는 사용하지 않았고 새 모델 추론도 하지 않았습니다.
- 기존 원시 기록과 결과 파일(149개 pilot, 12개 validation, run_meta 등)은 수정하지 않았습니다. 과거 run에 fingerprint를 소급해 붙이지도 않았습니다.
- 커밋은 하지 않았습니다.
- 사후(post hoc) 분석에는 post hoc이라고 표시했습니다.

## §6 지시 항목별 결과
| # | 지시 | 결과 | 문서 |
| --- | --- | --- | --- |
| 1 | 비어 있지 않은 legacy 출력에 fingerprint가 없으면 거부, mismatch 검사는 model load 전에 | 완료. `preflight()`가 model load·weight 해제·메타데이터 기록보다 먼저 실행됨 | RUNNER_FIX_20261021.md |
| 1′ | weight identity | 실제 shard 2개를 로딩 전에 streaming sha256으로 검증. HF revision 6c62a511, tokenizer/processor 파일, upstream tarball(b78db19)을 fingerprint에 연결 | 같음 |
| 2 | 완료된 run의 metadata 소급 교체 방지, README 재현 출력 경로 변경 | resume 시 기존 run_meta를 덮어쓰지 않음. 재현 명령은 새 폴더(`run_repro_<stamp>`)를 사용. 실제 `vla0_work/run`에 preflight를 걸어 거부됨을 확인(읽기 전용) | REPRO_COMMANDS_v2.md |
| 3 | 최종 validation gate에 status, exact-35/EOS, invariants 연결 | `validation_summary()`가 status==OK, 10개 gate가 모두 True, 기록 수 일치를 요구. donor 미확보는 FAIL. `arm_invariants`의 default True도 제거 | RUNNER_FIX_20261021.md |
| 4 | CPU negative control + fresh-run/same-fingerprint resume 경로 | 14개 control 모두 기대대로 동작(ALL_PASS). 리뷰의 synthetic 사례(옛 gate는 True, 새 gate는 False, CHECK_FAILED)는 이제 FAIL | tests/ |
| 5 | 새 코드는 ‘향후 실행용 수정’으로 표시 | 표시함. *(v02 정정)* 기존 149개 기록은 최초 GPU 패키지의 runner(e9c0bafb…, runtime fingerprint 없음)로 생성된 것이며, 45943fc3…는 이후 CPU 수정판이라 이 기록을 만들지 않았음. 새 정의로 사후 감사한 결과 validation 12/12, pilot 149/150 충족 | RUNNER_FIX §post hoc audit |
| 6 | NEXT_STAGE_PROTOCOL의 closed-loop 진입 조건 정리 | ‘only if 1’ 철회. closed-loop feasibility가 149개 파일럿과 경로 검증만으로 진행 가능한 별도 단계가 됨. 600개 확장은 선택 사항 | NEXT_STAGE_PROTOCOL_v2.md |
| 7 | 공식 ensemble로 CPU buffer replay, bounded GPU protocol과 비용 | **CPU replay 실행**(공식 `eval_run` 원문 사용). GPU rollout은 계획만 작성: 4 units, 상한 150 GPU-분, 추정 약 110분 | BUFFER_REPLAY_REPORT.md, NEXT_STAGE_PROTOCOL_v2 §1 |

## Buffer replay 핵심 결과 (post hoc, stationary context 가정, 물리 운동·outcome은 측정하지 않음)
README 공식 설정(action_horizon 1, ensemble 8, version 1) 기준입니다.

- **도달 시점과 비중:** context-only edit은 편집된 call 직후 실행 action 0–2에는 영향이 없습니다. 영향은 offset 3–7에서만 나타나고, 그 비중은 정확히 1/9입니다.
- **매 replan마다 편집할 때:** 정상상태에서 실행 |Δ|는 L 0.0227, O 0.0118로, chunk 평균 차이의 약 0.85입니다.
- **gripper:** 실행 gripper 명령은 한 번도 바뀌지 않았습니다.
- **실행 공간의 L−O (task-cluster bootstrap):** +0.0110 [0.0090, 0.0130].
  - ensemble을 쓰지 않는 기본값(ah8)에서는 +0.099입니다.
  - ensemble v2의 as_forced 변형에서는 −0.0007 [−0.0015, +0.0001]로, 부호가 유지되지 않습니다.
  - 따라서 closed-loop 설정을 사전에 고정해야 합니다(README 설정으로 고정함).
- **no-op 검사:** 모두 통과했습니다. R 청크와 reference 청크가 149/149 일치하고, R 주입 시 실행 action이 596/596에서 bitwise 동일합니다.

## 그 밖에
- **§3 독립 자료 audit:** 로컬 원본 `review_followup5/C_DISJOINT`를 스크립트와 함께 `audit_source_C_DISJOINT/`에 복사했습니다. 이 audit은 점검한 5개 출처만 다루며, 전체 공개 주행 데이터를 망라한 탐색이 아닙니다. 147-log graph 재현과 이 audit을 하나의 검증으로 부르지 않습니다.
- **수치:** 주 수치, 상호작용 해석, graph 계산은 다시 하지 않았습니다(리뷰에서 재현됨).

## 파일
- `REQUEST.md`: 검토 원문.
- `RESPONSE_20261021.md`: 항목별 대응(영문).
- `RUNNER_FIX_20261021.md`
- `BUFFER_REPLAY_REPORT.md`
- `NEXT_STAGE_PROTOCOL_v2.md`
- `REPRO_COMMANDS_v2.md`
- `scripts/`
  - vla0_run 수정 전·후 버전과 diff.
  - `vla0_buffer_replay.py`, `vla0_buffer_replay_summary.py`.
- `tests/`
  - runner control 스크립트와 결과.
  - 완료 기록의 사후 strict 감사.
- `buffer_replay/`: replay 결과.
- `audit_source_C_DISJOINT/`
- `OUTPUT_HASHES.json`

live 코드 `/root/VLA/vla0_work/scripts/vla0_run.py`는 수정 후 버전(sha 4a18f2e5…)으로 교체했습니다. 수정 전 버전은 `scripts/vla0_run_BEFORE_20261021fix.py`에 보존돼 있으며, 이전 ZIP 안의 파일과 동일합니다.
