"""CPU buffer replay (2026-10-21, POST HOC, no GPU, no simulator physics).

Question: when a stored context-edited VLA-0 chunk replaces the natural chunk at ONE replanning step, which executed actions change,
when, and by how much, under the OFFICIAL LIBERO evaluation loop (NVlabs/vla0 @ b78db19, roboverse/evals/libero/eval.py::eval_run)?

* `eval_run` is taken verbatim from the upstream file via AST (its source sha256 is recorded; the file is checked against the
  pinned tarball) and executed with a mock env that only records env.step(action) and a mock model that returns stored chunks.
* Text -> action decoding uses the official QwenActor.get_action_from_text_action with the checkpoint's dataset_stats.
* All other replanning steps return the R (self-patch) chunk of the same observation: a STATIONARY-CONTEXT assumption with no
  environment feedback. This isolates the buffer/ensemble path only; it says nothing about physical motion or task outcome.
Executed-chunk variants:
  A "context_only": natural (reference) vectors 1-3 + arm suffix (vectors 4-8)  -> the edit lives only in the model context
  B "as_forced":    arm prefix (with the edited vector) + arm suffix
"""
import ast, hashlib, json, os, sys, tarfile, types
import numpy as np

WORK = "/root/VLA/vla0_work"
sys.path.insert(0, os.path.join(WORK, "scripts"))
import vla0_adapter as V  # noqa: E402  (CPU import only; no model is built)
from vla0_analyze import suffix, ACT, H, ANCHOR  # noqa: E402

EVAL = os.path.join(V.REPO, "libs/RoboVerse/roboverse/evals/libero/eval.py")
TAR = os.path.join(WORK, "vla0_b78db19.tar.gz")
OUT = sys.argv[1]
ARMS = ["O", "L", "OL", "H", "HL"]
CONFIGS = {  # (action_horizon, ensemble_prediction, ensemble_version, ensemble_2_weight)
    "readme_ah1_ens8_v1": (1, 8, 1, 0.5),      # README LIBERO eval command
    "ah1_ens8_v2_w0.5": (1, 8, 2, 0.5),
    "default_ah8_ens1": (8, 1, 1, 0.5),       # eval_libero.py default: action_horizon 0 -> cfg horizon 8
    "evalfn_default_ah5_ens1": (5, 1, 1, 0.5),  # eval() keyword default (openpi value)
}
FRAME_SKIP, MAX_STEPS = 10, 48


def sha(b):
    return hashlib.sha256(b).hexdigest()


src_bytes = open(EVAL, "rb").read()
with tarfile.open(TAR) as tf:
    m = [x for x in tf.getmembers() if x.name.endswith("libs/RoboVerse/roboverse/evals/libero/eval.py")][0]
    tar_bytes = tf.extractfile(m).read()
assert src_bytes == tar_bytes, "eval.py differs from the pinned upstream tarball"
tree = ast.parse(src_bytes.decode())
fn = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "eval_run"][0]
fn_src = ast.get_source_segment(src_bytes.decode(), fn)
ns = {"np": np, "tqdm": lambda x: x, "LIBERO_DUMMY_ACTION": [0.0] * 6 + [-1.0], "pkl": None,
      "libero_to_rv_obs": lambda obs, instr, cfg: {}, "_img_to_numpy": lambda img: None}
exec(compile(fn_src, EVAL + "::eval_run", "exec"), ns)
eval_run = ns["eval_run"]

import pickle  # noqa: E402
stats = pickle.load(open(os.path.join(V.HF, "dataset_stats.pkl"), "rb"))
dec_self = types.SimpleNamespace(dataset_stats=stats["out_ori_act"], num_bins_actions=1000, act_dim=ACT, horizon=H)


def decode(numbers):
    return V.QwenActor.get_action_from_text_action(dec_self, [" ".join(str(int(x)) for x in numbers)])[0].numpy().astype(np.float64)


class Env:
    def __init__(self):
        self.acts = []

    def reset(self):
        pass

    def set_init_state(self, s):
        return {"agentview_image": np.zeros((2, 2, 3), np.uint8)}

    def step(self, a):
        self.acts.append(np.array(a, float))
        return {"agentview_image": np.zeros((2, 2, 3), np.uint8)}, 0.0, False, {}


class Model:
    def __init__(self, base, inject, at, persistent=False):
        self.base, self.inject, self.at, self.j, self.persistent = base, inject, at, 0, persistent

    def __call__(self, **kw):
        import torch
        hit = self.j >= self.at if self.persistent else self.j == self.at
        c = self.inject if (self.inject is not None and hit) else self.base
        self.j += 1
        return {"out_ori_act": torch.tensor(c.copy())[None]}


def executed(base, inject, at, cfg, persistent=False):
    ah, ens, ver, w = cfg
    env, model = Env(), Model(base, inject, at, persistent)
    eval_run(env, model, None, "", None, MAX_STEPS, FRAME_SKIP, ah, "", False, ens, ver, w)
    return np.array(env.acts[FRAME_SKIP:]), model


def main():
    os.makedirs(OUT, exist_ok=True)
    R_ = [json.loads(l) for l in open(os.path.join(WORK, "run/pilot/records.jsonl"))]
    rows, noop = [], []
    for r in R_:
        if r["status"] != "OK":
            continue
        ref = r["reference"]["audit"]["numbers"]
        sR = suffix(r["arms"]["R"])
        if sR is None:
            continue
        base = decode(list(ref[:ANCHOR * ACT]) + list(sR.astype(int).ravel()))
        noop.append({"obs_id": r["obs_id"], "R_equals_reference_chunk": bool(np.array_equal(base, decode(ref)))})
        for cname, cfg in CONFIGS.items():
            ah = cfg[0]
            at = 8 if ah == 1 else 2           # inject once the ensemble buffer is full (ah=1) / at the 3rd replan otherwise
            t_inj = at * ah                    # executed-step index (after frame skip) of the injected replan
            e0, _ = executed(base, None, at, cfg)
            e_same, _ = executed(base, base.copy(), at, cfg)
            noop.append({"obs_id": r["obs_id"], "config": cname, "inject_R_identity": bool(np.array_equal(e0, e_same))})
            for k in ARMS:
                s = suffix(r["arms"][k])
                if s is None:
                    continue
                for var, pre in (("context_only", ref[:ANCHOR * ACT]), ("as_forced", r["arms"][k]["prefix_numbers"])):
                    chunk = decode(list(pre) + list(s.astype(int).ravel()))
                    e1, _ = executed(base, chunk, at, cfg)
                    d = e1 - e0
                    chunk_d = np.abs(chunk[:, :6] - base[:, :6])
                    for off in range(H + 2):
                        t = t_inj + off
                        if t >= len(d):
                            break
                        rows.append({"obs_id": r["obs_id"], "task": f"{r['suite']}/{r['task_index']}", "config": cname, "arm": k,
                                     "variant": var, "offset": off, "exec_abs_d_arm6": float(np.abs(d[t, :6]).mean()),
                                     "exec_grip_changed": bool(d[t, 6] != 0),
                                     "chunk_abs_d_arm6_at_index": float(chunk_d[off].mean()) if off < H else None})
                    ep, _ = executed(base, chunk, at, cfg, persistent=True)
                    dp = ep - e0
                    ss = dp[t_inj + 2 * H:]          # steady state: every buffered chunk is an injected one
                    rows.append({"obs_id": r["obs_id"], "task": f"{r['suite']}/{r['task_index']}", "config": cname, "arm": k,
                                 "variant": var, "offset": "persistent_steady", "exec_abs_d_arm6": float(np.abs(ss[:, :6]).mean()),
                                 "steady_const": bool(np.allclose(ss, ss[:1])), "chunk_abs_d_arm6_mean": float(chunk_d.mean())})
                    before = np.abs(d[:t_inj]).max() if t_inj else 0.0
                    rows.append({"obs_id": r["obs_id"], "task": f"{r['suite']}/{r['task_index']}", "config": cname, "arm": k,
                                 "variant": var, "offset": "pre", "exec_abs_d_arm6": float(before)})
    json.dump(rows, open(os.path.join(OUT, "replay_rows.json"), "w"))
    json.dump(noop, open(os.path.join(OUT, "replay_noop_checks.json"), "w"), indent=0)
    meta = {"post_hoc": True, "gpu": False, "eval_py_sha256": sha(src_bytes), "eval_py_matches_tarball": True,
            "eval_run_source_sha256": sha(fn_src.encode()), "tarball_sha256": sha(open(TAR, "rb").read()), "configs": CONFIGS,
            "frame_skip": FRAME_SKIP, "max_steps": MAX_STEPS, "n_obs": len({x["obs_id"] for x in noop}),
            "assumption": "all non-injected replans return the same R chunk (stationary context, no env feedback)"}
    json.dump(meta, open(os.path.join(OUT, "replay_meta.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
