# Reproduction commands (v2, 2026-10-21)

These replace the `--out run` line in the previous package README, which pointed the runner at the completed run folder. The new runner refuses that folder because it has no RUN_FINGERPRINT.json.

```bash
cd /root/VLA/vla0_work
source /root/VLA/openvla/env.sh            # LIBERO, robosuite, Mesa EGL (observation rendering only)
python scripts/vla0_prepare_obs.py --manifest manifest_validation_12.json --out obs
python scripts/vla0_prepare_obs.py --manifest manifest_pilot_150.json --out obs
# weights: ankgoyal/vla0-libero@6c62a511 model_last/ -> /dev/shm/vla0/model_last (shards checked against the recorded LFS sha256)
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1 python scripts/vla0_run.py \
  --val-manifest manifest_validation_12.json --pilot-manifest manifest_pilot_150.json --obs obs \
  --out run_repro_$(date +%Y%m%d_%H%M%S) --enable-new-inference --release-shm-weights --gpu-cap-min 112
python scripts/vla0_analyze.py run_repro_<stamp>/pilot/records.jsonl analysis_repro_<stamp>
```

The completed `run/` folder stays as it is. Its records come from the original GPU run. The runner shipped with that first GPU package is sha256 e9c0bafb…; that run recorded no runtime fingerprint, so this is the packaged code, not a proven runtime identity. 45943fc3… is the later CPU-revised runner and did **not** produce these records *(corrected v02)*. They must not be resumed and must not receive a fingerprint retroactively.

CPU checks in this folder (no GPU):
```bash
python tests/test_vla0_run_controls.py tests/test_vla0_run_controls_result.json      # runner negative controls
python scripts/vla0_buffer_replay.py buffer_replay                                   # official eval_run replay
python scripts/vla0_buffer_replay_summary.py buffer_replay
```
Interpreter used: /root/miniforge3/envs/autovla/bin/python (run under `nice`).
