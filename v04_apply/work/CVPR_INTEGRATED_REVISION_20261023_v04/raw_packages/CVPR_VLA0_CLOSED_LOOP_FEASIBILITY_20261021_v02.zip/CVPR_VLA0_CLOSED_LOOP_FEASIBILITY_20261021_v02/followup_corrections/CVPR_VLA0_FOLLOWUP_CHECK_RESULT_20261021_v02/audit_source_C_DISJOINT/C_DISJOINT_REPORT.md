# C_DISJOINT — independent day/vehicle data: inventory, overlap audit, power plan (review_followup5)

**Status: `BLOCKED_NO_DISJOINT_DATA`.** No GPU was used; nothing was downloaded except the 179 kB private_test_hard
metadata archive, which was streamed and never written to disk.

Scripts: `scripts/review_followup5/c_disjoint.py`, `c_power.py`. Outputs: `DATA_INVENTORY.csv` (per log / scene),
`DATA_INVENTORY_summary.csv`, `overlap_audit.json`, `POWER_PRECISION_PLAN.csv`, `power_inputs.json`.

## Rule

A log is eligible only if **both** its day and its vehicle lie outside the connected day–vehicle components of
dev ∪ P1-C (5 components; days 2021.05.25 … 2021.10.06, 13 vehicles — `overlap_audit.json`) **and** it is not part of the
training data (OpenScene v1.1 trainval, which the AutoVLA configs train on). A new log or a new drive is not enough;
re-downloading existing images is not new data.

## Inventory

| source | logs / scenes | days | vehicles | day+vehicle disjoint from dev ∪ P1-C | of these in training data | eligible |
|---|---|---|---|---|---|---|
| OpenScene v1.1 test (= navtest logs; P0-D inventory) | 147 logs | 9 | 16 | 0 | – | **0** |
| navsim navmini log list | 62 logs | 20 | 13 | 13 (veh-12, veh-17, veh-50) | 13 (all in OpenScene trainval) | **0** |
| navsim warmup_test_e2e log list | 62 logs (same logs as navmini) | 20 | 13 | 13 | 13 | **0** |
| NAVSIM v2 navhard two-stage (on disk, 2,731 scenes; anonymised log names, day from timestamp + city UTC offset) | 2,731 scenes | 9 | 13 | 0 | – | **0** |
| OpenScene v1.1 private_test_hard (metadata streamed from dataset commit a76f840b…, sha256 50d505a4…) | 71 anonymised logs (355 frames) | unknown | unknown | unknown (log, vehicle and city anonymised) | unknown | **0** (cannot be verified; ground truth also withheld) |

Source revisions: OpenScene test / trainval metadata as recorded by P0-D (dataset commit a76f840b…, stream sha256 in
`review_followup3/P0/DISJOINT_LOG_INVENTORY_meta.json`). Whether the checkpoint was selected on navtest cannot be
determined (unknown).

The six existing P1-C components can be re-tested (A_B2_CLUSTER), but that is a re-analysis of the same data, not a new
independent validation.

## What data would be needed

- Logs whose day **and** vehicle are not in the dev ∪ P1-C components and not in OpenScene trainval, with camera
  sensors and ground-truth trajectories (A− / severe need GT), at the NAVSIM 2 Hz format the checkpoint expects.
- Independent unit = connected day–vehicle component of the **new** data. Minimum p resolution: 2/2^G; with the four-
  contrast Holm family the floor is 4 · 2/2^G, so G ≥ 8 informative components for α = 0.05 (F) and G ≥ 9 for α = 0.025 (P).
  Resolution is not power.

## Power / precision plan (`POWER_PRECISION_PLAN.csv`; exact sign-flip at 0, component effects resampled around a target
using the observed P1-C between-drive spread; components of 3 drives; optimistic because it assumes normal component effects)

| contrast | target | G = 6 | G = 8 | G = 10 | G = 12 | G = 16 |
|---|---|---|---|---|---|---|
| F C_NAT, Holm-worst-case p < 0.0125 | observed +25.5 pp | 0.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| F C_NAT, same | half (+12.8 pp) | 0.00 | 0.70 | 0.94 | 0.99 | 1.00 |
| F C_GT, same | half (+12.7 pp) | 0.00 | 0.51 | 0.82 | 0.94 | 1.00 |
| P C_NAT, p < 0.00625 (α 0.025, Holm worst case) | observed +4.0 pp | 0.00 | 0.00 | 0.94 | 1.00 | 1.00 |
| P C_NAT, same | half (+2.0 pp) | 0.00 | 0.00 | 0.28 | 0.52 | 0.71 |

Plan: ≥ 10 new components (≥ 30 drives) with ≥ 5 failure-stratum scenes each would test the failure-stratum effect with
high power even at half its size; a population-level (E4) effect at half size needs ≥ 16–20 components. Cost on the RTX
5090 at the B2 rate (≈ 2.3 s per unit, 6 cells + no-op) is about 4 GPU-min per 100 units plus image download; no such data
exists on this machine or in the inspected public splits.
