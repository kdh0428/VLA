# Changes v02 (response to CVPR_VLA0_FOLLOWUP_CHECK_20261021_v02.md §2 note and §4.1–4.2)

This is a corrected copy of CVPR_VLA0_FOLLOWUP_CHECK_RESULT_20261021.zip (sha256 41c9394e…). The original zip is unchanged.

| item | change |
| --- | --- |
| §4.1 runner lineage | README, RUNNER_FIX and REPRO_COMMANDS now give the lineage below. The original records are no longer attributed to 45943fc3… |
| §4.2 result file name | The test captures the result path before rewriting `sys.argv`. It was re-run (ALL_PASS, same content) and the result is saved as `tests/test_vla0_run_controls_result.json`. The misnamed `tests/--val-manifest` is kept as `tests/superseded_misnamed_result_--val-manifest.json` |
| §2 reproduction dependencies | Added `repro_deps/`: official eval.py (sha 61b8d46c…), the upstream tarball b78db19 (sha b8c1ce72…), LICENSE (CC BY-NC 4.0), config.yaml (6624f21b…) and dataset_stats.pkl (ee365dfe…) |
| §3.2–3.3 wording | BUFFER_REPLAY_REPORT gains "v02 clarifications": endpoint units are not comparable to the pilot's +0.01368; only as_forced (not context-only) is negative under ensemble v2; the persistent steady state assumes a stationary context; the replay used float64, so it is not a float32 bitwise check |
| §4.3 units / budget | Fixed in the closed-loop package (manifest_cl_v02.json, PROTOCOL_CL_v02.md): 4 explicit units plus a separate smoke unit, and 150 GPU-min total including smoke and failed attempts |

Runner lineage:
- e9c0bafb…: runner of the original GPU run package. That run recorded no runtime fingerprint.
- 45943fc3…: later CPU revision.
- 4a18f2e5…: future-execution fix.
