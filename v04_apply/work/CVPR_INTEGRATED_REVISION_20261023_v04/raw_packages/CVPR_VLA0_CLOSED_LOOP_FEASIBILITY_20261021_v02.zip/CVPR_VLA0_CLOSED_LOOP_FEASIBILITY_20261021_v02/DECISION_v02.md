# DECISION v02 — VLA-0 closed-loop feasibility (executed 2026-10-21)

## What was actually run
| item | planned | executed | status |
| --- | --- | --- | --- |
| Stage 1 smoke (S1_smoke: libero_goal / task 0 / init 8, arm N, 16 steps) | 1 episode | 1 episode, 16 calls | **PASS** |
| Stage 2 units (U1–U4) × arms (N, R, L, O), 48 executed steps each | 16 episodes | 16 episodes, 768 model calls | **completed, no STOP** |
| GPU time (ledger: whole process wall time, conservative) | cap 150 min | **74.0 min** (one attempt, no failed attempts) | within cap |
| Failed or repeated GPU attempts | – | 0 | – |

- Hardware: one RTX 5090 (physical GPU 1). Peak VRAM 7.7 GB.
- Weights: re-downloaded to /dev/shm; the shard sha256 matched the recorded LFS hashes before loading; the files were unlinked after loading.

## Gates
| check | result |
| --- | --- |
| Stage 1: native `QwenActor.forward` text and `out_ori_act` equal to the harness (adapter) output | 16/16 |
| Stage 1 and each Stage-2 N: model-free action replay in a fresh env reproduces every MuJoCo state bitwise | 5/5 episodes |
| **M1 no-op**: R equals N bitwise in every executed action and simulator state | **4/4 units**; self-patch token identity 160/160 calls |
| **M2**: offline replay of the logged float32 chunks, in logged order, through the official `eval_run` reproduces the logged executed actions and ensemble buffers bitwise | **17/17 episodes** (actions and buffers) |
| Pre-intervention identity: before call 8, actions, states and buffers of R/L/O equal N | 12/12 arm-units |
| Direct-path check: no command difference before offset 3 after the first APPLIED call | held in 8/8 L/O arm-units |

## Intervention coverage
- **R:** 40/40 self-patch calls per unit.
- **O:** 40/40 APPLIED in every unit.
- **L:** 40 APPLIED in U2 and U3; 39 APPLIED + 1 NOT_APPLIED (source_missing) in U1 and U4. The NOT_APPLIED calls executed the natural chunk and are not counted as interventions.
- No natural output was incomplete, so the parser never padded, truncated or fell back.

## Command → motion (per unit; executed step = steps after the 10-step frame skip; first edited call = step 8)
| unit | pair | first command diff | delay from first APPLIED | first EE diff > 0.1 mm | first > 1 mm | mean ‖ΔEE‖ over window (mm) | final ‖ΔEE‖ (mm) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| U1 | L−N | 11 | 3 | 11 | 15 | 2.81 | 4.30 |
| U1 | O−N | 11 | 3 | 14 | 17 | 2.43 | 9.22 |
| U2 | L−N | 11 | 3 | 14 | 18 | 1.63 | 3.01 |
| U2 | O−N | 11 | 3 | 15 | 25 | 1.31 | 3.52 |
| U3 | L−N | 11 | 3 | 13 | 28 | 1.27 | 5.52 |
| U3 | O−N | 11 | 3 | 13 | 27 | 0.69 | 0.78 |
| U4 | L−N | 11 | 3 | 12 | 17 | 2.16 | 5.15 |
| U4 | O−N | 11 | 3 | 16 | 26 | 2.36 | 8.42 |
| all | R−N | none | – | none | none | 0 | 0 |

Additional details:
- **Orientation:** differences reached 0.004–0.025 rad.
- **Gripper:** qpos differences were small (≤ 0.0024).
- **Success flags:** all false. The runs are 48-step truncated episodes, and the flags are logged only.

Full per-step traces are in `analysis/cl_step_traces.csv` and `figures/vla0_closed_loop_traces.png`.

**What this shows.** In the real simulator with the official loop and README configuration, a context-only edit reaches the executed command and then actual end-effector motion:
- **Command.** The executed command changes exactly at offset 3, as the ensemble path implies, in all 8 L/O arm-units.
- **Simulator state.** The state diverges at that same step.
- **Motion.** End-effector motion differences of 0.1 mm appear within 0–5 further steps and reach 1 mm after 7–20 steps from the first edit. By step 48 the differences are 0.8–9.2 mm.
- **Feedback.** After divergence the observations and natural outputs of the arms differ, so the later traces include feedback, as expected.

**What it does not show.**
- **L versus O.** There is no consistent latest-vs-older ordering in motion.
  - Mean ‖ΔEE‖ for L−N exceeds O−N in 3/4 units (+0.39, +0.32, +0.58, −0.20 mm).
  - Final ‖ΔEE‖ is larger for O in 3/4 units.
  - Mean command |Δ| is larger for L in 3/4 units.
  - With n = 4 there is no significance or equivalence claim, and the open-loop L > O result is **not** claimed to carry over to motion.
- **Outcome.** Nothing here addresses task success, usefulness or performance.
- **Ground truth.** Demonstrations were not used as ground truth.

## Is a task-outcome evaluation worth doing next?
**Not as the immediate next step; possibly later, only as a separately preregistered, bounded study.** Reasons:
1. **Effect size.** The motion effect after 40 edited calls is millimetre-scale (mean 0.7–2.8 mm per unit), and its direction relative to N is not consistent. Whether it changes success is an open question that this run cannot predict.
2. **Cost.** At the measured rates, a full episode costs:

   | arm | s/step | full libero_goal episode (300 steps) |
   | --- | --- | --- |
   | N | 2.7 | ≈ 14 min |
   | L or O (natural + 4-sample sources + forced decode) | 7.1 | ≈ 36 min |

   A paired success study powered for small differences would need tens of GPU-hours.
3. **Better intermediate question.** It is still cheap to ask whether the motion divergence keeps growing or saturates over a full episode. A handful of full-length paired N/L episodes on the same 4 units (≈ 3–4 GPU-h) would answer this, and should come before any success-rate design.

This is a recommendation only; no such run was started.
