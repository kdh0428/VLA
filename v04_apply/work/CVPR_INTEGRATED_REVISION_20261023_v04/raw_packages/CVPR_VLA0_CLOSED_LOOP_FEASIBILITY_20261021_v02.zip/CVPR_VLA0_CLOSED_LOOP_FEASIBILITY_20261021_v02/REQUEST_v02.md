# VLA-0 후속 검토 v02 — 실행 보호 수정과 CPU buffer replay

작성일: 2026-10-21 (KST)

이전 검토: CVPR_VLA0_FOLLOWUP_CHECK_20261021.md
이번 대상: CVPR_VLA0_FOLLOWUP_CHECK_RESULT_20261021.zip
ZIP SHA-256: 41c9394ec9ca1bca6f6327693e7e678c343ba517e1cbbfce20429ead89987e34

## 1. 결론

**이전의 두 실행 보호 문제는 수정됐고, 수정된 함수에 대한 독립 CPU 제어 검사 14개가 모두 통과했습니다.** 이 문제들은 닫아도 됩니다. 기존 149개 파일럿을 다시 추론할 필요가 없습니다.

새로 추가된 buffer replay의 행 단위 자료와 bootstrap도 재계산했습니다. README 설정에서 context-only suffix가 실행 명령에 전달되는 시점과 1/9 비중이 재현됩니다.

이는 **command-generation → ensemble → 실행 명령** 경로의 준비가 진전됐다는 뜻입니다. 실제 simulator feedback·물리적 운동·task outcome을 검증한 것은 아닙니다.

다음은 새 환경의 짧은 smoke test와 4개 단위의 paired closed-loop feasibility입니다. 600개 초기 관측 확장은 선행 조건이 아닙니다.

## 2. 독립 확인 결과

| 검사 | 결과 |
| --- | --- |
| 산출물 무결성 | 해시 목록 31개 모두 존재·일치 |
| 수정 전 runner | 이전 패키지의 runner와 byte-identical |
| legacy output + fingerprint 없음 | model load 전에 거부. metadata·기존 기록 보존 |
| fingerprint 불일치 | model load 전에 거부 |
| weight/tokenizer 불일치 | model load 전에 거부 |
| fresh run | fingerprint와 metadata 기록 후 validation → pilot |
| 같은 fingerprint의 resume | 기존 metadata 보존, 이미 PASS인 validation을 반복하지 않음 |
| strict validation summary | status, exact-35/EOS, invariants, donor 검사와 기록 수가 최종 PASS에 연결됨 |
| 이전 synthetic 실패 사례 | 이제 FAIL |
| 임시 fixture 정리 | 완료. 실제 모델·GPU·기존 run은 건드리지 않음 |
| replay 자료 | 149개 관측, 71,520개 행 |
| 관측별 replay 합계 | 저장 CSV와 최대 약 2.2×10⁻¹⁶ 차이 |
| 8개 config×variant contrast 및 구간 | 최대 약 2.8×10⁻¹⁷ 차이 |
| README context-only, offset 0–2 | 실행 명령 차이 0 |
| README context-only, offset 3–7 | nonzero 3,665개 비교에서 평균 전달 비율 0.111111…; 1/9 대비 최대 오차 약 2×10⁻¹⁴ |
| README context-only, offset 8–9 | 단일 주입의 실행 명령 차이 0 |
| 주입 전 차이 | 0 |
| no-op 기록 | R=reference 149개, R 주입 실행 일치 596개 기록 확인 |

CPU control은 실제 수정된 preflight/main/validation_summary 함수들을 AST로 추출해 격리된 작은 fixture와 fake model loader로 검사했습니다. 실제 모델을 로딩한 end-to-end GPU 검증과 구분합니다.

replay 검증은 제공된 행 자료에서의 재계산입니다. 공식 eval.py 원문·tarball·dataset_stats가 이번 ZIP에 없어서, 공식 eval_run과 실제 정규화 해제를 처음부터 독립 재실행한 검증은 아닙니다. 패키지는 해당 원문의 hash와 사용 경로를 보고합니다. 후속 전달물에는 이 작은 재현 의존 파일도 함께 보존하는 것이 좋습니다.

## 3. 새 replay 결과의 의미

### 3.1 단일 context-only 주입

README 설정은 action_horizon=1, ensemble_prediction=8, ensemble_version=1입니다.

- 편집된 call의 출력 vector 1–3을 natural 값으로 유지하므로 offset 0–2의 실행 명령은 바뀌지 않습니다.
- suffix vector 4–8은 offset 3–7의 실행 명령에 들어갑니다.
- 가득 찬 buffer에서 해당 older prediction의 비중은 0.5/(1+0.5×7)=1/9입니다.
- 단일 주입이므로 그 call의 horizon을 지난 offset 8–9에는 차이가 남지 않습니다. 이는 feedback이 없는 replay에 한정됩니다.

이 경로에서는 ‘현재 call의 첫 실행 action은 그대로’라는 사실과 ‘나중 실행 action에 영향이 도달한다’는 사실이 함께 성립합니다.

### 3.2 실행 명령 공간의 L−O

| 설정·variant | L−O | 95% task-cluster bootstrap 구간 |
| --- | ---: | --- |
| README v1, context_only | **+0.010980** | **[0.009010, 0.012963]** |
| ensemble v2, context_only | +0.002813 | [0.002371, 0.003266] |
| horizon 8 / no ensemble, context_only | +0.098817 | [0.081066, 0.116458] |
| horizon 5 / no ensemble, context_only | +0.047652 | [0.040134, 0.055400] |
| ensemble v2, as_forced | −0.000728 | [−0.001504, +0.000059] |

이 표의 endpoint는 단일 주입 후 평가 window에서 mean abs(action_arm−action_R)를 **시간에 대해 합한 값의 L−O**입니다. 원 파일럿의 정규화 bin 좌표 평균 차이 +0.01368과는 단위·집계가 다릅니다. 두 숫자를 직접 효과 보존율처럼 비교하면 안 됩니다.

context_only에서는 네 설정 모두 양의 차이가 관찰됐습니다. 음의 점추정은 as_forced라는 다른 개입에서 나옵니다. 이를 ‘context-only의 latest 우세가 ensemble v2에서 역전됐다’고 쓰면 안 됩니다.

### 3.3 매 replan마다 편집하는 stationary replay

README 설정의 정상상태 평균 실행 차이는 L 약 0.02267, O 약 0.01182입니다. 각각 같은 native action 공간에서 계산한 chunk 평균 차이의 약 0.85, 0.83입니다.

이 값은 모든 후속 관측이 같고, 같은 R과 같은 edited chunk를 반복 공급한 **stationary context 가정**의 결과입니다. 실제 환경에서는 실행 행동이 바뀌면 다음 영상·상태·새 예측도 바뀝니다. 실제 closed-loop에서 같은 비율·부호가 유지된다는 보장은 없습니다.

현재 replay는 decoded chunk를 float64로 변환해 mock model에 공급합니다. 후속 실제 로그의 offline replay에서는 native chunk와 계산 dtype을 그대로 유지해야 합니다. float64 replay의 no-op 검사를 native float32 경로의 bitwise 검증으로 대체하지 마세요.

## 4. 바로잡을 문서·재현 항목

아래는 기존 결과를 폐기하거나 기존 실험을 재실행해야 할 문제가 아닙니다. 다음 실험 준비와 함께 고치면 됩니다.

### 4.1 과거 GPU 실행 runner SHA 표기

이번 README, RUNNER_FIX, REPRO_COMMANDS는 기존 149개 기록이 SHA 45943fc3… runner로 생성됐다고 씁니다. 이 표기는 최초 전달물과 맞지 않습니다.

| 단계 | SHA-256 | 의미 |
| --- | --- | --- |
| 최초 GPU 결과 패키지에 포함된 runner | e9c0bafb13c246ea836a0927aea65b65c109ae0719b75ec02e1a49455b73377f | 최초 실행 보고 및 amendment에 연결된 코드 |
| 다음 CPU 보완판의 runner / 이번 BEFORE | 45943fc3d6f072115fcd8046f6a9ad4cc4b4951e5f84149efe7a1c98a6fcfd4f | 이전 검토에서 제어 흐름 문제를 찾았던 CPU 수정판 |
| 이번 AFTER | 4a18f2e53f847c705fbaa2d26e398341b239e6f6149a8127d5b7f5ca323e3890 | 이번 CPU controls로 검사한 향후 실행용 수정판 |

최초 기록에는 arms_complete_exact35_eos / arm_invariants 필드가 없지만, 45943fc3…는 매 정상 행에 이 필드를 기록합니다. 최초 결과와 다음 CPU 패키지의 원시 pilot 기록은 byte-identical입니다.

따라서 45943fc3…를 과거 GPU 실행 코드라고 소급해서 붙이지 마세요. 최초 패키지의 코드·amendment와 후속 CPU 수정 코드를 구분하세요. 최초 run의 runtime fingerprint가 없었다는 한계도 그대로 남겨야 합니다.

### 4.2 CPU control 결과 파일명

보고서는 tests/test_vla0_run_controls_result.json을 가리키지만 실제 ZIP의 결과 JSON은 tests/--val-manifest입니다. 테스트 중 sys.argv를 변경한 후 마지막 저장에서 sys.argv[1]을 다시 사용한 결과입니다.

시작 시 결과 경로를 별도 변수에 보존하고, 마지막 저장에는 그 변수를 사용하세요. 제어 검사 결과 자체는 확인됐으므로 단순 저장 경로 수정입니다.

### 4.3 4개 rollout unit과 예산을 정확히 고정

현재 문서의 ‘초기 상태 6–7, task 4개’는 4 units인지 8 units인지 모호합니다. 다음 실행 manifest에는 unit마다 suite/task/init index를 정확히 적으세요.

예시로 다음 4개를 고정할 수 있습니다.

| unit | suite | task index | init-state index |
| --- | --- | ---: | ---: |
| U1 | libero_spatial | 0 | 6 |
| U2 | libero_object | 5 | 6 |
| U3 | libero_goal | 0 | 7 |
| U4 | libero_goal | 5 | 7 |

task index는 공식 task 이름과 instruction으로 풀어서 저장하세요. Stage 1 smoke에는 별도 관측을 쓰고 사용 여부를 기록하세요. 나중의 optional unseen-state 실험에서는 이미 사용한 상태를 제외해야 합니다.

Stage 1 15분과 Stage 2 150분을 합해 165분인지, 전체 150분인지도 실행 프롬프트에서 분명히 하세요. 다음 단계에는 **smoke와 실패 시도를 포함한 전체 150 GPU-분 상한**을 권합니다.

기존 3.79초/call은 비용 추정용 평균입니다. source bank의 4-return sampling과 단일 greedy/forced decode는 비용이 다릅니다. smoke에서 실제 호출 종류별 시간을 측정해 남은 예산을 판단하세요.

## 5. 연구 기여에 대한 상태

확보된 근거:

1. 두 번째 학습된 policy·숫자 텍스트 행동 표현의 within-call temporal sensitivity.
2. 명시적 source 거리 통제를 포함한 latest vs preceding command 반응 차이.
3. native ensemble 설정에서 suffix 변화가 나중 실행 명령에 전달되는 경로의 CPU 점검.

아직 확보되지 않은 근거:

- VLA-0의 실제 EE 운동 변화와 환경 feedback.
- VLA-0의 task success·유용성·성능 향상.
- 별도 backbone 계열에 걸친 재현.
- AutoVLA의 추가 독립 상위 군집.

CPU 경로 점검은 새 성능 방법이나 새로운 물리 실험으로 쓰지 마세요. 논문에서는 기존 주 결과를 신뢰하고 해석하기 위한 구현·설계 근거로 배치할 수 있습니다. 기여 크기를 더 보강할 다음 질문은 **실제 환경에서 이 경로가 운동 차이까지 이어지는가**입니다.

## 6. 다음 코딩 에이전트 작업 지시

아래는 이 문서와 함께 전달할 다음 실행 범위입니다. 이 검토 과정에서는 GPU를 실행하지 않았습니다.

### 목표와 범위

기존 149개 파일럿을 보존하고, VLA-0 closed-loop feasibility harness를 구현해 실제 smoke와 4개 paired units까지 수행하세요. 계획서만 제출하지 말고 아래 예산 안에서 실행·분석·전달까지 완료하세요.

- 이번 범위: CPU 문서 정정, 환경/모델 연결, Stage 1 smoke, PASS 시 Stage 2의 N/R/L/O 4 arms.
- 전체 GPU 상한: **150분**. Stage 1과 실패·재검증 시도도 포함. 다른 작업을 방해하지 않는 GPU 한 장 사용.
- Stage 1 상한: 15 GPU-분. 미해결이면 실제 상태를 BLOCKED로 보고하고 독립적으로 가능한 CPU 작업을 완료.
- 600개 초기 관측 추가, full episodes, 성공률 확증 평가, fine-tuning은 수행하지 않음.
- 기존 checkpoint·완료 run·다른 작업 파일을 삭제하거나 기존 결과에 새 fingerprint를 소급 기록하지 않음.

### 실행

1. §4의 문서와 test 결과 경로를 정정하세요. 이미 닫힌 149개 주 결과·graph·기존 controls를 이유 없이 다시 연구하지 마세요.
2. 공식 loop의 pinned source, config/stats, 실제 모델/processor, 새 harness의 fingerprint를 고정하세요. 공식 eval loop의 계산은 유지하고 model/env wrapper 또는 logging hook으로 연결하세요.
3. CPU stationary replay를 실제 feedback 평가로 재사용하지 마세요. Stage 1에서는 실제 LIBERO와 모델을 연결해 별도 unit인 libero_goal / task index 0 / init-state index 8에서 N의 16개 실행 step을 관찰하세요.
4. §4.3의 4개 unit manifest를 고정하고, Stage 2는 frame skip 이후 48개 실행 step으로 제한하세요. 각 arm은 같은 초기 상태·seed에서 시작하고, intervention 전 state/action/buffer가 일치해야 합니다.
5. 설정: action_horizon=1, ensemble_prediction=8, ensemble_version=1, frame_skip=10, env seed=7. 다른 설정을 유리한 결과에 맞춰 선택하지 마세요.
6. Arms:
   - N: natural policy.
   - R: natural prefix를 같은 값으로 self-patch하는 no-op.
   - L: replan index 8부터 매 replan에서 conditioning vector 3만 donor로 교체.
   - O: 동일하게 vector 2만 교체.
   - L/O에서 출력·실행에 넘기는 chunk의 처음 3개 vector는 각 call의 자연 출력 그대로 유지. donor는 기존 규칙인 4 samples, T=0.7, 길이가 같은 첫 적격 vector를 사용.
7. 각 실제 call에서 자연 출력·source·conditioning prefix·emitted prefix·suffix·decoded chunk·입력 hash·dtype를 남기세요. L/O의 source seed는 unit/step으로 고정하고, 같은 입력을 받는 경우 source bank가 같도록 하세요.
8. 실제 arm들이 분기한 이후에는 관측·자연 출력이 서로 달라질 수 있습니다. ‘각 call 내 emitted prefix 고정’과 ‘episode 전체에서 arm 간 출력이 계속 같음’을 혼동하지 마세요.
9. 자연 출력이 불완전한 경우 native parser의 동작과 fallback 여부를 기록하세요. L/O에 유효한 reference prefix/source/완전한 edited suffix가 없으면 그 step은 자연 chunk를 실행하고 NOT_APPLIED 사유를 남기세요. 이를 유효한 개입·영효과·self-patch 성공으로 세지 마세요. donor를 얻기 위해 seed/후보 수를 반복 변경하지 마세요.
10. R을 실제로 self-patch한 step에서는 raw continuation·decoded chunk가 자연 출력과 일치해야 합니다. N/R의 실행 action과 simulator state도 일치해야 합니다. 불일치가 해결되지 않으면 STOP하고 L/O 결과를 성공한 검증으로 보고하지 마세요.

### 필수 검사와 측정

- N의 action trace를 모델 없이 simulator에 다시 넣어 state 재현을 점검.
- 각 arm에서 실제 사용한 chunk와 buffer를 저장하고, 같은 dtype·native loop를 쓰는 offline replay와 실행 action을 대조.
- offline replay에는 매 step의 실제 기록 chunk를 순서대로 공급. 같은 R chunk를 반복하는 stationary 가정을 사용하지 않음.
- context-only 주입 후 offset 0–2에는 직접 실행 action 변화가 없어야 함. 최초 차이가 offset 3보다 빠르면 구현 경로를 조사. 정확히 offset 3에서 차이가 반드시 생긴다고 강제하지는 않음.
- EE 위치 차이(m), orientation 차이, gripper 상태, 최초 명령/상태/운동 차이 시점, 시간별 trace를 unit마다 보고.
- L−O 운동 차이도 그대로 보고하되 n=4에서 유의성·동등성·성공률 개선을 주장하지 않음.
- 실제 개입 coverage와 invalid/source-missing/no-op fallback step을 명시.
- 성공 flag는 로그로만 보존. 48-step truncated run을 full-episode 성공률로 해석하지 않음.
- step별 비용·source 생성 비용·VRAM·전체 GPU 사용 시간을 기록.

### 전달물

버전을 포함한 새 패키지와 MD 파일명으로 전달하세요.

- 실제 실행 수와 상태를 앞에 둔 README/DECISION.
- 실행 전 고정 protocol, manifest, fingerprint와 변경 기록.
- 실행 가능한 harness·model/env 연결 코드.
- per-step 원시 로그, 실제 적용 chunk와 buffer, action/state/EE trace.
- N/R no-op, action replay, simulator determinism 결과.
- unit별 운동 trace 그림과 command→운동 지연 표.
- 실제 수행하지 못한 항목과 원인·비용.
- 다음 task-outcome 평가를 할 가치가 있는지 판단. 유리한 결과를 강제로 만들거나 곧바로 수백 episode를 추가하지 않음.
