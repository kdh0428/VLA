# VLA-0 closed loop: autovla env (transformers 4.49 for Qwen2.5-VL) + LIBERO/robosuite/mujoco from /root/VLA/openvla without
# shadowing transformers/tokenizers/huggingface_hub (only packages missing from the autovla env are linked in site_libero/).
source /root/miniforge3/etc/profile.d/conda.sh && conda activate autovla
export PYTHONPATH=/root/VLA/vla0_cl_work/site_libero:/root/VLA/openvla/LIBERO
export LD_LIBRARY_PATH=/root/VLA/openvla/mesa/lib:${LD_LIBRARY_PATH:-}
export MUJOCO_GL=egl PYOPENGL_PLATFORM=egl EGL_PLATFORM=surfaceless
export __EGL_VENDOR_LIBRARY_DIRS=/root/VLA/openvla/mesa/share/glvnd/egl_vendor.d
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1,2 TOKENIZERS_PARALLELISM=false
export MUJOCO_EGL_DEVICE_ID=2
