# Not done (v02) — and why

| item | reason | cost if done |
| --- | --- | --- |
| Official `libero_to_rv_obs` in the loop | Needs lerobot, which is not installed; the adapter path (validated 12/12, Stage 1 16/16 vs native forward) was used instead | Installing lerobot into the env (disk ≈ 5 GB free) and re-running Stage 1 |
| Full-length episodes and task success | Excluded by the request; the 48-step success flags are log-only | Per full episode: N ≈ 14 min, L/O ≈ 36 min (300-step libero_goal) |
| L vs O motion inference | n = 4 units, no test planned | – |
| Other configurations (ensemble v2, no-ensemble defaults) | Fixed to the README configuration in advance | ≈ 18 GPU-min per unit and configuration |
| 600-observation open-loop expansion, fine-tuning, success-rate confirmation | Excluded by the request | – |
| End-to-end GPU run of the revised `vla0_run.py` (4a18f2e5…) | Not required by this request; its CPU controls passed | ≈ 2 h for validation + pilot |
| Remaining GPU budget (76 of 150 min) | Unused; nothing further was in scope | – |
