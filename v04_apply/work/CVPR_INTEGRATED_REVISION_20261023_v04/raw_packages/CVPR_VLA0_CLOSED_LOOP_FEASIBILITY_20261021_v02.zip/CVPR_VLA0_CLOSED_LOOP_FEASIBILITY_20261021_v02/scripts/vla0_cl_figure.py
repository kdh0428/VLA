#!/usr/bin/env python
"""Per-unit traces: EE position difference (mm) and executed-command difference vs executed step. Usage: <analysis_dir> <fig_dir>"""
import os, sys
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

A, F = sys.argv[1], sys.argv[2]
os.makedirs(F, exist_ok=True)
t = pd.read_csv(os.path.join(A, "cl_step_traces.csv"))
t = t[t.exec_step >= 0]
COL = {"L-N": "#2a78d6", "O-N": "#eb6834", "L-O": "#1baf7a", "R-N": "#8a8984"}
LAB = {"L-N": "L vs N (vector 3 edit)", "O-N": "O vs N (vector 2 edit)", "L-O": "L vs O", "R-N": "R vs N (no-op)"}
units = list(dict.fromkeys(t.unit))
plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#b5b4ae", "axes.labelcolor": "#52514e", "xtick.color": "#52514e",
                     "ytick.color": "#52514e", "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(2, len(units), figsize=(3.1 * len(units), 5.2), sharex=True, squeeze=False)
for j, u in enumerate(units):
    for i, (col, ylab, scale) in enumerate([("ee_pos_d_m", "EE position difference (mm)", 1000.0),
                                            ("cmd_abs_d", "command |Δ| (6-dim mean)", 1.0)]):
        a = ax[i, j]
        for p in ["R-N", "O-N", "L-N", "L-O"]:
            s = t[(t.unit == u) & (t.pair == p)]
            if len(s):
                a.plot(s.exec_step, s[col] * scale, color=COL[p], lw=2 if p != "L-O" else 1.5,
                       ls="-" if p != "L-O" else "--", label=LAB[p], solid_capstyle="round")
        a.axvline(8, color="#b5b4ae", lw=1, ls=":")
        a.grid(axis="y", color="#e6e5e0", lw=0.6)
        if i == 0:
            a.set_title(u, fontsize=10, color="#0b0b0b")
            a.text(8.4, a.get_ylim()[1] * 0.92, "first edited call", fontsize=7, color="#52514e")
        if j == 0:
            a.set_ylabel(ylab)
        if i == 1:
            a.set_xlabel("executed step (after frame skip)")
h, l = ax[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=4, frameon=False, fontsize=8)
fig.tight_layout(rect=(0, 0, 1, 0.94))
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(F, f"vla0_closed_loop_traces.{ext}"), dpi=200)
print("saved")
