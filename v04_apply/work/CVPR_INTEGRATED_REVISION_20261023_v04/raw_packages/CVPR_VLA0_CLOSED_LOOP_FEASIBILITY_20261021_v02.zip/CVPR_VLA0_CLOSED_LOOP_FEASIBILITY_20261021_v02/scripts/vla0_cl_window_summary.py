"""Per-unit window summaries and per-call cost by kind (same computation as used for DECISION_v02). Usage: <run_dir> <analysis_dir>"""
import glob, json, os, sys
import numpy as np, pandas as pd
R, A = sys.argv[1], sys.argv[2]
t = pd.read_csv(os.path.join(A, "cl_step_traces.csv")); t = t[t.exec_step >= 0]
s = t.groupby(["unit", "pair"]).agg(mean_cmd_d=("cmd_abs_d", "mean"), mean_ee_mm=("ee_pos_d_m", lambda x: 1000 * x.mean()),
                                   final_ee_mm=("ee_pos_d_m", lambda x: 1000 * x.iloc[-1]), mean_ang_rad=("ee_ang_d_rad", "mean")).reset_index()
s.to_csv(os.path.join(A, "cl_window_summary.csv"), index=False)
calls = [json.loads(l) for f in glob.glob(os.path.join(R, "U*/*/calls.jsonl")) for l in open(f)]
k = {kk: float(np.mean([c[kk] for c in calls if kk in c])) for kk in ("t_natural_s", "t_sources_s", "t_forced_s", "t_call_s")}
json.dump(k, open(os.path.join(A, "cl_cost_by_call_kind.json"), "w"), indent=1)
print(s.round(4).to_string()); print(k)
