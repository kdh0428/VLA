#!/usr/bin/env python
"""CPU analysis of the closed-loop run (no GPU). Usage: vla0_cl_analyze.py <run_dir> <out_dir>
M2: the LOGGED float32 chunks of every arm, in their logged order, go through the official eval_run with a mock env. The executed
actions and ensemble buffers must equal the logged ones bitwise. Also: pre-intervention identity vs N; per-step command/state/EE
divergence; first-difference steps; delay from the first APPLIED call; coverage; per-call cost."""
import json, os, sys
import numpy as np, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vla0_cl_harness as Hn

RUN, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
M = json.load(open("/root/VLA/vla0_cl_work/manifest_cl_v02.json")); cfg = M["config"]
ns, _ = Hn.load_official()
FS = cfg["frame_skip"]; FIRST = M["stage2"]["first_intervention_replan"]


class MockEnv:
    def reset(self): pass
    def set_init_state(self, s): return self._obs()
    def get_sim_state(self): return np.zeros(1)
    def close(self): pass
    def _obs(self):
        z = np.zeros(3)
        return {"agentview_image": np.zeros((2, 2, 3), np.uint8), "robot0_eye_in_hand_image": np.zeros((2, 2, 3), np.uint8),
                "robot0_eef_pos": z, "robot0_eef_quat": np.array([0, 0, 0, 1.0]), "robot0_gripper_qpos": np.zeros(2)}
    def step(self, a): return self._obs(), 0.0, False, {}


def load_arm(u, arm):
    d = os.path.join(RUN, u, arm)
    if not os.path.exists(os.path.join(d, "episode.json")):
        return None
    z = np.load(os.path.join(d, "trace.npz"))
    calls = [json.loads(l) for l in open(os.path.join(d, "calls.jsonl"))]
    return {"z": {k: z[k] for k in z.files}, "buf": json.load(open(os.path.join(d, "buffers.json"))), "calls": calls,
            "ep": json.load(open(os.path.join(d, "episode.json")))}


def offline_replay(arm_d, steps):
    chunks = [np.array(c["chunk"], dtype=np.float32) for c in arm_d["calls"]]
    assert all(c["chunk_dtype"] == "torch.float32" for c in arm_d["calls"])
    it = iter(chunks)
    model = lambda **kw: {"out_ori_act": torch.tensor(next(it))[None]}  # noqa: E731
    env = Hn.StepLogger(MockEnv())
    ns["eval_run"](env, model, None, "", None, steps, FS, cfg["action_horizon"], "", False, cfg["ensemble_prediction"],
                   cfg["ensemble_version"], cfg["ensemble_2_weight"])
    st = [x for x in env.trace if x["kind"] == "step"]
    act_eq = len(st) == len(arm_d["z"]["action"]) and all(np.array_equal(x["action"], y) for x, y in zip(st, arm_d["z"]["action"]))
    def same_buf(x, b):
        if (x["buffer"] is None) != (b["buffer"] is None):
            return False
        if x["buffer"] is not None:
            if len(x["buffer"]) != len(b["buffer"]) or not all(np.array_equal(np.asarray(p), np.asarray(q, dtype=np.float32)) for p, q in zip(x["buffer"], b["buffer"])):
                return False
        ex, eb = x["ensembled_chunk"], b["ensembled_chunk"]
        return (ex is None and eb is None) or (ex is not None and eb is not None and np.array_equal(ex, np.asarray(eb, dtype=np.float32)))
    buf_eq = all(same_buf(x, b) for x, b in zip(st, arm_d["buf"]))
    dt = {b["ensembled_dtype"] for b in arm_d["buf"] if b["ensembled_dtype"]}
    return {"actions_bitwise": bool(act_eq), "buffers_bitwise": bool(buf_eq), "n_chunks": len(chunks), "ensembled_dtypes": sorted(dt)}


def qang(q1, q2):
    """rotation angle between unit quaternions; exactly 0 for identical inputs (atan2 form, sign-invariant)."""
    sgn = np.where(np.sum(q1 * q2, axis=-1, keepdims=True) < 0, -1.0, 1.0)
    return 4 * np.arctan2(np.linalg.norm(q1 - sgn * q2, axis=-1), np.linalg.norm(q1 + sgn * q2, axis=-1))


rows, summ, traces, delays = [], [], [], []
units = [x for x in M["units"]]
for U in units:
    u = U["unit"]; steps = M["stage1"]["steps"] if U["stage"] == "stage1" else M["stage2"]["steps"]
    arms = {a: load_arm(u, a) for a in (["N"] if U["stage"] == "stage1" else M["stage2"]["arms"])}
    arms = {k: v for k, v in arms.items() if v is not None}
    if not arms:
        continue
    for a, d in arms.items():
        r = offline_replay(d, steps)
        cnt = {}
        for c in d["calls"]:
            key = c["status"] + ("" if not c.get("reason") else f":{c['reason']}"); cnt[key] = cnt.get(key, 0) + 1
        t = lambda k: [c[k] for c in d["calls"] if k in c]  # noqa: E731
        rows.append({"unit": u, "arm": a, **r, "status_counts": cnt, "n_calls": len(d["calls"]), "wall_s": d["ep"]["wall_s"],
                     "success_flag_log_only": d["ep"]["success_flag_log_only"],
                     "t_call_mean": float(np.mean(t("t_call_s"))), "t_natural_mean": float(np.mean(t("t_natural_s"))),
                     "t_sources_mean": float(np.mean(t("t_sources_s"))) if t("t_sources_s") else None,
                     "t_forced_mean": float(np.mean(t("t_forced_s"))) if t("t_forced_s") else None,
                     "native_check_equal": (sum(c["native_check"]["text_equal"] and c["native_check"]["out_ori_act_equal"] for c in d["calls"])
                                            if "native_check" in d["calls"][0] else None),
                     "selfpatch_token_identity": (sum(c["selfpatch"]["token_identity"] for c in d["calls"] if "selfpatch" in c)
                                                  if a == "R" else None)})
    if "N" not in arms or U["stage"] == "stage1":
        continue
    zN = arms["N"]["z"]
    for a in [x for x in arms if x != "N"] + (["L-O"] if "L" in arms and "O" in arms else []):
        zA, zB = (arms["L"]["z"], arms["O"]["z"]) if a == "L-O" else (arms[a]["z"], zN)
        n = min(len(zA["action"]), len(zB["action"]))
        cmd = np.abs(zA["action"][:n, :6] - zB["action"][:n, :6]).mean(1)
        # trace index 0 = init, i = after executed simulator step i (incl. dummies)
        m = min(len(zA["state"]), len(zB["state"]))
        st_diff = np.array([not np.array_equal(zA["state"][i], zB["state"][i]) for i in range(m)])
        ee = np.linalg.norm(zA["eef_pos"][:m] - zB["eef_pos"][:m], axis=1)
        ang = qang(zA["eef_quat"][:m], zB["eef_quat"][:m]); grip = np.abs(zA["gripper_qpos"][:m] - zB["gripper_qpos"][:m]).sum(1)
        for i in range(n):
            traces.append({"unit": u, "pair": a if a == "L-O" else f"{a}-N", "exec_step": i - FS, "sim_step": i,
                           "cmd_abs_d": float(cmd[i]), "ee_pos_d_m": float(ee[i + 1]), "ee_ang_d_rad": float(ang[i + 1]),
                           "grip_qpos_d": float(grip[i + 1]), "state_differs": bool(st_diff[i + 1])})
        first = lambda arr: (int(np.argmax(arr)) if arr.any() else None)  # noqa: E731
        fc = first(cmd > 0); fs_ = first(st_diff[1:]); f01 = first(ee[1:] > 1e-4); f1 = first(ee[1:] > 1e-3)
        to_exec = lambda x: None if x is None else x - FS  # noqa: E731
        calls = arms[a]["calls"] if a != "L-O" else arms["L"]["calls"]
        applied = [c["call"] for c in calls if c["status"] in ("APPLIED",)]
        first_ap = applied[0] if applied else None
        pre_ok = None
        if a != "L-O":
            k = FS + FIRST
            pre_ok = bool(np.array_equal(zA["action"][:k], zN["action"][:k]) and np.array_equal(zA["state"][:k + 1], zN["state"][:k + 1]))
            bA, bN = arms[a]["buf"][:k], arms["N"]["buf"][:k]
            pre_ok = pre_ok and json.dumps(bA) == json.dumps(bN)
        delays.append({"unit": u, "pair": a if a == "L-O" else f"{a}-N", "first_applied_call": first_ap,
                       "first_cmd_diff_exec_step": to_exec(fc), "first_state_diff_exec_step": to_exec(fs_),
                       "first_ee_gt_0.1mm_exec_step": to_exec(f01), "first_ee_gt_1mm_exec_step": to_exec(f1),
                       "cmd_delay_from_first_applied": (None if (fc is None or first_ap is None) else to_exec(fc) - first_ap),
                       "pre_intervention_identical": pre_ok,
                       "final_ee_pos_d_m": float(ee[min(n, m - 1)]), "max_ee_pos_d_m": float(ee.max()),
                       "final_ee_ang_d_rad": float(ang[min(n, m - 1)]), "max_grip_qpos_d": float(grip.max())})
json.dump(rows, open(os.path.join(OUT, "cl_arm_checks.json"), "w"), indent=1)
json.dump(delays, open(os.path.join(OUT, "cl_delay_table.json"), "w"), indent=1)
import pandas as pd  # noqa: E402
pd.DataFrame(traces).to_csv(os.path.join(OUT, "cl_step_traces.csv"), index=False)
pd.DataFrame(delays).to_csv(os.path.join(OUT, "cl_delay_table.csv"), index=False)
pd.set_option("display.width", 250)
print(pd.DataFrame(rows).drop(columns=["status_counts"]).to_string())
for r in rows:
    print(r["unit"], r["arm"], r["status_counts"])
print(pd.DataFrame(delays).to_string())
