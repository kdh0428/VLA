#!/usr/bin/env python
"""VLA-0 closed-loop feasibility harness (v02, 2026-10-21). GPU; requires --enable-gpu. Protocol: PROTOCOL_CL_v02.md.

The official LIBERO loop `eval_run`, plus `_get_libero_env`, `_get_libero_task` and `_img_to_numpy`, are executed VERBATIM. They are
extracted via AST from roboverse/evals/libero/eval.py @ b78db19, and the file is checked byte-for-byte against the pinned tarball.
Two things are connected from outside, without changing the loop's computation:
  * `libero_to_rv_obs` (needs lerobot, not installed) -> passes the raw simulator images on. The model wrapper then applies the
    pilot adapter path V.obs_to_rgb + prompt_inputs, which validation equated with the native QwenActor.forward (12/12; Stage 1
    re-checks it on closed-loop observations).
  * model = an arm-specific callable returning {"out_ori_act": float32 tensor (1, 8, 7)} from the official
    QwenActor.get_action_from_text_action.
Logging hook: env.step is wrapped. Before each step it copies the eval_run frame's ensemble buffer (old_action_chunks), the
ensembled chunk and action_i (read-only). After each step it records the executed action, EE pose, gripper qpos and the full
MuJoCo state."""
import argparse, ast, hashlib, inspect, json, os, sys, tarfile, time, traceback
import numpy as np
import torch

WORK = "/root/VLA/vla0_work"
sys.path.insert(0, os.path.join(WORK, "scripts"))
import vla0_adapter as V  # noqa: E402
from vla0_run import donors_for, run_arm, seed_of, VERIFIED_SHARDS, TOKENIZER_FILES, UPSTREAM_TARBALL_SHA, HF_REVISION, _h  # noqa: E402
from libero.libero import benchmark, get_libero_path  # noqa: E402
from libero.libero.envs import OffScreenRenderEnv  # noqa: E402
from robosuite import load_controller_config  # noqa: E402

ACT, H, ANCHOR = 7, 8, 3
EVAL = os.path.join(V.REPO, "libs/RoboVerse/roboverse/evals/libero/eval.py")
TAR = os.path.join(WORK, "vla0_b78db19.tar.gz")
OFFICIAL = ["eval_run", "_get_libero_env", "_get_libero_task", "_img_to_numpy", "_max_task_length_lookup"]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load_official():
    src = open(EVAL, "rb").read()
    with tarfile.open(TAR) as tf:
        m = [x for x in tf.getmembers() if x.name.endswith("libs/RoboVerse/roboverse/evals/libero/eval.py")][0]
        assert tf.extractfile(m).read() == src, "eval.py differs from pinned tarball"
    text = src.decode(); tree = ast.parse(text)
    ns = {"np": np, "torch": torch, "os": os, "math": __import__("math"), "tqdm": lambda x: x, "pkl": __import__("pickle"),
          "OffScreenRenderEnv": OffScreenRenderEnv, "get_libero_path": get_libero_path, "benchmark": benchmark,
          "load_controller_config": load_controller_config}
    for n in tree.body:   # module constants (LIBERO_ENV_RESOLUTION, LIBERO_DUMMY_ACTION, LIBERO_TASK_SUITE_MAX_STEPS)
        if isinstance(n, ast.Assign) and all(isinstance(t, ast.Name) and t.id.startswith("LIBERO_") for t in n.targets):
            exec(compile(ast.Module([n], []), EVAL, "exec"), ns)
    srcs = {}
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and n.name in OFFICIAL:
            s = ast.get_source_segment(text, n); srcs[n.name] = sha(s.encode())
            exec(compile(s, f"{EVAL}::{n.name}", "exec"), ns)
    ns["libero_to_rv_obs"] = lambda obs, instr, cfg: {"agentview": np.array(obs["agentview_image"]),
                                                      "wrist": np.array(obs["robot0_eye_in_hand_image"]), "instr": instr}
    return ns, {"eval_py_sha256": sha(src), "function_source_sha256": srcs}


def fingerprint(args):
    shards = {f: _h(os.path.join(V.WEIGHTS, f)) for f in VERIFIED_SHARDS}
    if any(shards[f] != VERIFIED_SHARDS[f] for f in shards):
        sys.exit(f"weight shards differ from verified revision: {shards}")
    tok = {}
    for f in TOKENIZER_FILES:
        x = _h(os.path.join(V.WEIGHTS, f))
        if x != _h(os.path.join(V.HF, "model_last", f)):
            sys.exit(f"tokenizer/processor file differs: {f}")
        tok[f] = x
    if _h(TAR) != UPSTREAM_TARBALL_SHA:
        sys.exit("upstream tarball mismatch")
    return {"harness": _h(os.path.abspath(__file__)), "adapter": _h(os.path.join(WORK, "scripts", "vla0_adapter.py")), "vla0_run_helpers": _h(os.path.join(WORK, "scripts", "vla0_run.py")),
            "hf_revision": HF_REVISION, "weight_shards": shards, "tokenizer_processor": tok, "upstream_tarball": UPSTREAM_TARBALL_SHA,
            "config_yaml": _h(os.path.join(V.HF, "config.yaml")), "dataset_stats": _h(os.path.join(V.HF, "dataset_stats.pkl")),
            "manifest": _h(args.manifest), "protocol": _h(args.protocol)}


class Ledger:
    """GPU-minute ledger across attempts: every process that holds the model adds its wall time (conservative)."""
    def __init__(self, path, cap):
        self.path, self.cap = path, cap
        self.d = json.load(open(path)) if os.path.exists(path) else {"cap_min": cap, "attempts": []}
        self.d["attempts"].append({"pid": os.getpid(), "start": time.time(), "last": time.time(), "note": ""})
        self.save()

    def tick(self, note=None):
        a = self.d["attempts"][-1]; a["last"] = time.time()
        if note: a["note"] = note
        self.save()

    def used(self):
        return sum(a["last"] - a["start"] for a in self.d["attempts"]) / 60

    def save(self):
        json.dump(self.d, open(self.path + ".tmp", "w"), indent=1); os.replace(self.path + ".tmp", self.path)


class Policy:
    """arm-specific model callable used by the official eval_run."""
    def __init__(self, a, kv, unit, arm, first_iv, log, ledger, native_check=False):
        self.a, self.kv, self.unit, self.arm, self.first_iv = a, kv, unit, arm, first_iv
        self.log, self.ledger, self.native_check, self.j = log, ledger, native_check, 0

    def parse(self, text):
        return self.a.get_action_from_text_action([text])          # official parser (float32, CPU)

    def __call__(self, agentview, wrist, instr):
        a, j = self.a, self.j
        t0 = time.time()
        rgb = V.obs_to_rgb(agentview, wrist, self.kv)
        mi = V.prompt_inputs(a, rgb, instr)
        rec = {"unit": self.unit["unit"], "arm": self.arm, "call": j, "instr": instr,
               "agentview_sha": sha(np.ascontiguousarray(agentview).tobytes()), "wrist_sha": sha(np.ascontiguousarray(wrist).tobytes()),
               "rgb_sha": sha(rgb.cpu().numpy().tobytes()), "rgb_dtype": str(rgb.dtype)}
        t1 = time.time()
        nat = V.generate(a, mi)[0]
        rec["t_natural_s"] = time.time() - t1
        au = V.audit(a, nat); A = au["numbers"]
        nat_text = V.decode(a, nat)
        nat_chunk = self.parse(nat_text)
        rec["natural"] = {"ids": nat, "text": nat_text, "audit": {k: v for k, v in au.items() if k != "text"},
                          "parser_input_numbers": len(nat_text.strip().split(" ")) if nat_text.strip() else 0,
                          "parser_pads_or_truncates": au["n_numbers"] != H * ACT}
        if self.native_check:
            t2 = time.time()
            with torch.no_grad():
                out = a.forward(rgb=rgb, instr=[instr], get_loss=False, get_action=True, generate_temperature=0.0)
            rec["native_check"] = {"text_equal": out["pred_action_txt"][0] == nat_text,
                                   "out_ori_act_equal": bool(torch.equal(out["out_ori_act"].cpu(), nat_chunk)), "t_s": time.time() - t2}
        chunk, status, reason = nat_chunk, "NATURAL", None
        complete = au["complete"] and au["in_range"] and au["eos"]
        if self.arm != "N" and j >= self.first_iv:
            ref_pids = V.tok(a, V.prefix_text(A, ANCHOR * ACT)) if complete else None
            if not complete:
                status, reason = "NOT_APPLIED", "natural_incomplete"
            elif ref_pids != nat[:len(ref_pids)]:
                status, reason = "NOT_APPLIED", "prefix_does_not_retokenise"
            elif self.arm == "R":
                t3 = time.time()
                R = run_arm(a, mi, A, {}, [])
                rec["t_forced_s"] = time.time() - t3
                ident = R["ids"] == nat[len(ref_pids):]
                text = V.decode(a, ref_pids + R["ids"])
                chunk = self.parse(text)
                rec["selfpatch"] = {"suffix_ids": R["ids"], "token_identity": ident, "text_identity": text == nat_text,
                                    "chunk_identity": bool(torch.equal(chunk, nat_chunk))}
                rec["conditioning_prefix_ids"] = ref_pids; rec["emitted_prefix_ids"] = ref_pids
                status = "SELFPATCH_OK" if ident else "SELFPATCH_MISMATCH"
            else:
                which = [3] if self.arm == "L" else [2]
                t3 = time.time()
                sseed = seed_of(f"vla0cl:{self.unit['unit']}:{j}")
                sids = V.generate(a, mi, temperature=0.7, seed=sseed, num_return=4)
                rec["t_sources_s"] = time.time() - t3
                srcs = [{"ids": s, "audit": V.audit(a, s)} for s in sids]
                rec["sources"] = [{"ids": s["ids"], "n_numbers": s["audit"]["n_numbers"], "in_range": s["audit"]["in_range"]} for s in srcs]
                rec["source_seed"] = sseed
                donors, dlog = donors_for(a, A, srcs, ref_pids)
                rec["donor_search"] = dlog
                d = donors[which[0]]
                if d is None:
                    status, reason = "NOT_APPLIED", "source_missing"
                else:
                    t4 = time.time()
                    arm = run_arm(a, mi, A, donors, which)
                    rec["t_forced_s"] = time.time() - t4
                    spans = V.vector_spans(a, A, ANCHOR)
                    inv_len = len(arm["prefix_ids"]) == len(ref_pids)
                    inv_out = inv_len and all(arm["prefix_ids"][k] == ref_pids[k] for k in range(len(ref_pids))
                                              if not any(spans[w - 1][0] <= k < spans[w - 1][1] for w in which))
                    sa = arm["audit"]
                    ok35 = sa["n_numbers"] == (H - ANCHOR) * ACT and sa["n_bad_fields"] == 0 and sa["in_range"] and sa["eos"]
                    rec["donor"] = {"vector": which[0], "cand": d[0], "values": d[1]}
                    rec["conditioning_prefix_ids"] = arm["prefix_ids"]; rec["conditioning_prefix_numbers"] = arm["prefix_numbers"]
                    rec["emitted_prefix_ids"] = ref_pids
                    rec["edited_suffix"] = {"ids": arm["ids"], "numbers": sa["numbers"], "exact35_eos": ok35,
                                            "invariant_len": inv_len, "invariant_outside": inv_out}
                    if not (ok35 and inv_len and inv_out):
                        status, reason = "NOT_APPLIED", "invalid_edited_suffix_or_invariant"
                    else:
                        text = V.decode(a, ref_pids + arm["ids"])
                        c2 = self.parse(text)
                        assert torch.equal(c2[0, :ANCHOR], nat_chunk[0, :ANCHOR]), "emitted prefix vectors changed"
                        chunk, status = c2, "APPLIED"
                        rec["executed_text"] = text
        rec["status"], rec["reason"] = status, reason
        rec["chunk"] = chunk[0].numpy().tolist(); rec["chunk_dtype"] = str(chunk.dtype)
        rec["natural_chunk"] = nat_chunk[0].numpy().tolist()
        rec["t_call_s"] = time.time() - t0
        self.log.append(rec); self.j += 1
        self.ledger.tick()
        return {"out_ori_act": chunk.clone()}


class StepLogger:
    def __init__(self, env):
        self._env, self.trace = env, []

    def __getattr__(self, k):
        return getattr(self._env, k)

    def reset(self):
        return self._env.reset()

    def set_init_state(self, s):
        obs = self._env.set_init_state(s)
        self.trace.append({"kind": "init", "state": np.array(self._env.get_sim_state()), **self._pose(obs)})
        return obs

    @staticmethod
    def _pose(obs):
        return {"eef_pos": np.array(obs["robot0_eef_pos"]), "eef_quat": np.array(obs["robot0_eef_quat"]),
                "gripper_qpos": np.array(obs["robot0_gripper_qpos"])}

    def step(self, act):
        f = inspect.currentframe().f_back.f_locals         # eval_run frame, read-only copy
        buf = [np.array(c) for c in f.get("old_action_chunks", [])] if "old_action_chunks" in f else None
        ens = np.array(f["action_chunk"]) if f.get("action_chunk") is not None else None
        obs, r, done, info = self._env.step(act)
        self.trace.append({"kind": "step", "t": f.get("t"), "action_i": f.get("action_i"), "action": np.array(act, dtype=np.float64),
                           "buffer": buf, "ensembled_chunk": ens, "state": np.array(self._env.get_sim_state()),
                           "done": bool(done), "reward": float(r), **self._pose(obs)})
        return obs, r, done, info


def run_episode(ns, unit, policy, cfg, steps):
    task, init_states, _, desc = ns["_get_libero_task"](unit["task_name"], unit["suite"], 0)
    assert desc == unit["instruction"]
    env = StepLogger(ns["_get_libero_env"](task, seed=cfg["env_seed"], resolution=ns["LIBERO_ENV_RESOLUTION"],
                                           camera_depths=cfg["camera_depths"]))
    model = lambda agentview, wrist, instr: policy(agentview, wrist, instr)  # noqa: E731
    t0 = time.time()
    success, _ = ns["eval_run"](env, model, None, desc, init_states[unit["init_state_index"]], steps, cfg["frame_skip"],
                                cfg["action_horizon"], "", False, cfg["ensemble_prediction"], cfg["ensemble_version"],
                                cfg["ensemble_2_weight"])
    wall = time.time() - t0
    env._env.close()
    return env.trace, bool(success), wall


def replay_actions(ns, unit, cfg, actions):
    """simulator determinism: feed the logged actions (incl. dummies) to a fresh env, no model."""
    task, init_states, _, _ = ns["_get_libero_task"](unit["task_name"], unit["suite"], 0)
    env = ns["_get_libero_env"](task, seed=cfg["env_seed"], resolution=ns["LIBERO_ENV_RESOLUTION"], camera_depths=cfg["camera_depths"])
    env.reset(); env.set_init_state(init_states[unit["init_state_index"]])
    st = [np.array(env.get_sim_state())]
    for a_ in actions:
        env.step(list(a_)); st.append(np.array(env.get_sim_state()))
    env.close()
    return st


def save_arm(out, unit, arm, trace, calls, success, wall):
    d = os.path.join(out, unit["unit"], arm); os.makedirs(d, exist_ok=True)
    steps = [x for x in trace if x["kind"] == "step"]
    np.savez_compressed(os.path.join(d, "trace.npz"), state=np.stack([x["state"] for x in trace]),
                        eef_pos=np.stack([x["eef_pos"] for x in trace]), eef_quat=np.stack([x["eef_quat"] for x in trace]),
                        gripper_qpos=np.stack([x["gripper_qpos"] for x in trace]), action=np.stack([x["action"] for x in steps]),
                        t=np.array([x["t"] for x in steps]), done=np.array([x["done"] for x in steps]))
    bufs = [{"t": x["t"], "action_i": x["action_i"], "buffer": None if x["buffer"] is None else [b.tolist() for b in x["buffer"]],
             "buffer_dtypes": None if x["buffer"] is None else [str(b.dtype) for b in x["buffer"]],
             "ensembled_chunk": None if x["ensembled_chunk"] is None else x["ensembled_chunk"].tolist(),
             "ensembled_dtype": None if x["ensembled_chunk"] is None else str(x["ensembled_chunk"].dtype)} for x in steps]
    json.dump(bufs, open(os.path.join(d, "buffers.json"), "w"))
    with open(os.path.join(d, "calls.jsonl"), "w") as f:
        for c in calls:
            f.write(json.dumps(c) + "\n")
    json.dump({"success_flag_log_only": success, "wall_s": wall, "n_calls": len(calls), "n_steps": len(steps)},
              open(os.path.join(d, "episode.json"), "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True); ap.add_argument("--protocol", required=True)
    ap.add_argument("--out", required=True); ap.add_argument("--ledger", required=True)
    ap.add_argument("--cap-min", type=float, default=150.0); ap.add_argument("--enable-gpu", action="store_true")
    ap.add_argument("--stage", choices=["1", "2", "both"], default="both")
    ap.add_argument("--release-shm-weights", action="store_true")
    g = ap.parse_args()
    if not g.enable_gpu:
        sys.exit("--enable-gpu not given")
    if os.path.isdir(g.out) and any(os.scandir(g.out)):
        sys.exit("output dir not empty: use a new directory (no resume)")
    M = json.load(open(g.manifest)); cfg = M["config"]
    ns, offi = load_official()
    fp = fingerprint(g)                                   # before model load
    os.makedirs(g.out)
    json.dump({**fp, **offi}, open(os.path.join(g.out, "RUN_FINGERPRINT.json"), "w"), indent=1)
    led = Ledger(g.ledger, g.cap_min)
    if led.used() > g.cap_min:
        sys.exit("GPU cap already used")
    a, _, kv = V.build_actor()
    if g.release_shm_weights:
        for f in sorted(os.listdir(V.WEIGHTS)):
            if f.endswith(".safetensors"):
                os.remove(os.path.join(V.WEIGHTS, f))
    json.dump({"generation_config": a.model.generation_config.to_dict(), "torch": torch.__version__,
               "gpu": torch.cuda.get_device_name(0), "load_done_gpu_min": led.used()},
              open(os.path.join(g.out, "run_meta.json"), "w"), indent=1, default=str)
    status = {"stage1": "NOT_RUN", "stage2": {}, "stop_reason": None}
    S = lambda: json.dump({**status, "gpu_min_used_total": led.used()}, open(os.path.join(g.out, "STATUS.json"), "w"), indent=1)  # noqa: E731
    try:
        if g.stage in ("1", "both"):
            u = [x for x in M["units"] if x["stage"] == "stage1"][0]
            calls = []
            pol = Policy(a, kv, u, "N", 10 ** 9, calls, led, native_check=True)
            torch.cuda.reset_peak_memory_stats()
            trace, succ, wall = run_episode(ns, u, pol, cfg, M["stage1"]["steps"])
            save_arm(g.out, u, "N", trace, calls, succ, wall)
            acts = [x["action"] for x in trace if x["kind"] == "step"]
            st = replay_actions(ns, u, cfg, acts)
            det = all(np.array_equal(s, x["state"]) for s, x in zip(st, trace))
            nat_ok = all(c["native_check"]["text_equal"] and c["native_check"]["out_ori_act_equal"] for c in calls)
            buf_logged = all(x["buffer"] is not None for x in trace if x["kind"] == "step")
            status["stage1"] = {"status": "PASS" if (det and nat_ok and buf_logged and len(calls) == M["stage1"]["steps"]) else "FAIL",
                                "n_calls": len(calls), "native_equal": sum(c["native_check"]["text_equal"] and c["native_check"]["out_ori_act_equal"] for c in calls),
                                "sim_determinism_bitwise": det, "buffer_logged": buf_logged, "episode_wall_s": wall,
                                "t_natural_s_mean": float(np.mean([c["t_natural_s"] for c in calls])),
                                "t_native_forward_s_mean": float(np.mean([c["native_check"]["t_s"] for c in calls])),
                                "peak_vram_gb": torch.cuda.max_memory_allocated() / 1e9, "gpu_min_used_after": led.used()}
            S()
            if status["stage1"]["status"] != "PASS":
                status["stop_reason"] = "stage1_fail"; S(); return
        if g.stage in ("2", "both"):
            per_unit_est = None
            for u in [x for x in M["units"] if x["stage"] == "stage2"]:
                if per_unit_est and led.used() + per_unit_est > g.cap_min:
                    status["stage2"][u["unit"]] = "NOT_RUN_BUDGET"; status["stop_reason"] = "budget"; S(); break
                t_unit = time.time(); res = {}
                for arm in M["stage2"]["arms"]:
                    calls = []
                    pol = Policy(a, kv, u, arm, M["stage2"]["first_intervention_replan"], calls, led)
                    torch.cuda.reset_peak_memory_stats()
                    trace, succ, wall = run_episode(ns, u, pol, cfg, M["stage2"]["steps"])
                    save_arm(g.out, u, arm, trace, calls, succ, wall)
                    res[arm] = {"trace": trace, "calls": calls}
                    status["stage2"].setdefault(u["unit"], {})[arm] = {"wall_s": wall, "n_calls": len(calls),
                        "status_counts": {k: sum(c["status"] == k for c in calls) for k in {c["status"] for c in calls}},
                        "peak_vram_gb": torch.cuda.max_memory_allocated() / 1e9}
                    if arm == "N":
                        acts = [x["action"] for x in trace if x["kind"] == "step"]
                        st = replay_actions(ns, u, cfg, acts)
                        status["stage2"][u["unit"]]["N_sim_determinism_bitwise"] = all(np.array_equal(s, x["state"]) for s, x in zip(st, trace))
                    if arm == "R":
                        tn, tr = res["N"]["trace"], trace
                        same = len(tn) == len(tr) and all(np.array_equal(x["state"], y["state"]) for x, y in zip(tn, tr)) and \
                            all(np.array_equal(x["action"], y["action"]) for x, y in zip(tn, tr) if x["kind"] == "step")
                        sp = [c for c in calls if c["status"].startswith("SELFPATCH")]
                        status["stage2"][u["unit"]]["M1_noop"] = {"N_R_actions_states_bitwise": same, "selfpatch_calls": len(sp),
                                                                  "selfpatch_token_identity": sum(c["selfpatch"]["token_identity"] for c in sp)}
                        if not same:
                            status["stop_reason"] = f"M1_noop_fail_{u['unit']}"; S(); return
                    S()
                per_unit_est = (time.time() - t_unit) / 60 * 1.1
                status["stage2"][u["unit"]]["unit_gpu_min"] = (time.time() - t_unit) / 60
                S()
    except Exception:
        status["stop_reason"] = "exception: " + traceback.format_exc()[-2000:]; S(); raise
    finally:
        led.tick("process end"); S()


if __name__ == "__main__":
    main()
