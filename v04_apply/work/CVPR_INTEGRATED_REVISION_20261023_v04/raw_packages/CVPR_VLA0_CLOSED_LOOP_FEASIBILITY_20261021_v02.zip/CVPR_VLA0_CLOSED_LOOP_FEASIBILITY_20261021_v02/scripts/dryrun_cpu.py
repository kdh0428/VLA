"""CPU dry run (no model, no GPU): official eval_run + env + StepLogger with a fake policy returning fixed chunks."""
import json, sys, numpy as np, torch
sys.path.insert(0, "/root/VLA/vla0_cl_work/scripts")
import vla0_cl_harness as Hn
ns, offi = Hn.load_official()
M = json.load(open("/root/VLA/vla0_cl_work/manifest_cl_v02.json")); cfg = M["config"]; u = M["units"][0]
rng = np.random.default_rng(0); calls = []
def fake(agentview, wrist, instr):
    c = torch.tensor(rng.uniform(-0.3, 0.3, (1, 8, 7)).astype(np.float32)); c[0, :, 6] = -1.0
    calls.append(c[0].numpy().copy()); return {"out_ori_act": c}
class P:
    def __call__(self, agentview, wrist, instr): return fake(agentview, wrist, instr)
trace, succ, wall = Hn.run_episode(ns, u, P(), cfg, 12)
acts = [x["action"] for x in trace if x["kind"] == "step"]
st = Hn.replay_actions(ns, u, cfg, acts)
det = all(np.array_equal(s, x["state"]) for s, x in zip(st, trace))
steps = [x for x in trace if x["kind"] == "step"]
print("n_steps", len(steps), "calls", len(calls), "det", det, "wall", round(wall, 1), "offi", offi["eval_py_sha256"][:12])
print("buffer len at last step", len(steps[-1]["buffer"]), steps[-1]["buffer"][0].dtype, steps[-1]["ensembled_chunk"].dtype)
# check executed action = ensemble of logged chunks (version 1): newest weight 1, older 0.5, shifted
k = len(calls) - 1; num = calls[k][0].copy(); den = 1.0
for i in range(max(0, k - 7), k):
    num += 0.5 * calls[i][k - i]; den += 0.5
exp = num / den
print("exec matches manual ensemble (arm dims)", np.allclose(steps[-1]["action"][:6], exp[:6], atol=1e-6), steps[-1]["action"][:3], exp[:3])
