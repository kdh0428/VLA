# VLA-0 closed-loop feasibility — v02 (2026-10-21)

검토 요청: `REQUEST_v02.md` (CVPR_VLA0_FOLLOWUP_CHECK_20261021_v02.md)

## 실제 실행 수와 상태 (먼저)

| 항목 | 결과 |
| --- | --- |
| GPU 사용 | **74.0분** / 상한 150분. 한 번의 시도로 끝났고 실패·재시도 없음. RTX 5090 1장, peak VRAM 7.7 GB |
| Stage 1 smoke (libero_goal / task 0 / init 8, N, 16 step) | **PASS** — native forward 동일 16/16, 시뮬레이터 결정성 bitwise, buffer 기록됨 |
| Stage 2 (U1–U4 × N/R/L/O, 각 48 step) | **16 episode, 768 model call 모두 완료**. STOP 없음 |
| M1 no-op (R = N, action·state bitwise) | **4/4 unit**, self-patch token identity 160/160 |
| M2 offline replay (기록된 float32 chunk를 순서대로 공식 eval_run에 공급) | 실행 action·buffer bitwise 일치 **17/17 episode** |
| 개입 전(call < 8) 일치 | 12/12 arm-unit |
| L/O 개입 coverage | O 160/160 APPLIED. L 158 APPLIED, 2 NOT_APPLIED(source_missing, 자연 chunk 실행, 개입으로 세지 않음) |
| 성공 flag | 모두 false. 48-step truncated run이므로 로그로만 보존 |

## 핵심 결과
- **명령 변화 시점:** context-only edit에서 실행 명령이 처음 바뀐 시점은 8개 L/O arm-unit 모두 첫 APPLIED call 뒤 **정확히 offset 3**이었습니다. 시뮬레이터 state도 같은 step에서 갈라집니다.
- **실제 운동 차이:** EE 차이가 0.1 mm를 넘는 시점은 첫 편집 후 3–8 step, 1 mm를 넘는 시점은 7–20 step입니다. 48 step 시점의 차이는 0.8–9.2 mm입니다.
- **L vs O:** 운동 차이의 대소가 unit마다 일관되지 않습니다(평균 ‖ΔEE‖ L>O 3/4, 최종 ‖ΔEE‖ O>L 3/4). n=4이므로 유의성·동등성·성공률 주장은 하지 않습니다. open-loop의 L>O가 운동으로 이어진다고도 주장하지 않습니다.
- **다음 단계 판단:** task-outcome 평가는 지금 바로 진행할 단계가 아니라고 봅니다. 먼저 같은 4개 unit에서 full-length 쌍 episode를 몇 개 돌려(약 3–4 GPU-시간) 운동 차이가 커지는지 포화되는지 확인하는 편이 낫습니다. 자세한 근거는 `DECISION_v02.md`에 있습니다.

## 이전 패키지 정정 (§4)
- `followup_corrections/CVPR_VLA0_FOLLOWUP_CHECK_RESULT_20261021_v02/`에 정정본을 두었습니다(원본 zip은 그대로).
  - runner 계보: e9c0bafb…(최초 GPU 패키지, runtime fingerprint 없음) → 45943fc3…(CPU 수정판) → 4a18f2e5…(향후 실행용 수정판).
  - test 결과 파일명 수정 후 재실행: ALL_PASS, 내용 동일.
  - `repro_deps/` 추가: eval.py, tarball, LICENSE, config.yaml, dataset_stats.pkl.
  - replay 해석 문구 보완: 단위, as_forced 부호, stationary 가정, float64.
- 실행 unit 4개와 smoke unit은 manifest에 suite, task 이름, instruction, init index까지 고정했습니다.
- 예산 150분은 smoke와 실패 시도를 포함한 총액으로 명시했습니다.

## 파일
- **고정 계획:** `PROTOCOL_CL_v02.md`, `PROTOCOL_LOCK_CL_v02.sha256`(GPU 사용 전 고정), `manifest_cl_v02.json`, `env_cl.sh`, `site_libero_links.txt`
- **변경 기록:** `CHANGELOG_CL_v02.md`
- **판단:** `DECISION_v02.md`
- **코드:** `scripts/`
  - `vla0_cl_harness.py`: 공식 eval_run 연결과 arm 로직
  - `vla0_cl_analyze.py`: M2, divergence, delay
  - `vla0_cl_figure.py`
  - `vla0_cl_window_summary.py`
  - `dryrun_cpu.py`
- **원시 로그:** `run/attempt1/`
  - `RUN_FINGERPRINT.json`, `run_meta.json`, `STATUS.json`
  - unit/arm별 파일:
    - `calls.jsonl`: call마다 자연 출력 ids/text, source, conditioning·emitted prefix, suffix, 실행 chunk, 입력 hash, dtype, 시간
    - `buffers.json`: step별 ensemble buffer
    - `trace.npz`: action, MuJoCo state, EE pose, gripper
    - `episode.json`
- **GPU 기록:** `run_gpu_ledger.json`, `logs_attempt1.txt`
- **분석 결과:** `analysis/`
  - `cl_arm_checks.json`
  - `cl_delay_table.csv/json`
  - `cl_step_traces.csv`
  - `cl_window_summary.csv`
  - `cl_cost_by_call_kind.json`
- **그림:** `figures/vla0_closed_loop_traces.png/pdf`
- **수행하지 않은 항목:** `NOT_DONE_v02.md`
