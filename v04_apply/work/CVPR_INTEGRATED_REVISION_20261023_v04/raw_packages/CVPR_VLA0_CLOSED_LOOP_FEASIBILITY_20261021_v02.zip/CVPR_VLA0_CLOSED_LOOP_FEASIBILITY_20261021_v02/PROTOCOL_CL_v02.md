# PROTOCOL_CL_v02 — VLA-0 closed-loop feasibility (fixed before any GPU use, 2026-10-21)

Request: CVPR_VLA0_FOLLOWUP_CHECK_20261021_v02.md §6. The 149-observation pilot, the completed runs and the earlier controls are kept unchanged.

## Budget
- **Total GPU cap: 150 min**, covering Stage 1, Stage 2 and any failed or repeated attempts. The ledger is `run_gpu_ledger.json`: every process that holds the model adds its whole wall time, from process start (fingerprint hashing included) to exit. This is a conservative count.
- Stage 1 cap: 15 GPU-min. If Stage 1 is unresolved, report BLOCKED.
- GPU: one RTX 5090 (`CUDA_DEVICE_ORDER=PCI_BUS_ID`, physical GPU 1).
- Excluded: no 600-observation expansion, full episodes, success-rate evaluation or fine-tuning.

## Fixed configuration
action_horizon 1, ensemble_prediction 8, ensemble_version 1, frame_skip 10, env seed 7, resolution 256, camera depths on (the official README LIBERO command). No other configuration is run.

## Units (`manifest_cl_v02.json`)
| unit | stage | suite | task index | task name | init state |
| --- | --- | --- | --- | --- | --- |
| S1_smoke | 1 | libero_goal | 0 | open_the_middle_drawer_of_the_cabinet | 8 |
| U1 | 2 | libero_spatial | 0 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate | 6 |
| U2 | 2 | libero_object | 5 | pick_up_the_tomato_sauce_and_place_it_in_the_basket | 6 |
| U3 | 2 | libero_goal | 0 | open_the_middle_drawer_of_the_cabinet | 7 |
| U4 | 2 | libero_goal | 5 | push_the_plate_to_the_front_of_the_stove | 7 |

Initial states 6, 7 and 8 were not used before: validation used state 0 and the pilot used 1–5. Any later unseen-state experiment must exclude states 6–8 for these tasks, and 0–5 as before.

## Code path
- **Official code, run verbatim:** `eval_run`, `_get_libero_env`, `_get_libero_task`, `_img_to_numpy` and `_max_task_length_lookup`. They are AST-extracted from eval.py @ b78db19, which is checked byte-for-byte against the pinned tarball; the function-source hashes are in RUN_FINGERPRINT.json.
- **Observation path (deviation, stated).** The official `libero_to_rv_obs` needs lerobot, which is not installed. It is replaced by a pass-through of the raw simulator images. The model wrapper applies the pilot adapter path (`obs_to_rgb` + `prompt_inputs`), which validation equated with the native `QwenActor.forward` (12/12). Stage 1 re-checks native-forward equality at every closed-loop call.
- **Environment.** autovla conda env (transformers 4.49), plus only the LIBERO/robosuite/mujoco packages missing from it (`env_cl.sh`, `site_libero/`).
- **Decoding.** Every executed chunk is produced by the official `QwenActor.get_action_from_text_action` as float32 and passed unchanged to `eval_run`.
- **Logging.** An env.step wrapper reads the eval_run frame's ensemble buffer, ensembled chunk and action_i (read-only copies), then records the executed action, EE pose, gripper qpos and the full MuJoCo state.

## Stage 1 (S1_smoke, arm N, 16 executed steps)
PASS requires all of:
- (a) 16 calls, each with native-forward text and `out_ori_act` equal to the adapter output;
- (b) a model-free replay of the logged actions in a fresh env reproducing every MuJoCo state bitwise;
- (c) the buffer logged at every step.

Also recorded: per-call times by kind (natural greedy, native forward) and peak VRAM.

## Stage 2 (U1–U4; arms N, R, L, O; 48 executed steps after the frame skip)
Every arm starts from a fresh env (seed 7) and the same initial state. Intervention calls begin at call index 8 (executed step 8), when the 8-chunk buffer is first full.
- **N:** natural policy.
- **R:** at each call ≥ 8, the natural first-3-vector prefix is forced back (forced incremental decoding). The executed chunk is natural prefix + forced continuation. The token, text and chunk identity with the natural output are recorded.
- **L / O:** at each call ≥ 8, conditioning vector 3 (L) or vector 2 (O) is replaced by a donor.
  - Donor rule, as in the pilot: 4 samples at T = 0.7, seed = sha256("vla0cl:" + unit + ":" + call)[:4]; the first eligible candidate whose vector differs and whose token length matches, with identical tokens outside the span.
  - The executed chunk is the call's natural vectors 1–3 plus the edited suffix (vectors 4–8). It must be exactly 35 integers + EOS, with invariants holding.
  - Otherwise the natural chunk is executed and the call is logged as NOT_APPLIED (natural_incomplete / prefix_does_not_retokenise / source_missing / invalid_edited_suffix_or_invariant). NOT_APPLIED calls are not counted as interventions, null effects or self-patch successes. Seeds and candidate counts are never changed to obtain donors.
- **Order and stops:** N, R, L, O per unit.
  - Model-free action replay of N → simulator determinism.
  - **M1 (STOP rule):** R's executed actions and states must equal N's bitwise. Otherwise STOP; L/O results are not reported as validated.
  - **Budget rule:** a unit starts only if used + 1.1 × (last unit's GPU-min) ≤ 150.

## Measurements (analysis after the run, CPU)
- **M2.** Offline replay of every arm's *logged* chunks, in order, as float32 through the official `eval_run` with a mock env. It must reproduce the logged executed actions bitwise and the logged buffers; no stationary assumption.
- **Pre-intervention.** Before call 8, each arm's actions, states and buffers equal N's.
- **Direct-path check.** No executed-action difference vs N may appear before 3 executed steps after the first APPLIED call (offsets 0–2). An earlier difference triggers a path investigation. A difference exactly at offset 3 is not required.
- **Per unit and arm vs N, per executed step:**
  - command difference (mean |Δ| over the 6 arm dims);
  - EE position difference (m);
  - orientation difference (quaternion angle, rad);
  - gripper qpos difference;
  - first command / state / EE-motion (> 0.1 mm and > 1 mm) difference steps;
  - delay from the first APPLIED call.
- **Also reported:** L−O EE difference.
- **Interpretation limits.** No significance or equivalence test, and no success-rate claim (n = 4). Success flags are logged only, and a 48-step truncated run is not a success-rate measurement. After the arms' actions differ, the demonstration is not ground truth.
- **Coverage and cost.** APPLIED / NOT_APPLIED by reason; per-call times by kind (natural, sources, forced); VRAM; total GPU-min.
